using System.Text.Json.Nodes;

namespace Tdm.Orchestrator.Application.DTOs;

/// <summary>Request to execute an orchestration scenario.</summary>
public class OrchestratorInputDto
{
    public required string ProjectName { get; set; }
    public required string Environment { get; set; }
    public required string Scenario { get; set; }
    public string? TestCaseId { get; set; }
    public string? UserId { get; set; }

    /// <summary>
    /// Request-time input data available to steps as "input" — reference it as {input.id}
    /// in endpoint URLs or "$input.id" in body/header templates.
    /// </summary>
    public JsonNode? InputData { get; set; }
}
