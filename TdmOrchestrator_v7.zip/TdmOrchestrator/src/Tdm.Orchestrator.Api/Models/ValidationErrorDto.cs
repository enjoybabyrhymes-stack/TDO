namespace Tdm.Orchestrator.Application.DTOs;

/// <summary>Validation error response with available options.</summary>
public class ValidationErrorDto
{
    public string Error { get; set; } = string.Empty;
    public List<string> Options { get; set; } = new();
}
