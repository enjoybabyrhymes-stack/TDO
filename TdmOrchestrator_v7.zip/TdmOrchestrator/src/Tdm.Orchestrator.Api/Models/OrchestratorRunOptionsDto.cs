using System.Text.Json.Nodes;

namespace Tdm.Orchestrator.Application.DTOs;

/// <summary>Optional request body for orchestration execution endpoint.</summary>
public class OrchestratorRunOptionsDto
{
    public string? UserId { get; set; }
    public string? TestCaseId { get; set; }
    public JsonNode? InputData { get; set; }
}
