namespace Tdm.Orchestrator.Application.DTOs;

public class LoginDto
{
    public string? Username { get; set; }
    public string? Password { get; set; }
}

/// <summary>Who is signed in.</summary>
public class UserInfoDto
{
    public int? UserId { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public int? GroupId { get; set; }
    public string? GroupName { get; set; }

    /// <summary>True when signed in with the configured admin key instead of a user account.</summary>
    public bool ViaAdminKey { get; set; }
}

public class LoginResultDto
{
    public string Token { get; set; } = string.Empty;
    public DateTime ExpiresAt { get; set; }
    public UserInfoDto User { get; set; } = new();
}

public class GroupDto
{
    public int GroupId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public int UserCount { get; set; }
    public int ScenarioCount { get; set; }
    public int ConnectionCount { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class GroupSaveDto
{
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
}

public class UserDto
{
    public int UserId { get; set; }
    public string Username { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public int? GroupId { get; set; }
    public string? GroupName { get; set; }
    public bool Active { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? LastLoginAt { get; set; }
}

public class UserCreateDto
{
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string Role { get; set; } = "USER";
    public int? GroupId { get; set; }
}

public class UserUpdateDto
{
    public string Role { get; set; } = "USER";
    public int? GroupId { get; set; }
    public bool Active { get; set; } = true;
}

public class PasswordResetDto
{
    public string Password { get; set; } = string.Empty;
}

public class AssignGroupDto
{
    /// <summary>The group to give the scenario to; null makes it unassigned (admin-only).</summary>
    public int? GroupId { get; set; }
}
