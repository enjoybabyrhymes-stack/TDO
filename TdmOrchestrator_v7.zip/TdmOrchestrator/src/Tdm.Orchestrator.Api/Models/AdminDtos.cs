using System.Text.Json.Nodes;

namespace Tdm.Orchestrator.Application.DTOs;

/// <summary>A connection (base URL or setting) as shown in the admin UI. Secret values are masked.</summary>
public class ConfigItemDto
{
    public int Id { get; set; }
    public string ConfigKey { get; set; } = string.Empty;
    public string ConfigValue { get; set; } = string.Empty;
    public string? Description { get; set; }
    public bool IsSecret { get; set; }
    public int? GroupId { get; set; }
    public string? GroupName { get; set; }
    public DateTime UpdatedAt { get; set; }
}

/// <summary>Create or update a connection. On update, an empty value keeps the stored value.</summary>
public class ConfigSaveDto
{
    public string ConfigKey { get; set; } = string.Empty;
    public string? ConfigValue { get; set; }
    public string? Description { get; set; }

    /// <summary>Administrators choose the owning group; for other users it is always their own group.</summary>
    public int? GroupId { get; set; }
}

public class MoveStepDto
{
    /// <summary>"up" or "down".</summary>
    public string Direction { get; set; } = "up";
}

public class ScenarioSummaryDto
{
    public string ProjectName { get; set; } = string.Empty;
    public string Environment { get; set; } = string.Empty;
    public string ScenarioName { get; set; } = string.Empty;
    public int StepCount { get; set; }
    public int ActiveStepCount { get; set; }
    public int? GroupId { get; set; }
    public string? GroupName { get; set; }
    public DateTime UpdatedAt { get; set; }
}

/// <summary>Answer to "can I use this scenario name?" asked while the user is typing it.</summary>
public class ScenarioNameCheckDto
{
    public bool Available { get; set; }

    /// <summary>True when the existing scenario is one the caller can open (their own group, or an administrator).</summary>
    public bool Visible { get; set; }

    public string? Message { get; set; }
}

public class StepDto
{
    public int ServiceId { get; set; }
    public string ProjectName { get; set; } = string.Empty;
    public string Environment { get; set; } = string.Empty;
    public string ScenarioName { get; set; } = string.Empty;
    public int StepOrder { get; set; }
    public string? StepDescription { get; set; }
    public string StepType { get; set; } = string.Empty;
    public string? BaseUrlConfigKey { get; set; }
    public string? Endpoint { get; set; }
    public string? HttpMethod { get; set; }
    public string? InputParamMap { get; set; }
    public string? OutputParamMap { get; set; }
    public int RetryCount { get; set; }
    public int TimeoutSeconds { get; set; } = 30;
    public int WaitTimeSeconds { get; set; }
    /// <summary>Polling: seconds between status checks (0 = not using the polling settings).</summary>
    public int PollIntervalSeconds { get; set; }
    /// <summary>Polling: total seconds to keep checking before giving up.</summary>
    public int PollMaxWaitSeconds { get; set; }

    /// <summary>The owning group. On save it only matters to administrators creating the first step of a new scenario.</summary>
    public int? GroupId { get; set; }
    public bool Active { get; set; } = true;
    public DateTime UpdatedAt { get; set; }
}

public class CloneScenarioDto
{
    public string ProjectName { get; set; } = string.Empty;
    public string Environment { get; set; } = string.Empty;
    public string ScenarioName { get; set; } = string.Empty;
    public string TargetProjectName { get; set; } = string.Empty;
    public string TargetEnvironment { get; set; } = string.Empty;
    public string TargetScenarioName { get; set; } = string.Empty;

    /// <summary>Administrators may copy into another group; otherwise the copy stays in the source group.</summary>
    public int? TargetGroupId { get; set; }
}

public class ScenarioActiveDto
{
    public bool Active { get; set; }
}

public class ValidationIssueDto
{
    /// <summary>"error" blocks a correct run; "warning" is worth reviewing.</summary>
    public string Severity { get; set; } = "error";
    public int? StepOrder { get; set; }
    public string Message { get; set; } = string.Empty;
}

public class PostmanExportDto
{
    public JsonNode? Collection { get; set; }
    public JsonNode? SampleBody { get; set; }
    public List<string> RequiredInputs { get; set; } = new();
    public string RunPath { get; set; } = string.Empty;
}

public class RunItemDto
{
    public long RunId { get; set; }
    public string ProjectName { get; set; } = string.Empty;
    public string Environment { get; set; } = string.Empty;
    public string ScenarioName { get; set; } = string.Empty;
    public int StepOrder { get; set; }
    public string? RunGroupId { get; set; }
    public string? RequestUrl { get; set; }
    public DateTime ExecutionStartTime { get; set; }
    public DateTime? ExecutionEndTime { get; set; }
    public string? Status { get; set; }
    public int AttemptCount { get; set; }
    public string? ErrorMessage { get; set; }
    public string? ExecutedBy { get; set; }
}
