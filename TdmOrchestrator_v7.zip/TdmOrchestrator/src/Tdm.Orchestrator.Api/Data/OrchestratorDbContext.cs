using Tdm.Orchestrator.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Tdm.Orchestrator.Infrastructure.Persistence;

/// <summary>EF Core DbContext for orchestration engine data access.</summary>
public class OrchestratorDbContext : DbContext
{
    public OrchestratorDbContext(DbContextOptions<OrchestratorDbContext> options) 
        : base(options)
    {
    }

    public DbSet<OrchestrationStep> OrchestrationSteps => Set<OrchestrationStep>();
    public DbSet<OrchestrationRun> OrchestrationRuns => Set<OrchestrationRun>();
    public DbSet<ApiConfig> ApiConfigs => Set<ApiConfig>();
    public DbSet<UserGroup> UserGroups => Set<UserGroup>();
    public DbSet<AppUser> AppUsers => Set<AppUser>();
    public DbSet<UserSession> UserSessions => Set<UserSession>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<OrchestrationStep>()
            .HasIndex(s => new { s.ProjectName, s.Environment, s.ScenarioName, s.StepOrder })
            .HasDatabaseName("IX_OrchestrationSteps_Lookup");

        modelBuilder.Entity<OrchestrationStep>()
            .HasIndex(s => s.ActiveFlag)
            .HasDatabaseName("IX_OrchestrationSteps_Active");

        // A connection name is unique within its group, so two teams can each have "Partner.BaseUrl".
        // HasFilter(null) keeps SQL Server from skipping rows whose GroupId is NULL (not yet assigned).
        modelBuilder.Entity<ApiConfig>()
            .HasIndex(c => new { c.GroupId, c.ConfigKey })
            .IsUnique()
            .HasFilter(null)
            .HasDatabaseName("IX_ApiConfig_Group_Key");

        modelBuilder.Entity<OrchestrationStep>()
            .HasIndex(s => s.GroupId)
            .HasDatabaseName("IX_OrchestrationSteps_Group");

        modelBuilder.Entity<UserGroup>()
            .HasIndex(g => g.Name)
            .IsUnique()
            .HasDatabaseName("IX_UserGroups_Name");

        modelBuilder.Entity<AppUser>()
            .HasIndex(u => u.Username)
            .IsUnique()
            .HasDatabaseName("IX_AppUsers_Username");

        modelBuilder.Entity<UserSession>()
            .HasIndex(s => s.TokenHash)
            .IsUnique()
            .HasDatabaseName("IX_UserSessions_TokenHash");

        modelBuilder.Entity<OrchestrationRun>()
            .HasIndex(r => new { r.ProjectName, r.Environment, r.ScenarioName })
            .HasDatabaseName("IX_OrchestrationRuns_Scenario");

        modelBuilder.Entity<OrchestrationStep>()
            .Property(s => s.ActiveFlag)
            .HasMaxLength(1)
            .IsRequired();

        modelBuilder.Entity<OrchestrationRun>()
            .Property(r => r.ExecutionStartTime)
            .HasDefaultValueSql("CURRENT_TIMESTAMP");

        modelBuilder.Entity<ApiConfig>()
            .Property(c => c.CreatedAt)
            .HasDefaultValueSql("CURRENT_TIMESTAMP");
    }
}
