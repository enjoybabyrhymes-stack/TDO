using Microsoft.EntityFrameworkCore;

namespace Tdm.Orchestrator.Infrastructure.Persistence;

/// <summary>
/// Brings a database created by an earlier release up to date (EnsureCreated never alters existing tables).
/// Every statement is idempotent. The same statements are in database/003_AddPollingColumns.sql and
/// database/004_AddGroupsAndUsers.sql for databases managed by a DBA. Runs at startup in Development, or when
/// Database:AutoUpgrade is true.
/// </summary>
public static class SchemaUpgrade
{
    private static readonly string[] Statements =
    {
        // ---- 003: polling settings
        "IF COL_LENGTH('dbo.OrchestrationSteps','PollIntervalSeconds') IS NULL " +
        "ALTER TABLE dbo.OrchestrationSteps ADD PollIntervalSeconds INT NOT NULL CONSTRAINT DF_OrchestrationSteps_PollInterval DEFAULT 0",

        "IF COL_LENGTH('dbo.OrchestrationSteps','PollMaxWaitSeconds') IS NULL " +
        "ALTER TABLE dbo.OrchestrationSteps ADD PollMaxWaitSeconds INT NOT NULL CONSTRAINT DF_OrchestrationSteps_PollMaxWait DEFAULT 0",

        // ---- 004: groups, users, sessions
        "IF OBJECT_ID(N'dbo.UserGroups', N'U') IS NULL " +
        "CREATE TABLE dbo.UserGroups (" +
        "GroupId INT IDENTITY(1,1) NOT NULL, Name NVARCHAR(100) NOT NULL, Description NVARCHAR(500) NULL, " +
        "CreatedAt DATETIME2(7) NOT NULL, CONSTRAINT PK_UserGroups PRIMARY KEY CLUSTERED (GroupId))",

        "IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_UserGroups_Name' AND object_id = OBJECT_ID(N'dbo.UserGroups')) " +
        "CREATE UNIQUE NONCLUSTERED INDEX IX_UserGroups_Name ON dbo.UserGroups (Name)",

        "IF OBJECT_ID(N'dbo.AppUsers', N'U') IS NULL " +
        "CREATE TABLE dbo.AppUsers (" +
        "UserId INT IDENTITY(1,1) NOT NULL, Username NVARCHAR(100) NOT NULL, PasswordHash NVARCHAR(400) NOT NULL, " +
        "Role NVARCHAR(10) NOT NULL, GroupId INT NULL, Active BIT NOT NULL, CreatedAt DATETIME2(7) NOT NULL, " +
        "LastLoginAt DATETIME2(7) NULL, CONSTRAINT PK_AppUsers PRIMARY KEY CLUSTERED (UserId))",

        "IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AppUsers_Username' AND object_id = OBJECT_ID(N'dbo.AppUsers')) " +
        "CREATE UNIQUE NONCLUSTERED INDEX IX_AppUsers_Username ON dbo.AppUsers (Username)",

        "IF OBJECT_ID(N'dbo.UserSessions', N'U') IS NULL " +
        "CREATE TABLE dbo.UserSessions (" +
        "SessionId BIGINT IDENTITY(1,1) NOT NULL, TokenHash NVARCHAR(64) NOT NULL, UserId INT NOT NULL, " +
        "CreatedAt DATETIME2(7) NOT NULL, ExpiresAt DATETIME2(7) NOT NULL, CONSTRAINT PK_UserSessions PRIMARY KEY CLUSTERED (SessionId))",

        "IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_UserSessions_TokenHash' AND object_id = OBJECT_ID(N'dbo.UserSessions')) " +
        "CREATE UNIQUE NONCLUSTERED INDEX IX_UserSessions_TokenHash ON dbo.UserSessions (TokenHash)",

        "IF COL_LENGTH('dbo.OrchestrationSteps','GroupId') IS NULL ALTER TABLE dbo.OrchestrationSteps ADD GroupId INT NULL",

        "IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_OrchestrationSteps_Group' AND object_id = OBJECT_ID(N'dbo.OrchestrationSteps')) " +
        "CREATE NONCLUSTERED INDEX IX_OrchestrationSteps_Group ON dbo.OrchestrationSteps (GroupId)",

        "IF COL_LENGTH('dbo.ApiConfig','GroupId') IS NULL ALTER TABLE dbo.ApiConfig ADD GroupId INT NULL",

        // Run history groups the step rows of one execution.
        "IF COL_LENGTH('dbo.OrchestrationRuns','RunGroupId') IS NULL ALTER TABLE dbo.OrchestrationRuns ADD RunGroupId NVARCHAR(36) NULL",

        // A connection name is now unique per group instead of globally.
        "IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_ApiConfig_Key' AND object_id = OBJECT_ID(N'dbo.ApiConfig')) " +
        "DROP INDEX IX_ApiConfig_Key ON dbo.ApiConfig",

        "IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_ApiConfig_Group_Key' AND object_id = OBJECT_ID(N'dbo.ApiConfig')) " +
        "CREATE UNIQUE NONCLUSTERED INDEX IX_ApiConfig_Group_Key ON dbo.ApiConfig (GroupId, ConfigKey)"
    };

    public static void Apply(OrchestratorDbContext db)
    {
        foreach (var sql in Statements)
        {
            db.Database.ExecuteSqlRaw(sql);
        }
    }
}
