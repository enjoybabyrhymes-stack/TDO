using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Options;
using Tdm.Orchestrator.Application.Services;
using Tdm.Orchestrator.Domain.Constants;
using Tdm.Orchestrator.Options;

namespace Tdm.Orchestrator.Infrastructure.Middleware;

/// <summary>
/// Authorizes requests to the admin API and records who is calling. Two ways in:
///   1. "Authorization: Bearer token" from a username/password sign-in (an administrator, or a user of one group).
///   2. The configured admin key (header X-Admin-Key): full administrator access, used to bootstrap the first admin.
/// Anything else is rejected with 401.
/// </summary>
public class AdminKeyFilter : IAsyncAuthorizationFilter
{
    private readonly AdminOptions _options;
    private readonly ISessionService _sessions;
    private readonly CurrentUser _current;
    private readonly ILogger<AdminKeyFilter> _logger;

    public AdminKeyFilter(
        IOptions<AdminOptions> options,
        ISessionService sessions,
        CurrentUser current,
        ILogger<AdminKeyFilter> logger)
    {
        _options = options.Value;
        _sessions = sessions;
        _current = current;
        _logger = logger;
    }

    public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
    {
        var http = context.HttpContext;

        var authorization = http.Request.Headers.Authorization.ToString();
        if (authorization.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
        {
            var token = authorization.Substring(7).Trim();
            var user = token.Length == 0 ? null : await _sessions.FindUserAsync(token, http.RequestAborted);
            if (user == null)
            {
                Reject(context, StatusCodes.Status401Unauthorized, "Your session has expired. Please sign in again.");
                return;
            }

            var isAdmin = string.Equals(user.Role, AuthConstants.Role_Admin, StringComparison.OrdinalIgnoreCase);

            // A regular user without a group must never see anything (a null group would otherwise match unassigned data).
            if (!isAdmin && user.GroupId == null)
            {
                Reject(context, StatusCodes.Status403Forbidden, "Your account is not assigned to a group. Ask an administrator.");
                return;
            }

            _current.Set(user.UserId, user.Username, isAdmin, user.GroupId);
            return;
        }

        if (_options.ApiKeys.Length > 0 &&
            http.Request.Headers.TryGetValue(_options.HeaderName, out var provided) &&
            IsValidKey(provided.ToString()))
        {
            _current.Set(null, "admin key", true, null);
            return;
        }

        _logger.LogWarning(
            "Rejected admin request with missing or invalid credentials from {RemoteIp}",
            http.Connection.RemoteIpAddress);
        Reject(context, StatusCodes.Status401Unauthorized, "Invalid or missing credentials.");
    }

    private static void Reject(AuthorizationFilterContext context, int status, string message)
    {
        context.Result = new ObjectResult(new { error = message }) { StatusCode = status };
    }

    /// <summary>
    /// Compares SHA-256 hashes of the keys in constant time, so neither the key content
    /// nor its length can be inferred from response timing.
    /// </summary>
    private bool IsValidKey(string provided)
    {
        var providedHash = SHA256.HashData(Encoding.UTF8.GetBytes(provided));
        var matched = false;
        foreach (var key in _options.ApiKeys)
        {
            var keyHash = SHA256.HashData(Encoding.UTF8.GetBytes(key));
            matched |= CryptographicOperations.FixedTimeEquals(providedHash, keyHash);
        }

        return matched;
    }
}
