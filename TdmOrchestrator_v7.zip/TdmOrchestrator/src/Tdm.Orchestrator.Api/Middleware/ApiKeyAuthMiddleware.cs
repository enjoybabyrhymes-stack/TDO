using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Options;
using Tdm.Orchestrator.Options;

namespace Tdm.Orchestrator.Infrastructure.Middleware;

/// <summary>
/// Minimal API-key authentication. This is a v1 gate — enough to stop anonymous
/// internet traffic from running workflows — not a substitute for real per-user/
/// per-project authorization. See PRODUCTION_HARDENING.md for the upgrade path
/// (OAuth2/OIDC, per-project scoping) recommended before wide rollout.
/// </summary>
public class ApiKeyAuthMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ApiKeyAuthMiddleware> _logger;

    // Paths that must stay reachable without a key — load balancers / k8s probes
    // and the Swagger UI (Swagger itself is already Development-only in Program.cs).
    private static readonly string[] AnonymousPathPrefixes =
    {
        "/health/live",
        "/health/ready",
        "/swagger",
        // The admin API is protected by its own key (AdminKeyFilter), not the run key.
        "/api/v1/admin",
        // The admin web page is static and holds no data; it is also served by UseStaticFiles before this middleware.
        "/admin-ui"
    };

    public ApiKeyAuthMiddleware(RequestDelegate next, ILogger<ApiKeyAuthMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context, IOptions<ApiKeyOptions> options)
    {
        var path = context.Request.Path.Value ?? string.Empty;
        if (AnonymousPathPrefixes.Any(p => path.StartsWith(p, StringComparison.OrdinalIgnoreCase)))
        {
            await _next(context);
            return;
        }

        var apiKeyOptions = options.Value;

        // Fail CLOSED: if nobody configured any valid keys, reject everything rather
        // than silently running unauthenticated. This is intentional — it forces
        // whoever deploys this to a new environment to make an explicit decision.
        if (apiKeyOptions.ValidKeys.Length == 0)
        {
            _logger.LogError(
                "No API keys configured (ApiKey:ValidKeys is empty) — rejecting all requests. " +
                "Set the ApiKey__ValidKeys__0 environment variable (or your secrets manager equivalent) before this deployment can serve traffic.");
            context.Response.StatusCode = StatusCodes.Status503ServiceUnavailable;
            await context.Response.WriteAsJsonAsync(new { error = "API authentication is not configured for this environment." });
            return;
        }

        if (!context.Request.Headers.TryGetValue(apiKeyOptions.HeaderName, out var providedKeyValues))
        {
            context.Response.StatusCode = StatusCodes.Status401Unauthorized;
            await context.Response.WriteAsJsonAsync(new { error = $"Missing '{apiKeyOptions.HeaderName}' header." });
            return;
        }

        var providedKey = providedKeyValues.ToString();
        var isValid = apiKeyOptions.ValidKeys.Any(validKey => FixedTimeEquals(providedKey, validKey));

        if (!isValid)
        {
            _logger.LogWarning("Rejected request with an invalid API key from {RemoteIp}", context.Connection.RemoteIpAddress);
            context.Response.StatusCode = StatusCodes.Status401Unauthorized;
            await context.Response.WriteAsJsonAsync(new { error = "Invalid API key." });
            return;
        }

        await _next(context);
    }

    /// <summary>
    /// Constant-time string comparison so an attacker can't infer the correct key
    /// character-by-character by measuring response time differences.
    /// </summary>
    private static bool FixedTimeEquals(string a, string b)
    {
        var aBytes = Encoding.UTF8.GetBytes(a);
        var bBytes = Encoding.UTF8.GetBytes(b);

        if (aBytes.Length != bBytes.Length)
        {
            // Still perform a fixed-time comparison of matching length so the
            // "lengths differ" case doesn't itself leak timing information.
            CryptographicOperations.FixedTimeEquals(aBytes, aBytes);
            return false;
        }

        return CryptographicOperations.FixedTimeEquals(aBytes, bBytes);
    }
}
