using System.Net;
using System.Text.Json;
using Tdm.Orchestrator.Domain.Exceptions;

namespace Tdm.Orchestrator.Infrastructure.Middleware;

/// <summary>Centralized exception handling middleware implementing ProblemDetails.</summary>
public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;

    public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (OrchestrationException ex)
        {
            _logger.LogWarning(ex, "Orchestration error: {ErrorCode}", ex.ErrorCode ?? "UNKNOWN");
            context.Response.StatusCode = (int)ex.StatusCode;
            context.Response.ContentType = "application/problem+json";
            
            var problemDetails = new
            {
                type = "https://tdm-orchestrator.example.com/errors/" + (ex.ErrorCode ?? "orchestration-error"),
                title = ex.GetType().Name,
                status = (int)ex.StatusCode,
                detail = ex.Message
            };
            
            await context.Response.WriteAsJsonAsync(problemDetails);
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Downstream HTTP call failed");
            context.Response.StatusCode = (int)HttpStatusCode.BadGateway;
            context.Response.ContentType = "application/problem+json";
            
            var problemDetails = new
            {
                type = "https://tdm-orchestrator.example.com/errors/downstream-error",
                title = "Downstream API Error",
                status = (int)HttpStatusCode.BadGateway,
                detail = "External API call failed. Check orchestration configuration and downstream service."
            };
            
            await context.Response.WriteAsJsonAsync(problemDetails);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unhandled exception");
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            context.Response.ContentType = "application/problem+json";
            
            var problemDetails = new
            {
                type = "https://tdm-orchestrator.example.com/errors/internal-server-error",
                title = "Internal Server Error",
                status = (int)HttpStatusCode.InternalServerError,
                detail = "An unexpected error occurred. Please contact support with the request timestamp."
            };
            
            await context.Response.WriteAsJsonAsync(problemDetails);
        }
    }
}
