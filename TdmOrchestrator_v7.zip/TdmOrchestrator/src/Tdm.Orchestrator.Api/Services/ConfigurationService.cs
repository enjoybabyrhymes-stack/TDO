using Tdm.Orchestrator.Application.Interfaces;
using Tdm.Orchestrator.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Tdm.Orchestrator.Application.Services;

/// <summary>Retrieves orchestration configuration from the database.</summary>
public class ConfigurationService : IConfigurationService
{
    private readonly OrchestratorDbContext _db;
    private readonly ILogger<ConfigurationService> _logger;

    public ConfigurationService(OrchestratorDbContext db, ILogger<ConfigurationService> logger)
    {
        _db = db;
        _logger = logger;
    }

    public async Task<string?> GetConfigValueAsync(string? key, int? groupId, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(key))
        {
            return null;
        }

        return await _db.ApiConfigs
            .AsNoTracking()
            .Where(c => c.ConfigKey == key && c.GroupId == groupId)
            .Select(c => c.ConfigValue)
            .FirstOrDefaultAsync(cancellationToken);
    }

    public async Task<Dictionary<string, string>> GetAllConfigAsync(int? groupId, CancellationToken cancellationToken = default)
    {
        // Only the scenario's own group: a template can never read another team's connections or secrets.
        return await _db.ApiConfigs
            .AsNoTracking()
            .Where(c => c.GroupId == groupId)
            .ToDictionaryAsync(c => c.ConfigKey, c => c.ConfigValue, cancellationToken);
    }
}
