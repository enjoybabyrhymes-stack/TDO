using System.Net;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using Tdm.Orchestrator.Application.DTOs;
using Tdm.Orchestrator.Application.Interfaces;
using Tdm.Orchestrator.Domain.Constants;
using Tdm.Orchestrator.Domain.Entities;
using Tdm.Orchestrator.Domain.Exceptions;
using Tdm.Orchestrator.Infrastructure.Persistence;

namespace Tdm.Orchestrator.Application.Services;

/// <summary>
/// Implements the management operations used by the admin UI. All changes are written to the
/// same tables the orchestration engine reads, so an edit takes effect on the next run.
/// </summary>
public class ScenarioAdminService : IScenarioAdminService
{
    private const string SecretMask = "********";

    private static readonly string[] AllowedHttpMethods = { "GET", "POST", "PUT", "PATCH", "DELETE" };

    // Names end up in a URL path (/run/{project}/{environment}/{scenario}), so keep them URL-safe.
    private static readonly Regex NamePattern = new(@"^[A-Za-z0-9_.\-]+$", RegexOptions.Compiled);

    // Connection keys whose values must never be returned to the browser.
    private static readonly Regex SecretKeyPattern =
        new("(key|secret|token|password|pwd|credential)", RegexOptions.Compiled | RegexOptions.IgnoreCase);

    // $step2, {step2.id} and "step2.field" style references.
    private static readonly Regex StepReferencePattern = new(@"\bstep(\d+)(?=[.\[])", RegexOptions.Compiled);

    // $input.x, {input.x} and "input.x" (used inside $when conditions).
    private static readonly Regex InputReferencePattern =
        new(@"(?:\$|\{|"")input\.([A-Za-z_][A-Za-z0-9_]*)", RegexOptions.Compiled);

    private readonly OrchestratorDbContext _db;
    private readonly ICurrentUser _user;
    private readonly ILogger<ScenarioAdminService> _logger;

    public ScenarioAdminService(OrchestratorDbContext db, ICurrentUser user, ILogger<ScenarioAdminService> logger)
    {
        _db = db;
        _user = user;
        _logger = logger;
    }

    // ---------------------------------------------------------------------
    // Connections (ApiConfig)
    // ---------------------------------------------------------------------

    public async Task<IReadOnlyList<ConfigItemDto>> GetConfigsAsync(CancellationToken cancellationToken = default)
    {
        var rows = await ScopedConfigs().AsNoTracking().OrderBy(c => c.ConfigKey).ToListAsync(cancellationToken);
        var groups = await GroupNamesAsync(cancellationToken);
        return rows.Select(c => ToConfigDto(c, groups)).ToList();
    }

    public async Task<ConfigItemDto> CreateConfigAsync(ConfigSaveDto dto, CancellationToken cancellationToken = default)
    {
        var key = ValidateConfigKey(dto.ConfigKey);
        if (string.IsNullOrWhiteSpace(dto.ConfigValue))
        {
            throw new ValidationException("A value is required.", "CONFIG_VALUE_REQUIRED");
        }

        // Administrators pick the owning group; everyone else always creates in their own group.
        var groupId = _user.IsAdmin
            ? await RequireExistingGroupAsync(dto.GroupId, cancellationToken)
            : _user.GroupId;

        if (await _db.ApiConfigs.AnyAsync(c => c.ConfigKey == key && c.GroupId == groupId, cancellationToken))
        {
            throw new OrchestrationException(
                $"A connection named '{key}' already exists.", HttpStatusCode.Conflict, "CONFIG_EXISTS");
        }

        var now = DateTime.UtcNow;
        var entity = new ApiConfig
        {
            GroupId = groupId,
            ConfigKey = key,
            ConfigValue = dto.ConfigValue.Trim(),
            Description = NullIfBlank(dto.Description),
            CreatedAt = now,
            UpdatedAt = now
        };

        _db.ApiConfigs.Add(entity);
        await _db.SaveChangesAsync(cancellationToken);
        _logger.LogInformation("{User} created connection {ConfigKey}", _user.Name, key);
        return ToConfigDto(entity, await GroupNamesAsync(cancellationToken));
    }

    public async Task<ConfigItemDto> UpdateConfigAsync(int id, ConfigSaveDto dto, CancellationToken cancellationToken = default)
    {
        var entity = await ScopedConfigs().FirstOrDefaultAsync(c => c.Id == id, cancellationToken)
            ?? throw NotFound("Connection not found.");

        var key = ValidateConfigKey(dto.ConfigKey);

        // Only an administrator can move a connection to another group (and only by naming one).
        var targetGroup = entity.GroupId;
        if (_user.IsAdmin && dto.GroupId.HasValue)
        {
            targetGroup = await RequireExistingGroupAsync(dto.GroupId, cancellationToken);
        }

        if (await _db.ApiConfigs.AnyAsync(c => c.ConfigKey == key && c.GroupId == targetGroup && c.Id != id, cancellationToken))
        {
            throw new OrchestrationException(
                $"A connection named '{key}' already exists.", HttpStatusCode.Conflict, "CONFIG_EXISTS");
        }

        // An empty value (or the mask echoed back by the UI) keeps what is stored.
        var keepValue = string.IsNullOrWhiteSpace(dto.ConfigValue) || dto.ConfigValue == SecretMask;

        entity.ConfigKey = key;
        entity.GroupId = targetGroup;
        if (!keepValue)
        {
            entity.ConfigValue = dto.ConfigValue!.Trim();
        }

        entity.Description = NullIfBlank(dto.Description);
        entity.UpdatedAt = DateTime.UtcNow;

        await _db.SaveChangesAsync(cancellationToken);
        _logger.LogInformation("{User} updated connection {ConfigKey}", _user.Name, key);
        return ToConfigDto(entity, await GroupNamesAsync(cancellationToken));
    }

    public async Task DeleteConfigAsync(int id, CancellationToken cancellationToken = default)
    {
        var entity = await ScopedConfigs().FirstOrDefaultAsync(c => c.Id == id, cancellationToken)
            ?? throw NotFound("Connection not found.");

        var entityGroup = entity.GroupId;
        var inUse = await _db.OrchestrationSteps
            .AnyAsync(s => s.BaseUrlConfigKey == entity.ConfigKey && s.GroupId == entityGroup, cancellationToken);
        if (inUse)
        {
            throw new OrchestrationException(
                $"'{entity.ConfigKey}' is used as the base URL of one or more steps. Change those steps first.",
                HttpStatusCode.Conflict, "CONFIG_IN_USE");
        }

        _db.ApiConfigs.Remove(entity);
        await _db.SaveChangesAsync(cancellationToken);
        _logger.LogInformation("Admin deleted connection {ConfigKey}", entity.ConfigKey);
    }

    // ---------------------------------------------------------------------
    // Scenarios and steps (OrchestrationSteps)
    // ---------------------------------------------------------------------

    public async Task<IReadOnlyList<ScenarioSummaryDto>> GetScenariosAsync(CancellationToken cancellationToken = default)
    {
        var scenarios = await ScopedSteps()
            .AsNoTracking()
            .GroupBy(s => new { s.ProjectName, s.Environment, s.ScenarioName, s.GroupId })
            .Select(g => new ScenarioSummaryDto
            {
                ProjectName = g.Key.ProjectName,
                Environment = g.Key.Environment,
                ScenarioName = g.Key.ScenarioName,
                GroupId = g.Key.GroupId,
                StepCount = g.Count(),
                ActiveStepCount = g.Count(x => x.ActiveFlag == OrchestrationConstants.ActiveFlag_Active),
                UpdatedAt = g.Max(x => x.UpdatedAt)
            })
            .OrderBy(s => s.ProjectName).ThenBy(s => s.Environment).ThenBy(s => s.ScenarioName)
            .ToListAsync(cancellationToken);

        var groups = await GroupNamesAsync(cancellationToken);
        foreach (var scenario in scenarios)
        {
            scenario.GroupName = scenario.GroupId.HasValue && groups.TryGetValue(scenario.GroupId.Value, out var name)
                ? name
                : null;
        }

        return scenarios;
    }

    public async Task<IReadOnlyList<StepDto>> GetStepsAsync(
        string project, string environment, string scenario, CancellationToken cancellationToken = default)
    {
        var rows = await LoadSteps(project, environment, scenario).AsNoTracking().ToListAsync(cancellationToken);
        return rows.Select(ToStepDto).ToList();
    }

    public async Task<StepDto> CreateStepAsync(StepDto dto, CancellationToken cancellationToken = default)
    {
        dto.ProjectName = ValidateName(dto.ProjectName, "Project");
        dto.Environment = ValidateName(dto.Environment, "Environment");
        dto.ScenarioName = ValidateName(dto.ScenarioName, "Scenario");

        var groupId = await ResolveStepGroupAsync(dto, null, null, false, cancellationToken);
        await ValidateStepAsync(dto, groupId, cancellationToken);
        await EnsureStepOrderFreeAsync(dto, null, cancellationToken);

        var now = DateTime.UtcNow;
        var entity = new OrchestrationStep { CreatedAt = now, UpdatedAt = now, GroupId = groupId };
        ApplyStep(entity, dto);

        _db.OrchestrationSteps.Add(entity);
        await _db.SaveChangesAsync(cancellationToken);
        _logger.LogInformation(
            "Admin created step {StepOrder} in {Project}/{Environment}/{Scenario}",
            entity.StepOrder, entity.ProjectName, entity.Environment, entity.ScenarioName);
        return ToStepDto(entity);
    }

    public async Task<StepDto> UpdateStepAsync(int id, StepDto dto, CancellationToken cancellationToken = default)
    {
        var entity = await ScopedSteps().FirstOrDefaultAsync(s => s.ServiceId == id, cancellationToken)
            ?? throw NotFound("Step not found.");

        dto.ProjectName = ValidateName(dto.ProjectName, "Project");
        dto.Environment = ValidateName(dto.Environment, "Environment");
        dto.ScenarioName = ValidateName(dto.ScenarioName, "Scenario");

        // A step never changes group by being edited; it only has to stay clear of another group's scenario names.
        var groupId = await ResolveStepGroupAsync(dto, id, entity.GroupId, true, cancellationToken);
        await ValidateStepAsync(dto, groupId, cancellationToken);
        await EnsureStepOrderFreeAsync(dto, id, cancellationToken);

        ApplyStep(entity, dto);
        entity.UpdatedAt = DateTime.UtcNow;

        await _db.SaveChangesAsync(cancellationToken);
        _logger.LogInformation(
            "Admin updated step {ServiceId} ({Project}/{Environment}/{Scenario})",
            entity.ServiceId, entity.ProjectName, entity.Environment, entity.ScenarioName);
        return ToStepDto(entity);
    }

    public async Task DeleteStepAsync(int id, CancellationToken cancellationToken = default)
    {
        var entity = await ScopedSteps().FirstOrDefaultAsync(s => s.ServiceId == id, cancellationToken)
            ?? throw NotFound("Step not found.");

        // The scenario's other steps close the gap: deleting step 1 turns step 2 into step 1, and so on.
        var siblings = await _db.OrchestrationSteps
            .Where(s => s.ProjectName == entity.ProjectName && s.Environment == entity.Environment && s.ScenarioName == entity.ScenarioName)
            .ToListAsync(cancellationToken);
        siblings.Remove(entity);
        _db.OrchestrationSteps.Remove(entity);

        var remaining = siblings.OrderBy(s => s.StepOrder).ThenBy(s => s.ServiceId).ToList();
        var map = new Dictionary<int, int>();
        for (var i = 0; i < remaining.Count; i++)
        {
            map.TryAdd(remaining[i].StepOrder, i + 1);
        }

        ApplyStepOrderMap(remaining, map);
        for (var i = 0; i < remaining.Count; i++)
        {
            if (remaining[i].StepOrder != i + 1)
            {
                remaining[i].StepOrder = i + 1;
                remaining[i].UpdatedAt = DateTime.UtcNow;
            }
        }

        await _db.SaveChangesAsync(cancellationToken);
        _logger.LogInformation("Admin deleted step {ServiceId} and renumbered {Count} later step(s)", id, remaining.Count);
    }

    /// <summary>Swaps a step with its neighbour (up = earlier). References to the two steps follow them.</summary>
    public async Task MoveStepAsync(int id, bool up, CancellationToken cancellationToken = default)
    {
        var entity = await ScopedSteps().FirstOrDefaultAsync(s => s.ServiceId == id, cancellationToken)
            ?? throw NotFound("Step not found.");

        var siblings = await _db.OrchestrationSteps
            .Where(s => s.ProjectName == entity.ProjectName && s.Environment == entity.Environment && s.ScenarioName == entity.ScenarioName)
            .ToListAsync(cancellationToken);
        var ordered = siblings.OrderBy(s => s.StepOrder).ThenBy(s => s.ServiceId).ToList();
        var index = ordered.IndexOf(entity);
        var otherIndex = up ? index - 1 : index + 1;
        if (otherIndex < 0 || otherIndex >= ordered.Count)
        {
            return;
        }

        var other = ordered[otherIndex];
        if (other.StepOrder == entity.StepOrder)
        {
            throw new ValidationException("Two steps have the same order number. Give each step its own number first.", "STEP_ORDER_DUPLICATE");
        }

        var a = entity.StepOrder;
        var b = other.StepOrder;
        var map = siblings.Select(s => s.StepOrder).Distinct().ToDictionary(o => o, o => o);
        map[a] = b;
        map[b] = a;

        ApplyStepOrderMap(siblings, map);
        entity.StepOrder = b;
        other.StepOrder = a;
        entity.UpdatedAt = other.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync(cancellationToken);
    }

    /// <summary>A scenario cannot have two steps with the same order number.</summary>
    private async Task EnsureStepOrderFreeAsync(StepDto dto, int? excludeServiceId, CancellationToken cancellationToken)
    {
        var taken = await _db.OrchestrationSteps.AsNoTracking().AnyAsync(s =>
            s.ProjectName == dto.ProjectName && s.Environment == dto.Environment && s.ScenarioName == dto.ScenarioName &&
            s.StepOrder == dto.StepOrder && s.ServiceId != (excludeServiceId ?? 0), cancellationToken);
        if (taken)
        {
            throw new ValidationException(
                $"This scenario already has a step {dto.StepOrder}. Choose a number that is not used.", "STEP_ORDER_DUPLICATE");
        }
    }

    /// <summary>
    /// Rewrites step references ($step2.id, {step2.id}, "step2.status") in the given steps using old -> new order numbers.
    /// A reference to an order that is not in the map (for example a deleted step) becomes step0, which never exists,
    /// so it shows up as a broken reference instead of silently pointing at another step.
    /// </summary>
    private static void ApplyStepOrderMap(IEnumerable<OrchestrationStep> steps, IReadOnlyDictionary<int, int> map)
    {
        string? Rewrite(string? text) => string.IsNullOrEmpty(text)
            ? text
            : StepReferencePattern.Replace(text, m =>
                "step" + (map.TryGetValue(int.Parse(m.Groups[1].Value), out var next) ? next : 0));

        foreach (var s in steps)
        {
            s.Endpoint = Rewrite(s.Endpoint) ?? string.Empty;
            s.InputParamMap = Rewrite(s.InputParamMap);
            if (!string.Equals(s.StepType, OrchestrationConstants.StepType_RestApi, StringComparison.OrdinalIgnoreCase))
            {
                s.OutputParamMap = Rewrite(s.OutputParamMap);
            }
        }
    }

    public async Task CloneScenarioAsync(CloneScenarioDto dto, CancellationToken cancellationToken = default)
    {
        var targetProject = ValidateName(dto.TargetProjectName, "Target project");
        var targetEnvironment = ValidateName(dto.TargetEnvironment, "Target environment");
        var targetScenario = ValidateName(dto.TargetScenarioName, "Target scenario");

        var source = await LoadSteps(dto.ProjectName, dto.Environment, dto.ScenarioName)
            .AsNoTracking().ToListAsync(cancellationToken);
        if (source.Count == 0)
        {
            throw NotFound("The scenario to copy has no steps.");
        }

        // The scenario name must be free across ALL groups: the run URL does not say which group it is for.
        var targetExists = await _db.OrchestrationSteps
            .AnyAsync(s => s.ProjectName == targetProject && s.Environment == targetEnvironment &&
                           s.ScenarioName == targetScenario, cancellationToken);
        if (targetExists)
        {
            throw new OrchestrationException(
                "The target scenario already exists. Choose a different name or delete it first.",
                HttpStatusCode.Conflict, "SCENARIO_EXISTS");
        }

        // The copy stays in the source group unless an administrator names another one.
        var targetGroupId = source[0].GroupId;
        if (_user.IsAdmin && dto.TargetGroupId.HasValue)
        {
            targetGroupId = await RequireExistingGroupAsync(dto.TargetGroupId, cancellationToken);
        }

        var now = DateTime.UtcNow;
        foreach (var step in source)
        {
            _db.OrchestrationSteps.Add(new OrchestrationStep
            {
                GroupId = targetGroupId,
                ProjectName = targetProject,
                Environment = targetEnvironment,
                ScenarioName = targetScenario,
                StepOrder = step.StepOrder,
                StepDescription = step.StepDescription,
                StepType = step.StepType,
                BaseUrlConfigKey = step.BaseUrlConfigKey,
                Endpoint = step.Endpoint,
                HttpMethod = step.HttpMethod,
                InputParamMap = step.InputParamMap,
                OutputParamMap = step.OutputParamMap,
                RetryCount = step.RetryCount,
                TimeoutSeconds = step.TimeoutSeconds,
                WaitTimeSeconds = step.WaitTimeSeconds,
                PollIntervalSeconds = step.PollIntervalSeconds,
                PollMaxWaitSeconds = step.PollMaxWaitSeconds,
                ActiveFlag = step.ActiveFlag,
                CreatedAt = now,
                UpdatedAt = now
            });
        }

        await _db.SaveChangesAsync(cancellationToken);
        _logger.LogInformation(
            "Admin cloned {Project}/{Environment}/{Scenario} to {TargetProject}/{TargetEnvironment}/{TargetScenario}",
            dto.ProjectName, dto.Environment, dto.ScenarioName, targetProject, targetEnvironment, targetScenario);
    }

    public async Task SetScenarioActiveAsync(
        string project, string environment, string scenario, bool active, CancellationToken cancellationToken = default)
    {
        var steps = await LoadSteps(project, environment, scenario).ToListAsync(cancellationToken);
        if (steps.Count == 0)
        {
            throw NotFound("Scenario not found.");
        }

        var flag = active ? OrchestrationConstants.ActiveFlag_Active : OrchestrationConstants.ActiveFlag_Inactive;
        var now = DateTime.UtcNow;
        foreach (var step in steps)
        {
            step.ActiveFlag = flag;
            step.UpdatedAt = now;
        }

        await _db.SaveChangesAsync(cancellationToken);
        _logger.LogInformation(
            "Admin set {Project}/{Environment}/{Scenario} active={Active}", project, environment, scenario, active);
    }

    public async Task DeleteScenarioAsync(
        string project, string environment, string scenario, CancellationToken cancellationToken = default)
    {
        var steps = await LoadSteps(project, environment, scenario).ToListAsync(cancellationToken);
        if (steps.Count == 0)
        {
            throw NotFound("Scenario not found.");
        }

        _db.OrchestrationSteps.RemoveRange(steps);
        await _db.SaveChangesAsync(cancellationToken);
        _logger.LogInformation(
            "Admin deleted scenario {Project}/{Environment}/{Scenario} ({Count} steps)",
            project, environment, scenario, steps.Count);
    }

    // ---------------------------------------------------------------------
    // Validation and Postman export
    // ---------------------------------------------------------------------

    public async Task<IReadOnlyList<ValidationIssueDto>> ValidateScenarioAsync(
        string project, string environment, string scenario, CancellationToken cancellationToken = default)
    {
        var all = await LoadSteps(project, environment, scenario).AsNoTracking().ToListAsync(cancellationToken);
        if (all.Count == 0)
        {
            throw NotFound("Scenario not found.");
        }

        var issues = new List<ValidationIssueDto>();
        var steps = all
            .Where(s => s.ActiveFlag == OrchestrationConstants.ActiveFlag_Active)
            .OrderBy(s => s.StepOrder)
            .ToList();

        if (steps.Count == 0)
        {
            issues.Add(Issue("warning", null,
                "The scenario is disabled (no active steps). Run requests will report that the scenario does not exist."));
            return issues;
        }

        var scenarioGroupId = all[0].GroupId;
        var configKeys = (await _db.ApiConfigs.AsNoTracking()
                .Where(c => c.GroupId == scenarioGroupId)
                .Select(c => c.ConfigKey)
                .ToListAsync(cancellationToken))
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        foreach (var duplicate in steps.GroupBy(s => s.StepOrder).Where(g => g.Count() > 1))
        {
            issues.Add(Issue("error", duplicate.Key,
                $"{duplicate.Count()} active steps share step order {duplicate.Key}. Each step needs its own order."));
        }

        var orders = steps.Select(s => s.StepOrder).Distinct().OrderBy(o => o).ToList();
        for (var i = 0; i < orders.Count; i++)
        {
            if (orders[i] != i + 1)
            {
                issues.Add(Issue("warning", null,
                    "Step orders are not 1, 2, 3 … without gaps. The run still works in order, but gaps make step references easy to get wrong."));
                break;
            }
        }

        var activeOrders = steps.Select(s => s.StepOrder).ToHashSet();
        double worstCaseSeconds = 0;

        foreach (var step in steps)
        {
            var order = step.StepOrder;
            var isRest = string.Equals(step.StepType, OrchestrationConstants.StepType_RestApi, StringComparison.OrdinalIgnoreCase);
            var isConsolidate = string.Equals(step.StepType, OrchestrationConstants.StepType_Consolidate, StringComparison.OrdinalIgnoreCase);

            if (!isRest && !isConsolidate)
            {
                issues.Add(Issue("error", order, $"Unknown step type '{step.StepType}'."));
                continue;
            }

            if (isRest)
            {
                if (string.IsNullOrWhiteSpace(step.Endpoint))
                {
                    issues.Add(Issue("error", order, "The endpoint is empty."));
                }

                if (string.IsNullOrWhiteSpace(step.HttpMethod) ||
                    !AllowedHttpMethods.Contains(step.HttpMethod.ToUpperInvariant()))
                {
                    issues.Add(Issue("error", order, "The HTTP method must be GET, POST, PUT, PATCH or DELETE."));
                }

                if (!string.IsNullOrWhiteSpace(step.BaseUrlConfigKey))
                {
                    if (!configKeys.Contains(step.BaseUrlConfigKey))
                    {
                        issues.Add(Issue("error", order,
                            $"The base URL '{step.BaseUrlConfigKey}' does not exist under Connections."));
                    }
                }
                else if (!string.IsNullOrWhiteSpace(step.Endpoint) &&
                         !step.Endpoint.StartsWith("http", StringComparison.OrdinalIgnoreCase))
                {
                    issues.Add(Issue("error", order,
                        "No base URL is selected and the endpoint is not a full http(s) address."));
                }
            }
            else if (string.IsNullOrWhiteSpace(step.OutputParamMap))
            {
                issues.Add(Issue("error", order, "A consolidate step needs an output template."));
            }

            CheckJson(step.InputParamMap, "request template", order, issues);
            CheckJson(step.OutputParamMap, "output template", order, issues);

            var text = string.Join("\n", step.Endpoint, step.InputParamMap, step.OutputParamMap);
            foreach (var number in StepReferencePattern.Matches(text)
                         .Select(m => int.Parse(m.Groups[1].Value)).Distinct().OrderBy(n => n))
            {
                if (number >= order)
                {
                    issues.Add(Issue("error", order,
                        $"It refers to step {number}, which has not run yet at this point."));
                }
                else if (!activeOrders.Contains(number))
                {
                    issues.Add(Issue("error", order,
                        $"It refers to step {number}, which does not exist or is disabled."));
                }
            }

            if (step.TimeoutSeconds <= 0)
            {
                issues.Add(Issue("warning", order, "The timeout is not positive; a default of 30 seconds is used."));
            }

            var polls = !string.IsNullOrWhiteSpace(step.InputParamMap) && step.InputParamMap.Contains("\"poll\"");
            if (step.PollIntervalSeconds > 0)
            {
                if (!HasPollCondition(step.InputParamMap))
                {
                    issues.Add(Issue("error", order,
                        "Polling is set up (interval and give-up time) but the request template has no poll condition."));
                }

                // Pre-step wait, then the first call, then one call per interval until the give-up time.
                var checks = Math.Max(1, step.PollMaxWaitSeconds / step.PollIntervalSeconds) + 1;
                worstCaseSeconds += step.WaitTimeSeconds + step.PollMaxWaitSeconds + (double)step.TimeoutSeconds * checks;
            }
            else
            {
                worstCaseSeconds += polls
                    ? (double)step.WaitTimeSeconds * step.RetryCount + step.TimeoutSeconds * (step.RetryCount + 1)
                    : step.WaitTimeSeconds + (double)step.TimeoutSeconds * (step.RetryCount + 1);
            }
        }

        if (worstCaseSeconds > 200)
        {
            issues.Add(Issue("warning", null,
                $"In the worst case this scenario can run for about {Math.Round(worstCaseSeconds)} seconds. " +
                "Azure's front end ends idle HTTP requests at roughly 230 seconds, so the caller may time out."));
        }

        return issues;
    }

    public async Task<PostmanExportDto> BuildPostmanExportAsync(
        string project, string environment, string scenario, CancellationToken cancellationToken = default)
    {
        var steps = await LoadSteps(project, environment, scenario)
            .AsNoTracking()
            .Where(s => s.ActiveFlag == OrchestrationConstants.ActiveFlag_Active)
            .ToListAsync(cancellationToken);
        if (steps.Count == 0)
        {
            throw NotFound("The scenario has no active steps.");
        }

        var inputs = new List<string>();
        foreach (var step in steps.OrderBy(s => s.StepOrder))
        {
            var text = string.Join("\n", step.Endpoint, step.InputParamMap, step.OutputParamMap);
            foreach (Match match in InputReferencePattern.Matches(text))
            {
                var name = match.Groups[1].Value;
                if (!inputs.Contains(name))
                {
                    inputs.Add(name);
                }
            }
        }

        var inputData = new JsonObject();
        foreach (var name in inputs)
        {
            inputData[name] = "";
        }

        var body = new JsonObject
        {
            ["userId"] = "",
            ["testCaseId"] = "",
            ["inputData"] = inputData
        };

        var runPath =
            $"/api/v1/orchestrator/run/{Uri.EscapeDataString(project)}/{Uri.EscapeDataString(environment)}/{Uri.EscapeDataString(scenario)}";

        var collection = new JsonObject
        {
            ["info"] = new JsonObject
            {
                ["name"] = $"TDM Orchestrator - {project} / {environment} / {scenario}",
                ["schema"] = "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
            },
            ["variable"] = new JsonArray(
                new JsonObject { ["key"] = "baseUrl", ["value"] = "https://localhost:5001" },
                new JsonObject { ["key"] = "apiKey", ["value"] = "" }),
            ["item"] = new JsonArray(new JsonObject
            {
                ["name"] = $"Run {scenario}",
                ["request"] = new JsonObject
                {
                    ["method"] = "POST",
                    ["header"] = new JsonArray(
                        new JsonObject { ["key"] = "X-Api-Key", ["value"] = "{{apiKey}}" },
                        new JsonObject { ["key"] = "Content-Type", ["value"] = "application/json" }),
                    ["body"] = new JsonObject
                    {
                        ["mode"] = "raw",
                        ["raw"] = body.ToJsonString(new JsonSerializerOptions { WriteIndented = true }),
                        ["options"] = new JsonObject { ["raw"] = new JsonObject { ["language"] = "json" } }
                    },
                    ["url"] = new JsonObject
                    {
                        ["raw"] = "{{baseUrl}}" + runPath,
                        ["host"] = new JsonArray("{{baseUrl}}"),
                        ["path"] = new JsonArray(
                            "api", "v1", "orchestrator", "run", project, environment, scenario)
                    }
                }
            })
        };

        return new PostmanExportDto
        {
            Collection = collection,
            SampleBody = body,
            RequiredInputs = inputs,
            RunPath = runPath
        };
    }

    // ---------------------------------------------------------------------
    // Run history
    // ---------------------------------------------------------------------

    public async Task<IReadOnlyList<RunItemDto>> GetRunsAsync(
        string? project, string? environment, string? scenario, int take, CancellationToken cancellationToken = default)
    {
        var query = _db.OrchestrationRuns.AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(project))
        {
            query = query.Where(r => r.ProjectName == project);
        }

        if (!string.IsNullOrWhiteSpace(environment))
        {
            query = query.Where(r => r.Environment == environment);
        }

        if (!string.IsNullOrWhiteSpace(scenario))
        {
            query = query.Where(r => r.ScenarioName == scenario);
        }

        var limit = Math.Clamp(take, 1, 200);
        if (!_user.IsAdmin)
        {
            // Only runs of scenarios that belong to the caller's group.
            var group = _user.GroupId;
            query = query.Where(r => _db.OrchestrationSteps.Any(s =>
                s.GroupId == group &&
                s.ProjectName == r.ProjectName &&
                s.Environment == r.Environment &&
                s.ScenarioName == r.ScenarioName));
        }

        var rows = await query.OrderByDescending(r => r.RunId).Take(limit).ToListAsync(cancellationToken);

        return rows.Select(r => new RunItemDto
        {
            RunId = r.RunId,
            ProjectName = r.ProjectName,
            Environment = r.Environment,
            ScenarioName = r.ScenarioName,
            StepOrder = r.StepOrder,
            RunGroupId = r.RunGroupId,
            RequestUrl = r.RequestUrl,
            ExecutionStartTime = r.ExecutionStartTime,
            ExecutionEndTime = r.ExecutionEndTime,
            Status = r.Status,
            AttemptCount = r.AttemptCount,
            ErrorMessage = r.ErrorMessage,
            ExecutedBy = r.ExecutedBy
        }).ToList();
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    // ---- Group scoping ---------------------------------------------------

    /// <summary>Steps the caller may see: all of them for an administrator, otherwise only their group's.</summary>
    private IQueryable<OrchestrationStep> ScopedSteps()
    {
        if (_user.IsAdmin)
        {
            return _db.OrchestrationSteps;
        }

        var group = _user.GroupId;
        return _db.OrchestrationSteps.Where(s => s.GroupId == group);
    }

    private IQueryable<ApiConfig> ScopedConfigs()
    {
        if (_user.IsAdmin)
        {
            return _db.ApiConfigs;
        }

        var group = _user.GroupId;
        return _db.ApiConfigs.Where(c => c.GroupId == group);
    }

    private void RequireAdmin()
    {
        if (!_user.IsAdmin)
        {
            throw new OrchestrationException("Only an administrator can do this.", HttpStatusCode.Forbidden, "FORBIDDEN");
        }
    }

    private async Task<Dictionary<int, string>> GroupNamesAsync(CancellationToken cancellationToken) =>
        await _db.UserGroups.AsNoTracking().ToDictionaryAsync(g => g.GroupId, g => g.Name, cancellationToken);

    private async Task<int?> RequireExistingGroupAsync(int? groupId, CancellationToken cancellationToken)
    {
        if (groupId == null || !await _db.UserGroups.AnyAsync(g => g.GroupId == groupId, cancellationToken))
        {
            throw new ValidationException("Choose the group this belongs to.", "GROUP_REQUIRED");
        }

        return groupId;
    }

    /// <summary>
    /// Works out which group a step belongs to and keeps scenario names unique across groups
    /// (the run URL has no group in it, so a name can only mean one scenario).
    /// </summary>
    private async Task<int?> ResolveStepGroupAsync(
        StepDto dto, int? editingStepId, int? ownGroupId, bool isUpdate, CancellationToken cancellationToken)
    {
        var sameName = _db.OrchestrationSteps.Where(s =>
            s.ProjectName == dto.ProjectName && s.Environment == dto.Environment && s.ScenarioName == dto.ScenarioName);
        if (editingStepId.HasValue)
        {
            var self = editingStepId.Value;
            sameName = sameName.Where(s => s.ServiceId != self);
        }

        var existingGroups = await sameName.Select(s => s.GroupId).Distinct().ToListAsync(cancellationToken);

        if (isUpdate)
        {
            if (existingGroups.Any(g => g != ownGroupId))
            {
                throw new OrchestrationException(
                    "That scenario name is already in use.", HttpStatusCode.Conflict, "SCENARIO_EXISTS");
            }

            return ownGroupId;
        }

        if (existingGroups.Count > 0)
        {
            var existing = existingGroups[0];
            if (!_user.IsAdmin && existing != _user.GroupId)
            {
                // Deliberately vague: do not reveal another group's scenario.
                throw new OrchestrationException(
                    "That scenario name is already in use.", HttpStatusCode.Conflict, "SCENARIO_EXISTS");
            }

            return existing;
        }

        return _user.IsAdmin
            ? await RequireExistingGroupAsync(dto.GroupId, cancellationToken)
            : _user.GroupId;
    }

    public async Task<ScenarioNameCheckDto> CheckScenarioNameAsync(
        string project, string environment, string scenario, CancellationToken cancellationToken = default)
    {
        var groups = await _db.OrchestrationSteps.AsNoTracking()
            .Where(s => s.ProjectName == project && s.Environment == environment && s.ScenarioName == scenario)
            .Select(s => s.GroupId)
            .Distinct()
            .ToListAsync(cancellationToken);

        if (groups.Count == 0)
        {
            return new ScenarioNameCheckDto { Available = true, Visible = false };
        }

        var visible = _user.IsAdmin || groups.All(g => g == _user.GroupId);
        return new ScenarioNameCheckDto
        {
            Available = false,
            Visible = visible,
            // Deliberately vague for another group's scenario.
            Message = visible ? "A scenario with this name already exists." : "That scenario name is already in use."
        };
    }

    public async Task AssignScenarioGroupAsync(
        string project, string environment, string scenario, int? groupId, CancellationToken cancellationToken = default)
    {
        RequireAdmin();
        var steps = await LoadSteps(project, environment, scenario).ToListAsync(cancellationToken);
        if (steps.Count == 0)
        {
            throw NotFound("Scenario not found.");
        }

        if (groupId.HasValue)
        {
            await RequireExistingGroupAsync(groupId, cancellationToken);
        }

        foreach (var step in steps)
        {
            step.GroupId = groupId;
            step.UpdatedAt = DateTime.UtcNow;
        }

        await _db.SaveChangesAsync(cancellationToken);
        _logger.LogInformation(
            "{User} assigned {Project}/{Environment}/{Scenario} to group {GroupId}",
            _user.Name, project, environment, scenario, groupId);
    }

    private IQueryable<OrchestrationStep> LoadSteps(string project, string environment, string scenario) =>
        ScopedSteps()
            .Where(s => s.ProjectName == project && s.Environment == environment && s.ScenarioName == scenario)
            .OrderBy(s => s.StepOrder).ThenBy(s => s.ServiceId);

    private async Task ValidateStepAsync(StepDto dto, int? groupId, CancellationToken cancellationToken)
    {
        dto.ProjectName = ValidateName(dto.ProjectName, "Project");
        dto.Environment = ValidateName(dto.Environment, "Environment");
        dto.ScenarioName = ValidateName(dto.ScenarioName, "Scenario");

        if (dto.StepOrder < 1 || dto.StepOrder > 999)
        {
            throw new ValidationException("The step order must be between 1 and 999.", "STEP_ORDER_INVALID");
        }

        var type = (dto.StepType ?? string.Empty).Trim().ToUpperInvariant();
        if (type != OrchestrationConstants.StepType_RestApi && type != OrchestrationConstants.StepType_Consolidate)
        {
            throw new ValidationException("The step type must be RESTAPI or CONSOLIDATE.", "STEP_TYPE_INVALID");
        }

        dto.StepType = type;

        if (dto.RetryCount < 0 || dto.RetryCount > 10)
        {
            throw new ValidationException("Retry count must be between 0 and 10.", "RETRY_INVALID");
        }

        if (dto.TimeoutSeconds < 1 || dto.TimeoutSeconds > 600)
        {
            throw new ValidationException("Timeout must be between 1 and 600 seconds.", "TIMEOUT_INVALID");
        }

        if (dto.WaitTimeSeconds < 0 || dto.WaitTimeSeconds > 3600)
        {
            throw new ValidationException("Wait time must be between 0 and 3600 seconds.", "WAIT_INVALID");
        }

        if (dto.PollIntervalSeconds < 0 || dto.PollIntervalSeconds > 3600)
        {
            throw new ValidationException(
                "The polling interval must be between 0 and 3600 seconds.", "POLL_INTERVAL_INVALID");
        }

        if (dto.PollMaxWaitSeconds < 0 || dto.PollMaxWaitSeconds > 86400)
        {
            throw new ValidationException(
                "The polling give-up time must be between 0 and 86400 seconds (24 hours).", "POLL_MAXWAIT_INVALID");
        }

        dto.InputParamMap = NullIfBlank(dto.InputParamMap);
        dto.OutputParamMap = NullIfBlank(dto.OutputParamMap);
        RequireValidJson(dto.InputParamMap, "The request template");
        RequireValidJson(dto.OutputParamMap, "The output template");

        if (type != OrchestrationConstants.StepType_RestApi)
        {
            // Only REST steps can poll.
            dto.PollIntervalSeconds = 0;
            dto.PollMaxWaitSeconds = 0;
        }
        else if (dto.PollIntervalSeconds > 0 || dto.PollMaxWaitSeconds > 0)
        {
            if (dto.PollIntervalSeconds < 1 || dto.PollMaxWaitSeconds < dto.PollIntervalSeconds)
            {
                throw new ValidationException(
                    "Polling needs a check interval and a give-up time that is at least one interval long.",
                    "POLL_SETTINGS_INVALID");
            }

            if (!HasPollCondition(dto.InputParamMap))
            {
                throw new ValidationException(
                    "Polling needs a condition (what to wait for). Add a \"poll\" block with a \"condition\" to the request template.",
                    "POLL_CONDITION_REQUIRED");
            }
        }

        if (type == OrchestrationConstants.StepType_RestApi)
        {
            if (string.IsNullOrWhiteSpace(dto.Endpoint))
            {
                throw new ValidationException("An endpoint is required for a REST API step.", "ENDPOINT_REQUIRED");
            }

            var method = (dto.HttpMethod ?? string.Empty).Trim().ToUpperInvariant();
            if (!AllowedHttpMethods.Contains(method))
            {
                throw new ValidationException(
                    "The HTTP method must be GET, POST, PUT, PATCH or DELETE.", "METHOD_INVALID");
            }

            dto.HttpMethod = method;

            dto.BaseUrlConfigKey = NullIfBlank(dto.BaseUrlConfigKey);
            if (dto.BaseUrlConfigKey != null &&
                !await _db.ApiConfigs.AnyAsync(c => c.ConfigKey == dto.BaseUrlConfigKey && c.GroupId == groupId, cancellationToken))
            {
                throw new ValidationException(
                    $"The base URL '{dto.BaseUrlConfigKey}' does not exist in this group. Add it under Connections first.",
                    "BASE_URL_UNKNOWN");
            }
        }
        else if (string.IsNullOrWhiteSpace(dto.OutputParamMap))
        {
            throw new ValidationException(
                "A consolidate step needs an output template.", "OUTPUT_TEMPLATE_REQUIRED");
        }
    }

    private static void ApplyStep(OrchestrationStep entity, StepDto dto)
    {
        entity.ProjectName = dto.ProjectName;
        entity.Environment = dto.Environment;
        entity.ScenarioName = dto.ScenarioName;
        entity.StepOrder = dto.StepOrder;
        entity.StepDescription = NullIfBlank(dto.StepDescription);
        entity.StepType = dto.StepType;
        entity.BaseUrlConfigKey = dto.BaseUrlConfigKey;
        entity.Endpoint = NullIfBlank(dto.Endpoint);
        entity.HttpMethod = dto.HttpMethod;
        entity.InputParamMap = dto.InputParamMap;
        entity.OutputParamMap = dto.OutputParamMap;
        entity.RetryCount = dto.RetryCount;
        entity.TimeoutSeconds = dto.TimeoutSeconds;
        entity.WaitTimeSeconds = dto.WaitTimeSeconds;
        entity.PollIntervalSeconds = dto.PollIntervalSeconds;
        entity.PollMaxWaitSeconds = dto.PollMaxWaitSeconds;
        entity.ActiveFlag = dto.Active
            ? OrchestrationConstants.ActiveFlag_Active
            : OrchestrationConstants.ActiveFlag_Inactive;
    }

    private static string ValidateConfigKey(string? key)
    {
        var value = (key ?? string.Empty).Trim();
        if (value.Length == 0 || value.Length > 150)
        {
            throw new ValidationException("The connection name must be 1 to 150 characters.", "CONFIG_KEY_INVALID");
        }

        if (!Regex.IsMatch(value, @"^[A-Za-z0-9_.\-]+$"))
        {
            throw new ValidationException(
                "The connection name may only contain letters, digits, '_', '-' and '.'.", "CONFIG_KEY_INVALID");
        }

        return value;
    }

    private static string ValidateName(string? name, string label)
    {
        var value = (name ?? string.Empty).Trim();
        if (value.Length == 0 || value.Length > 100 || !NamePattern.IsMatch(value))
        {
            throw new ValidationException(
                $"{label} must be 1 to 100 characters: letters, digits, '_', '-' and '.' only.", "NAME_INVALID");
        }

        return value;
    }

    /// <summary>True when the request template contains a "poll" object with a "condition" object.</summary>
    private static bool HasPollCondition(string? inputParamMap)
    {
        if (string.IsNullOrWhiteSpace(inputParamMap))
        {
            return false;
        }

        try
        {
            return JsonNode.Parse(inputParamMap) is JsonObject root
                   && root["poll"] is JsonObject poll
                   && poll["condition"] is JsonObject;
        }
        catch (JsonException)
        {
            return false;
        }
    }

    private static void RequireValidJson(string? json, string label)
    {
        if (json == null)
        {
            return;
        }

        try
        {
            JsonNode.Parse(json);
        }
        catch (JsonException ex)
        {
            throw new ValidationException($"{label} is not valid JSON: {ex.Message}", "JSON_INVALID");
        }
    }

    private static void CheckJson(string? json, string label, int order, List<ValidationIssueDto> issues)
    {
        if (string.IsNullOrWhiteSpace(json))
        {
            return;
        }

        try
        {
            JsonNode.Parse(json);
        }
        catch (JsonException ex)
        {
            issues.Add(Issue("error", order, $"The {label} is not valid JSON: {ex.Message}"));
        }
    }

    private static ValidationIssueDto Issue(string severity, int? order, string message) =>
        new() { Severity = severity, StepOrder = order, Message = message };

    private static string? NullIfBlank(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();

    private static OrchestrationException NotFound(string message) =>
        new(message, HttpStatusCode.NotFound, "NOT_FOUND");

    private static ConfigItemDto ToConfigDto(ApiConfig c, Dictionary<int, string> groups)
    {
        var secret = SecretKeyPattern.IsMatch(c.ConfigKey);
        return new ConfigItemDto
        {
            Id = c.Id,
            ConfigKey = c.ConfigKey,
            ConfigValue = secret ? SecretMask : c.ConfigValue,
            Description = c.Description,
            IsSecret = secret,
            GroupId = c.GroupId,
            GroupName = c.GroupId.HasValue && groups.TryGetValue(c.GroupId.Value, out var groupName) ? groupName : null,
            UpdatedAt = c.UpdatedAt
        };
    }

    private static StepDto ToStepDto(OrchestrationStep s) => new()
    {
        ServiceId = s.ServiceId,
        ProjectName = s.ProjectName,
        Environment = s.Environment,
        ScenarioName = s.ScenarioName,
        StepOrder = s.StepOrder,
        StepDescription = s.StepDescription,
        StepType = s.StepType,
        BaseUrlConfigKey = s.BaseUrlConfigKey,
        Endpoint = s.Endpoint,
        HttpMethod = s.HttpMethod,
        InputParamMap = s.InputParamMap,
        OutputParamMap = s.OutputParamMap,
        RetryCount = s.RetryCount,
        TimeoutSeconds = s.TimeoutSeconds,
        WaitTimeSeconds = s.WaitTimeSeconds,
        PollIntervalSeconds = s.PollIntervalSeconds,
        PollMaxWaitSeconds = s.PollMaxWaitSeconds,
        GroupId = s.GroupId,
        Active = s.ActiveFlag == OrchestrationConstants.ActiveFlag_Active,
        UpdatedAt = s.UpdatedAt
    };
}
