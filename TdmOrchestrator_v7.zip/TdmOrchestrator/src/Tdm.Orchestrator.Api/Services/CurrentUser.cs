namespace Tdm.Orchestrator.Application.Services;

/// <summary>Who is calling the admin API. Filled in by AdminKeyFilter; read by the services to scope data.</summary>
public interface ICurrentUser
{
    bool IsAuthenticated { get; }
    bool IsAdmin { get; }
    int? UserId { get; }
    string Name { get; }

    /// <summary>The group a non-admin user belongs to. Always null for administrators.</summary>
    int? GroupId { get; }
}

public class CurrentUser : ICurrentUser
{
    public bool IsAuthenticated { get; private set; }
    public bool IsAdmin { get; private set; }
    public int? UserId { get; private set; }
    public string Name { get; private set; } = string.Empty;
    public int? GroupId { get; private set; }

    public void Set(int? userId, string name, bool isAdmin, int? groupId)
    {
        IsAuthenticated = true;
        UserId = userId;
        Name = name;
        IsAdmin = isAdmin;
        GroupId = isAdmin ? null : groupId;
    }
}
