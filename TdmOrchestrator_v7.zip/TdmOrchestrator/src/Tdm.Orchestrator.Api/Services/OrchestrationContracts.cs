using System.Text.Json.Nodes;
using Tdm.Orchestrator.Application.DTOs;

namespace Tdm.Orchestrator.Application.Interfaces;

/// <summary>Response from external API call.</summary>
public class HttpResponseDto
{
    public int StatusCode { get; set; }
    public string? RequestUrl { get; set; }
    public JsonNode? Response { get; set; }
}

/// <summary>Core orchestration engine interface.</summary>
public interface IOrchestratorService
{
    /// <summary>Executes an orchestration scenario.</summary>
    Task<JsonNode?> ExecuteAsync(OrchestratorInputDto input, CancellationToken cancellationToken = default);
}

/// <summary>Configuration data access.</summary>
public interface IConfigurationService
{
    /// <summary>Connection values are looked up inside one group only; null is the "not assigned" group.</summary>
    Task<string?> GetConfigValueAsync(string key, int? groupId, CancellationToken cancellationToken = default);
    Task<Dictionary<string, string>> GetAllConfigAsync(int? groupId, CancellationToken cancellationToken = default);
}

/// <summary>Handles HTTP calls to external APIs with proper timeout and error handling.</summary>
public interface IHttpApiClient
{
    Task<HttpResponseDto> CallApiAsync(
        string url,
        string httpMethod,
        JsonNode? body,
        IReadOnlyDictionary<string, string>? headers,
        int timeoutSeconds,
        CancellationToken cancellationToken = default);
}
