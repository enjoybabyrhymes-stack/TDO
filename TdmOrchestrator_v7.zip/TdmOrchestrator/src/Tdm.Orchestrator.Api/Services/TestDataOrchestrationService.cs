using System.Text.Json.Nodes;
using Tdm.Orchestrator.Application.DTOs;
using Tdm.Orchestrator.Application.Interfaces;
using Tdm.Orchestrator.Application.Utilities;
using Tdm.Orchestrator.Domain.Constants;
using Tdm.Orchestrator.Domain.Entities;
using Tdm.Orchestrator.Domain.Exceptions;
using Tdm.Orchestrator.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Tdm.Orchestrator.Application.Services;

/// <summary>
/// Core orchestration engine. Orchestrates multi-step scenarios by executing
/// database-configured steps in sequence, chaining outputs between steps.
/// </summary>
public class TestDataOrchestrationService : IOrchestratorService
{
    private readonly OrchestratorDbContext _db;
    private readonly IHttpApiClient _httpClient;
    private readonly IConfigurationService _configService;
    private readonly ILogger<TestDataOrchestrationService> _logger;

    public TestDataOrchestrationService(
        OrchestratorDbContext db,
        IHttpApiClient httpClient,
        IConfigurationService configService,
        ILogger<TestDataOrchestrationService> logger)
    {
        _db = db;
        _httpClient = httpClient;
        _configService = configService;
        _logger = logger;
    }

    public async Task<JsonNode?> ExecuteAsync(OrchestratorInputDto input, CancellationToken cancellationToken = default)
    {
        var steps = await _db.OrchestrationSteps
            .AsNoTracking()
            .Where(s => s.ProjectName.ToLower() == input.ProjectName.ToLower() &&
                        s.Environment.ToLower() == input.Environment.ToLower() &&
                        s.ScenarioName.ToLower() == input.Scenario.ToLower() &&
                        s.ActiveFlag == OrchestrationConstants.ActiveFlag_Active)
            .OrderBy(s => s.StepOrder)
            .ToListAsync(cancellationToken);

        if (!steps.Any())
        {
            throw new ValidationException(
                $"No active steps configured for {input.ProjectName}/{input.Environment}/{input.Scenario}",
                "SCENARIO_NOT_FOUND");
        }

        // All steps of a scenario belong to one group; connections are resolved from that group only.
        var scenarioGroupId = steps[0].GroupId;
        var configValues = await _configService.GetAllConfigAsync(scenarioGroupId, cancellationToken);

        var stepsResponseMap = new Dictionary<string, JsonNode?>();
        if (input.InputData != null)
        {
            stepsResponseMap["input"] = input.InputData;
        }

        JsonNode? lastOutput = null;
        var runGroupId = Guid.NewGuid().ToString("N");

        foreach (var step in steps)
        {
            // Respect wait times between steps
            if (step.WaitTimeSeconds > 0)
            {
                _logger.LogInformation(
                    "Waiting {Seconds}s before step {StepOrder} of scenario {Scenario}",
                    step.WaitTimeSeconds, step.StepOrder, input.Scenario);
                await Task.Delay(TimeSpan.FromSeconds(step.WaitTimeSeconds), cancellationToken);
            }

            var run = new OrchestrationRun
            {
                ProjectName = step.ProjectName,
                Environment = step.Environment,
                ScenarioName = step.ScenarioName,
                ServiceId = step.ServiceId,
                StepOrder = step.StepOrder,
                RunGroupId = runGroupId,
                ExecutionStartTime = DateTime.UtcNow,
                ExecutedBy = input.UserId
            };

            try
            {
                lastOutput = await ExecuteStepAsync(step, stepsResponseMap, configValues, run, cancellationToken);
            }
            catch (Exception ex)
            {
                // Keep the real HTTP status when the failure came from the called system (404, 503, 504...).
                run.Status ??= "500";
                run.ErrorMessage = ex.Message;
                run.ExecutionEndTime = DateTime.UtcNow;
                _db.OrchestrationRuns.Add(run);
                await _db.SaveChangesAsync(cancellationToken);

                _logger.LogError(ex,
                    "Step {StepOrder} of scenario {Scenario} failed",
                    step.StepOrder, input.Scenario);

                throw new OrchestrationException(
                    $"Step {step.StepOrder} ({step.StepDescription}) failed: {ex.Message}");
            }

            run.ExecutionEndTime = DateTime.UtcNow;
            _db.OrchestrationRuns.Add(run);
            await _db.SaveChangesAsync(cancellationToken);

            _logger.LogInformation(
                "Step {StepOrder} of scenario {Scenario} completed with status {Status}",
                step.StepOrder, input.Scenario, run.Status);
        }

        return lastOutput;
    }

    private async Task<JsonNode?> ExecuteStepAsync(
        OrchestrationStep step,
        Dictionary<string, JsonNode?> stepsResponseMap,
        Dictionary<string, string> configValues,
        OrchestrationRun run,
        CancellationToken cancellationToken = default)
    {
        var stepKey = $"step{step.StepOrder}";

        if (step.StepType.Equals(OrchestrationConstants.StepType_RestApi, StringComparison.OrdinalIgnoreCase))
        {
            // Resolve base URL from configuration or use endpoint as full URL
            var baseUrl = string.IsNullOrWhiteSpace(step.BaseUrlConfigKey)
                ? string.Empty
                : await _configService.GetConfigValueAsync(step.BaseUrlConfigKey, step.GroupId, cancellationToken) ?? string.Empty;

            if (!string.IsNullOrWhiteSpace(step.BaseUrlConfigKey) && string.IsNullOrEmpty(baseUrl))
            {
                throw new ConfigurationException(
                    $"Configuration key '{step.BaseUrlConfigKey}' referenced by step {step.StepOrder} was not found.");
            }

            // Resolve placeholders in endpoint
            var resolvedSuffix = PlaceholderResolver.ResolveEndpoint(
                step.Endpoint ?? string.Empty, stepsResponseMap, configValues);
            var fullUrl = baseUrl + resolvedSuffix;
            run.RequestUrl = fullUrl;

            // Resolve and split body/headers from template
            var resolvedInput = PlaceholderResolver.ResolveTemplate(
                step.InputParamMap, stepsResponseMap, configValues);
            var (resolvedBody, resolvedHeaders) = SplitBodyAndHeaders(resolvedInput);

            // ---------------------------------------------------------------
            // Optional "poll" block: { "condition": {...}, "body": {...},
            // "headers": {...} }. When InputParamMap includes one alongside
            // "body", this step doesn't move on after a single successful
            // call — it keeps re-calling its own endpoint until "condition"
            // matches the latest response, or it runs out of attempts.
            //
            // Timing comes from the step's PollIntervalSeconds (check every N seconds) and
            // PollMaxWaitSeconds (give up after N seconds). Older steps that have a poll block but
            // leave both at 0 keep the original convention: RetryCount = max extra polls and
            // WaitTimeSeconds = delay between polls. (WaitTimeSeconds is also still applied once
            // before the step, for every step type.)
            // ---------------------------------------------------------------
            if (resolvedInput is JsonObject resolvedInputObj &&
                resolvedInputObj["poll"] is JsonObject pollBlock)
            {
                return await ExecutePollingStepAsync(
                    step,
                    fullUrl,
                    resolvedBody,
                    resolvedHeaders,
                    pollBlock,
                    stepsResponseMap,
                    configValues,
                    stepKey,
                    run,
                    cancellationToken);
            }

            // ---------------------------------------------------------------
            // Retry logic: step.RetryCount is the number of EXTRA attempts
            // allowed after the first try (RetryCount = 2 -> up to 3 total
            // attempts). We only retry on server-side/network-style failures
            // (HTTP 5xx, including the 502/504 statuses HttpApiClient returns
            // for connection errors and timeouts). Client errors (4xx) are not
            // retried, since calling the same broken request again won't help.
            // A short linear backoff (1s, 2s, 3s, ...) runs between attempts
            // so a struggling downstream service isn't hammered immediately.
            // ---------------------------------------------------------------
            var maxAttempts = Math.Max(1, step.RetryCount + 1);
            HttpResponseDto response = null!;

            var attemptsMade = 0;

            for (var attempt = 1; attempt <= maxAttempts; attempt++)
            {
                attemptsMade = attempt;

                response = await _httpClient.CallApiAsync(
                    fullUrl,
                    step.HttpMethod ?? OrchestrationConstants.HttpMethod_Get,
                    resolvedBody,
                    resolvedHeaders,
                    step.TimeoutSeconds,
                    cancellationToken);

                var isRetryableFailure = response.StatusCode >= 500;

                if (!isRetryableFailure || attempt == maxAttempts)
                {
                    if (attempt > 1)
                    {
                        _logger.LogInformation(
                            "Step {StepOrder} of scenario {Scenario} finished after {Attempt}/{MaxAttempts} attempt(s) with status {Status}",
                            step.StepOrder, step.ScenarioName, attempt, maxAttempts, response.StatusCode);
                    }
                    break;
                }

                _logger.LogWarning(
                    "Step {StepOrder} of scenario {Scenario} attempt {Attempt}/{MaxAttempts} failed with status {Status} — retrying",
                    step.StepOrder, step.ScenarioName, attempt, maxAttempts, response.StatusCode);

                await Task.Delay(TimeSpan.FromSeconds(attempt), cancellationToken);
            }

            stepsResponseMap[stepKey] = response.Response;
            run.Status = response.StatusCode.ToString();
            run.AttemptCount = attemptsMade;

            // An error answer from the called system fails this step and stops the run, so it shows up in
            // the run history with the step number instead of later steps carrying on with an error body.
            if (response.StatusCode >= 400)
            {
                throw new OrchestrationException(DescribeHttpFailure(step, fullUrl, response));
            }

            return response.Response;
        }

        if (step.StepType.Equals(OrchestrationConstants.StepType_Consolidate, StringComparison.OrdinalIgnoreCase))
        {
            // Consolidate step: aggregate fields from previous steps
            var consolidated = PlaceholderResolver.ResolveTemplate(
                step.OutputParamMap, stepsResponseMap, configValues);
            stepsResponseMap[stepKey] = consolidated;
            run.Status = "200";
            return consolidated;
        }

        throw new OrchestrationException(
            $"Unknown step type '{step.StepType}'. Supported types: {OrchestrationConstants.StepType_RestApi}, {OrchestrationConstants.StepType_Consolidate}");
    }

    /// <summary>
    /// Executes a step whose InputParamMap includes a "poll" block: calls the
    /// step's own endpoint once with the initial body, then — if
    /// "poll.condition" doesn't match the response — keeps re-calling the
    /// same endpoint, using "poll.body"/"poll.headers" when given (falling
    /// back to the initial body/headers otherwise), until the condition
    /// matches or the max attempt count is reached. Each attempt's response
    /// overwrites what's stored for this step, so both the condition check
    /// and any later step referencing "$stepN.xxx" always see the latest
    /// data, not the first call's response.
    /// </summary>
    private async Task<JsonNode?> ExecutePollingStepAsync(
        OrchestrationStep step,
        string fullUrl,
        JsonNode? initialBody,
        Dictionary<string, string>? initialHeaders,
        JsonObject pollBlock,
        Dictionary<string, JsonNode?> stepsResponseMap,
        Dictionary<string, string> configValues,
        string stepKey,
        OrchestrationRun run,
        CancellationToken cancellationToken)
    {
        if (pollBlock["condition"] is not JsonObject pollCondition)
        {
            throw new ConfigurationException(
                $"Step {step.StepOrder}'s 'poll' block requires a 'condition' object " +
                "(e.g. {\"field\": \"step2.status\", \"equals\": \"approved\"}).");
        }

        // poll.body/poll.headers override what's sent on every re-call after
        // the first. When the poll block doesn't specify its own, re-calls
        // reuse the same body/headers as the initial call.
        var (pollBodyOverride, pollHeadersOverride) = SplitBodyAndHeaders(pollBlock);
        var pollBody = pollBlock.ContainsKey("body") ? pollBodyOverride : initialBody;
        var pollHeaders = pollBlock.ContainsKey("headers") ? pollHeadersOverride : initialHeaders;

        // Dedicated polling settings (PollIntervalSeconds / PollMaxWaitSeconds) win when set. Otherwise fall back
        // to the original convention (RetryCount = extra polls, WaitTimeSeconds = interval) so scenarios saved
        // before those columns existed behave exactly as before.
        int maxAttempts;
        int pollIntervalSeconds;
        if (step.PollIntervalSeconds > 0)
        {
            pollIntervalSeconds = step.PollIntervalSeconds;
            maxAttempts = Math.Max(1, step.PollMaxWaitSeconds / step.PollIntervalSeconds) + 1;
        }
        else
        {
            pollIntervalSeconds = step.WaitTimeSeconds > 0 ? step.WaitTimeSeconds : 30;
            maxAttempts = Math.Max(1, step.RetryCount + 1);
        }

        HttpResponseDto response = null!;
        var attemptsMade = 0;

        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            attemptsMade = attempt;

            var body = attempt == 1 ? initialBody : pollBody;
            var headers = attempt == 1 ? initialHeaders : pollHeaders;

            response = await _httpClient.CallApiAsync(
                fullUrl,
                step.HttpMethod ?? OrchestrationConstants.HttpMethod_Get,
                body,
                headers,
                step.TimeoutSeconds,
                cancellationToken);

            // Overwrite immediately so the condition check below (and any
            // later step) sees this attempt's data, not a stale one.
            stepsResponseMap[stepKey] = response.Response;

            var conditionMet = PlaceholderResolver.EvaluateCondition(
                pollCondition, stepsResponseMap, configValues);

            if (conditionMet)
            {
                if (attempt > 1)
                {
                    _logger.LogInformation(
                        "Step {StepOrder} of scenario {Scenario} poll condition met after {Attempt}/{MaxAttempts} attempt(s)",
                        step.StepOrder, step.ScenarioName, attempt, maxAttempts);
                }
                break;
            }

            if (attempt == maxAttempts)
            {
                run.Status = response.StatusCode.ToString();
                run.AttemptCount = attemptsMade;

                throw new OrchestrationException(
                    $"Step {step.StepOrder} ({step.StepDescription}) timed out after " +
                    $"{maxAttempts} poll attempt(s) (~{(maxAttempts - 1) * pollIntervalSeconds}s) " +
                    $"without its poll condition being met (last response: HTTP {response.StatusCode}).");
            }

            _logger.LogInformation(
                "Step {StepOrder} of scenario {Scenario} poll attempt {Attempt}/{MaxAttempts}: condition not yet met, waiting {Interval}s",
                step.StepOrder, step.ScenarioName, attempt, maxAttempts, pollIntervalSeconds);

            await Task.Delay(TimeSpan.FromSeconds(pollIntervalSeconds), cancellationToken);
        }

        run.Status = response.StatusCode.ToString();
        run.AttemptCount = attemptsMade;

        return response.Response;
    }

    private static string DescribeHttpFailure(OrchestrationStep step, string url, HttpResponseDto response)
    {
        var method = (step.HttpMethod ?? OrchestrationConstants.HttpMethod_Get).ToUpperInvariant();
        var reason = response.StatusCode switch
        {
            504 => " (the request timed out)",
            502 => " (the server could not be reached)",
            _ => string.Empty
        };

        var body = response.Response?.ToJsonString() ?? string.Empty;
        if (body.Length > 300)
        {
            body = body[..300] + "...";
        }

        return $"HTTP {response.StatusCode}{reason} from {method} {url}" + (body.Length > 0 ? $": {body}" : ".");
    }

    /// <summary>
    /// Splits InputParamMap into request body and headers.
    /// Expected format: { "headers": {...}, "body": {...} } or just the body if neither key is present.
    /// </summary>
    private static (JsonNode? Body, Dictionary<string, string>? Headers) SplitBodyAndHeaders(JsonNode? resolvedInput)
    {
        if (resolvedInput is not JsonObject obj)
        {
            return (resolvedInput, null);
        }

        var hasHeadersKey = obj.ContainsKey("headers");
        var hasBodyKey = obj.ContainsKey("body");

        if (!hasHeadersKey && !hasBodyKey)
        {
            return (resolvedInput, null);
        }

        Dictionary<string, string>? headers = null;
        if (hasHeadersKey && obj["headers"] is JsonObject headersObj)
        {
            headers = new Dictionary<string, string>();
            foreach (var (key, value) in headersObj)
            {
                var stringValue = value?.ToString();
                if (!string.IsNullOrEmpty(stringValue))
                {
                    headers[key] = stringValue;
                }
            }
        }

        var body = hasBodyKey ? obj["body"] : null;
        return (body, headers);
    }
}
