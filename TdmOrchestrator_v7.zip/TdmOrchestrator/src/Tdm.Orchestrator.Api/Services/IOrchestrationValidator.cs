namespace Tdm.Orchestrator.Application.Interfaces;

/// <summary>Validates orchestration scenario existence and availability.</summary>
public interface IOrchestrationValidator
{
    Task<bool> IsValidProjectAsync(string project, CancellationToken cancellationToken = default);
    Task<bool> IsValidEnvironmentAsync(string project, string environment, CancellationToken cancellationToken = default);
    Task<bool> IsValidScenarioAsync(string project, string environment, string scenario, CancellationToken cancellationToken = default);
    Task<IEnumerable<string>> GetProjectsAsync(CancellationToken cancellationToken = default);
    Task<IEnumerable<string>> GetEnvironmentsAsync(string project, CancellationToken cancellationToken = default);
    Task<IEnumerable<string>> GetScenariosAsync(string project, string environment, CancellationToken cancellationToken = default);
}
