using Tdm.Orchestrator.Application.DTOs;

namespace Tdm.Orchestrator.Application.Interfaces;

/// <summary>Groups and users. Only administrators may change them.</summary>
public interface IAccessAdminService
{
    Task<IReadOnlyList<GroupDto>> GetGroupsAsync(CancellationToken cancellationToken = default);
    Task<GroupDto> CreateGroupAsync(GroupSaveDto dto, CancellationToken cancellationToken = default);
    Task<GroupDto> UpdateGroupAsync(int id, GroupSaveDto dto, CancellationToken cancellationToken = default);
    Task DeleteGroupAsync(int id, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<UserDto>> GetUsersAsync(CancellationToken cancellationToken = default);
    Task<UserDto> CreateUserAsync(UserCreateDto dto, CancellationToken cancellationToken = default);
    Task<UserDto> UpdateUserAsync(int id, UserUpdateDto dto, CancellationToken cancellationToken = default);
    Task ResetPasswordAsync(int id, PasswordResetDto dto, CancellationToken cancellationToken = default);
    Task DeleteUserAsync(int id, CancellationToken cancellationToken = default);
}
