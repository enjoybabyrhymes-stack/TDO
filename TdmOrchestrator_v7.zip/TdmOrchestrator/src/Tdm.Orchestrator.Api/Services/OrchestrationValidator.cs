using Tdm.Orchestrator.Application.Interfaces;
using Tdm.Orchestrator.Domain.Constants;
using Tdm.Orchestrator.Domain.Entities;
using Tdm.Orchestrator.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace Tdm.Orchestrator.Application.Services;

/// <summary>Validates orchestration scenario configurations.</summary>
public class OrchestrationValidator : IOrchestrationValidator
{
    private readonly OrchestratorDbContext _db;
    private readonly ILogger<OrchestrationValidator> _logger;

    public OrchestrationValidator(OrchestratorDbContext db, ILogger<OrchestrationValidator> logger)
    {
        _db = db;
        _logger = logger;
    }

    /// <summary>
    /// Base query for every lookup below: active steps only, read-only.
    /// AsNoTracking() skips EF Core's change-tracking bookkeeping, which is
    /// pure overhead for queries whose results are never modified/saved —
    /// every method in this class is a read-only existence/lookup check.
    /// </summary>
    private IQueryable<OrchestrationStep> ActiveSteps() =>
        _db.OrchestrationSteps
            .AsNoTracking()
            .Where(s => s.ActiveFlag == OrchestrationConstants.ActiveFlag_Active);

    public async Task<bool> IsValidProjectAsync(string project, CancellationToken cancellationToken = default)
    {
        return await ActiveSteps()
            .AnyAsync(s => s.ProjectName.ToLower() == project.ToLower(), cancellationToken);
    }

    public async Task<bool> IsValidEnvironmentAsync(string project, string environment, CancellationToken cancellationToken = default)
    {
        return await ActiveSteps()
            .AnyAsync(s =>
                s.ProjectName.ToLower() == project.ToLower() &&
                s.Environment.ToLower() == environment.ToLower(),
                cancellationToken);
    }

    public async Task<bool> IsValidScenarioAsync(string project, string environment, string scenario, CancellationToken cancellationToken = default)
    {
        return await ActiveSteps()
            .AnyAsync(s =>
                s.ProjectName.ToLower() == project.ToLower() &&
                s.Environment.ToLower() == environment.ToLower() &&
                s.ScenarioName.ToLower() == scenario.ToLower(),
                cancellationToken);
    }

    public async Task<IEnumerable<string>> GetProjectsAsync(CancellationToken cancellationToken = default)
    {
        return await ActiveSteps()
            .Select(s => s.ProjectName)
            .Distinct()
            .ToListAsync(cancellationToken);
    }

    public async Task<IEnumerable<string>> GetEnvironmentsAsync(string project, CancellationToken cancellationToken = default)
    {
        return await ActiveSteps()
            .Where(s => s.ProjectName.ToLower() == project.ToLower())
            .Select(s => s.Environment)
            .Distinct()
            .ToListAsync(cancellationToken);
    }

    public async Task<IEnumerable<string>> GetScenariosAsync(string project, string environment, CancellationToken cancellationToken = default)
    {
        return await ActiveSteps()
            .Where(s =>
                s.ProjectName.ToLower() == project.ToLower() &&
                s.Environment.ToLower() == environment.ToLower())
            .Select(s => s.ScenarioName)
            .Distinct()
            .ToListAsync(cancellationToken);
    }
}
