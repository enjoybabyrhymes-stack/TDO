using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Tdm.Orchestrator.Domain.Entities;
using Tdm.Orchestrator.Infrastructure.Persistence;
using Tdm.Orchestrator.Options;

namespace Tdm.Orchestrator.Application.Services;

public interface ISessionService
{
    Task<(string Token, DateTime ExpiresAt)> CreateAsync(AppUser user, CancellationToken cancellationToken = default);
    Task<AppUser?> FindUserAsync(string token, CancellationToken cancellationToken = default);
    Task RevokeAsync(string token, CancellationToken cancellationToken = default);
    Task RevokeAllForUserAsync(int userId, CancellationToken cancellationToken = default);
}

/// <summary>Server-side sessions: a random token is handed to the browser, only its hash is stored.</summary>
public class SessionService : ISessionService
{
    private readonly OrchestratorDbContext _db;
    private readonly AdminOptions _options;

    public SessionService(OrchestratorDbContext db, IOptions<AdminOptions> options)
    {
        _db = db;
        _options = options.Value;
    }

    private static string HashToken(string token) =>
        Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(token)));

    public async Task<(string Token, DateTime ExpiresAt)> CreateAsync(AppUser user, CancellationToken cancellationToken = default)
    {
        var now = DateTime.UtcNow;

        // Housekeeping: drop sessions that have already expired.
        await _db.UserSessions.Where(s => s.ExpiresAt < now).ExecuteDeleteAsync(cancellationToken);

        var token = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32))
            .Replace('+', '-').Replace('/', '_').TrimEnd('=');
        var hours = _options.SessionHours > 0 ? _options.SessionHours : 8;
        var expires = now.AddHours(hours);

        _db.UserSessions.Add(new UserSession
        {
            TokenHash = HashToken(token),
            UserId = user.UserId,
            CreatedAt = now,
            ExpiresAt = expires
        });
        await _db.SaveChangesAsync(cancellationToken);
        return (token, expires);
    }

    public async Task<AppUser?> FindUserAsync(string token, CancellationToken cancellationToken = default)
    {
        var hash = HashToken(token);
        var now = DateTime.UtcNow;
        var session = await _db.UserSessions.AsNoTracking()
            .FirstOrDefaultAsync(s => s.TokenHash == hash && s.ExpiresAt > now, cancellationToken);
        if (session == null)
        {
            return null;
        }

        return await _db.AppUsers.AsNoTracking()
            .FirstOrDefaultAsync(u => u.UserId == session.UserId && u.Active, cancellationToken);
    }

    public async Task RevokeAsync(string token, CancellationToken cancellationToken = default)
    {
        var hash = HashToken(token);
        await _db.UserSessions.Where(s => s.TokenHash == hash).ExecuteDeleteAsync(cancellationToken);
    }

    public async Task RevokeAllForUserAsync(int userId, CancellationToken cancellationToken = default)
    {
        await _db.UserSessions.Where(s => s.UserId == userId).ExecuteDeleteAsync(cancellationToken);
    }
}
