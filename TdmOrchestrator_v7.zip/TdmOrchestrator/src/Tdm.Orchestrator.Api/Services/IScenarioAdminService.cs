using Tdm.Orchestrator.Application.DTOs;

namespace Tdm.Orchestrator.Application.Interfaces;

/// <summary>Management operations behind the admin UI: connections, scenarios, steps, validation and export.</summary>
public interface IScenarioAdminService
{
    Task<IReadOnlyList<ConfigItemDto>> GetConfigsAsync(CancellationToken cancellationToken = default);
    Task<ConfigItemDto> CreateConfigAsync(ConfigSaveDto dto, CancellationToken cancellationToken = default);
    Task<ConfigItemDto> UpdateConfigAsync(int id, ConfigSaveDto dto, CancellationToken cancellationToken = default);
    Task DeleteConfigAsync(int id, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<ScenarioSummaryDto>> GetScenariosAsync(CancellationToken cancellationToken = default);
    Task<IReadOnlyList<StepDto>> GetStepsAsync(string project, string environment, string scenario, CancellationToken cancellationToken = default);
    Task<StepDto> CreateStepAsync(StepDto dto, CancellationToken cancellationToken = default);
    Task<StepDto> UpdateStepAsync(int id, StepDto dto, CancellationToken cancellationToken = default);
    Task DeleteStepAsync(int id, CancellationToken cancellationToken = default);
    Task MoveStepAsync(int id, bool up, CancellationToken cancellationToken = default);

    Task CloneScenarioAsync(CloneScenarioDto dto, CancellationToken cancellationToken = default);
    Task SetScenarioActiveAsync(string project, string environment, string scenario, bool active, CancellationToken cancellationToken = default);
    Task DeleteScenarioAsync(string project, string environment, string scenario, CancellationToken cancellationToken = default);

    /// <summary>Administrators only: give a scenario to a group (null = unassigned).</summary>
    Task<ScenarioNameCheckDto> CheckScenarioNameAsync(string project, string environment, string scenario, CancellationToken cancellationToken = default);
    Task AssignScenarioGroupAsync(string project, string environment, string scenario, int? groupId, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<ValidationIssueDto>> ValidateScenarioAsync(string project, string environment, string scenario, CancellationToken cancellationToken = default);
    Task<PostmanExportDto> BuildPostmanExportAsync(string project, string environment, string scenario, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<RunItemDto>> GetRunsAsync(string? project, string? environment, string? scenario, int take, CancellationToken cancellationToken = default);
}
