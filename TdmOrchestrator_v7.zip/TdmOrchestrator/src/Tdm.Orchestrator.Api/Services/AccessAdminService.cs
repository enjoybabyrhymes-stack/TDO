using System.Net;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Tdm.Orchestrator.Application.DTOs;
using Tdm.Orchestrator.Application.Interfaces;
using Tdm.Orchestrator.Application.Utilities;
using Tdm.Orchestrator.Domain.Constants;
using Tdm.Orchestrator.Domain.Entities;
using Tdm.Orchestrator.Domain.Exceptions;
using Tdm.Orchestrator.Infrastructure.Persistence;
using Tdm.Orchestrator.Options;

namespace Tdm.Orchestrator.Application.Services;

/// <summary>Creates and manages groups and users. Everything that changes them requires an administrator.</summary>
public class AccessAdminService : IAccessAdminService
{
    private static readonly Regex UsernamePattern = new(@"^[A-Za-z0-9_.@\-]{3,64}$", RegexOptions.Compiled);

    private readonly OrchestratorDbContext _db;
    private readonly ICurrentUser _user;
    private readonly ISessionService _sessions;
    private readonly AdminOptions _options;
    private readonly ILogger<AccessAdminService> _logger;

    public AccessAdminService(
        OrchestratorDbContext db,
        ICurrentUser user,
        ISessionService sessions,
        IOptions<AdminOptions> options,
        ILogger<AccessAdminService> logger)
    {
        _db = db;
        _user = user;
        _sessions = sessions;
        _options = options.Value;
        _logger = logger;
    }

    private void RequireAdmin()
    {
        if (!_user.IsAdmin)
        {
            throw new OrchestrationException(
                "Only an administrator can do this.", HttpStatusCode.Forbidden, "FORBIDDEN");
        }
    }

    // ---------------------------------------------------------------------
    // Groups
    // ---------------------------------------------------------------------

    public async Task<IReadOnlyList<GroupDto>> GetGroupsAsync(CancellationToken cancellationToken = default)
    {
        // Administrators see every group; other users only their own (the UI shows its name).
        var query = _db.UserGroups.AsNoTracking();
        if (!_user.IsAdmin)
        {
            var mine = _user.GroupId;
            query = query.Where(g => g.GroupId == mine);
        }

        var groups = await query.OrderBy(g => g.Name).ToListAsync(cancellationToken);
        var result = new List<GroupDto>();
        foreach (var g in groups)
        {
            result.Add(await ToGroupDtoAsync(g, cancellationToken));
        }

        return result;
    }

    public async Task<GroupDto> CreateGroupAsync(GroupSaveDto dto, CancellationToken cancellationToken = default)
    {
        RequireAdmin();
        var name = ValidateGroupName(dto.Name);

        if (await _db.UserGroups.AnyAsync(g => g.Name == name, cancellationToken))
        {
            throw new OrchestrationException(
                $"A group named '{name}' already exists.", HttpStatusCode.Conflict, "GROUP_EXISTS");
        }

        var entity = new UserGroup { Name = name, Description = NullIfBlank(dto.Description), CreatedAt = DateTime.UtcNow };
        _db.UserGroups.Add(entity);
        await _db.SaveChangesAsync(cancellationToken);
        _logger.LogInformation("{Admin} created group {Group}", _user.Name, name);
        return await ToGroupDtoAsync(entity, cancellationToken);
    }

    public async Task<GroupDto> UpdateGroupAsync(int id, GroupSaveDto dto, CancellationToken cancellationToken = default)
    {
        RequireAdmin();
        var entity = await _db.UserGroups.FirstOrDefaultAsync(g => g.GroupId == id, cancellationToken)
            ?? throw NotFound("Group not found.");

        var name = ValidateGroupName(dto.Name);
        if (await _db.UserGroups.AnyAsync(g => g.Name == name && g.GroupId != id, cancellationToken))
        {
            throw new OrchestrationException(
                $"A group named '{name}' already exists.", HttpStatusCode.Conflict, "GROUP_EXISTS");
        }

        entity.Name = name;
        entity.Description = NullIfBlank(dto.Description);
        await _db.SaveChangesAsync(cancellationToken);
        _logger.LogInformation("{Admin} updated group {GroupId}", _user.Name, id);
        return await ToGroupDtoAsync(entity, cancellationToken);
    }

    public async Task DeleteGroupAsync(int id, CancellationToken cancellationToken = default)
    {
        RequireAdmin();
        var entity = await _db.UserGroups.FirstOrDefaultAsync(g => g.GroupId == id, cancellationToken)
            ?? throw NotFound("Group not found.");

        var users = await _db.AppUsers.CountAsync(u => u.GroupId == id, cancellationToken);
        var steps = await _db.OrchestrationSteps.CountAsync(s => s.GroupId == id, cancellationToken);
        var configs = await _db.ApiConfigs.CountAsync(c => c.GroupId == id, cancellationToken);
        if (users + steps + configs > 0)
        {
            throw new OrchestrationException(
                $"'{entity.Name}' still has {users} user(s), {steps} step(s) and {configs} connection(s). " +
                "Move or delete them first.",
                HttpStatusCode.Conflict, "GROUP_NOT_EMPTY");
        }

        _db.UserGroups.Remove(entity);
        await _db.SaveChangesAsync(cancellationToken);
        _logger.LogInformation("{Admin} deleted group {Group}", _user.Name, entity.Name);
    }

    // ---------------------------------------------------------------------
    // Users
    // ---------------------------------------------------------------------

    public async Task<IReadOnlyList<UserDto>> GetUsersAsync(CancellationToken cancellationToken = default)
    {
        RequireAdmin();
        var groups = await GroupNamesAsync(cancellationToken);
        var users = await _db.AppUsers.AsNoTracking().OrderBy(u => u.Username).ToListAsync(cancellationToken);
        return users.Select(u => ToUserDto(u, groups)).ToList();
    }

    public async Task<UserDto> CreateUserAsync(UserCreateDto dto, CancellationToken cancellationToken = default)
    {
        RequireAdmin();
        var username = ValidateUsername(dto.Username);
        ValidatePassword(dto.Password, username);
        var role = ValidateRole(dto.Role);
        var groupId = await ValidateRoleGroupAsync(role, dto.GroupId, cancellationToken);

        if (await _db.AppUsers.AnyAsync(u => u.Username == username, cancellationToken))
        {
            throw new OrchestrationException(
                $"The user name '{username}' is already taken.", HttpStatusCode.Conflict, "USER_EXISTS");
        }

        var entity = new AppUser
        {
            Username = username,
            PasswordHash = PasswordHashing.Hash(dto.Password),
            Role = role,
            GroupId = groupId,
            Active = true,
            CreatedAt = DateTime.UtcNow
        };
        _db.AppUsers.Add(entity);
        await _db.SaveChangesAsync(cancellationToken);
        _logger.LogInformation("{Admin} created user {Username} ({Role})", _user.Name, username, role);
        return ToUserDto(entity, await GroupNamesAsync(cancellationToken));
    }

    public async Task<UserDto> UpdateUserAsync(int id, UserUpdateDto dto, CancellationToken cancellationToken = default)
    {
        RequireAdmin();
        var entity = await _db.AppUsers.FirstOrDefaultAsync(u => u.UserId == id, cancellationToken)
            ?? throw NotFound("User not found.");

        var role = ValidateRole(dto.Role);
        var groupId = await ValidateRoleGroupAsync(role, dto.GroupId, cancellationToken);

        if (_user.UserId == id && (role != AuthConstants.Role_Admin || !dto.Active))
        {
            throw new ValidationException(
                "You cannot remove your own administrator access or deactivate your own account.", "SELF_LOCKOUT");
        }

        var changedAccess = entity.Role != role || entity.GroupId != groupId || entity.Active != dto.Active;
        entity.Role = role;
        entity.GroupId = groupId;
        entity.Active = dto.Active;
        await _db.SaveChangesAsync(cancellationToken);

        // A changed role, group or an inactive account takes effect immediately: the person must sign in again.
        if (changedAccess)
        {
            await _sessions.RevokeAllForUserAsync(id, cancellationToken);
        }

        _logger.LogInformation("{Admin} updated user {Username}", _user.Name, entity.Username);
        return ToUserDto(entity, await GroupNamesAsync(cancellationToken));
    }

    public async Task ResetPasswordAsync(int id, PasswordResetDto dto, CancellationToken cancellationToken = default)
    {
        RequireAdmin();
        var entity = await _db.AppUsers.FirstOrDefaultAsync(u => u.UserId == id, cancellationToken)
            ?? throw NotFound("User not found.");

        ValidatePassword(dto.Password, entity.Username);
        entity.PasswordHash = PasswordHashing.Hash(dto.Password);
        await _db.SaveChangesAsync(cancellationToken);
        await _sessions.RevokeAllForUserAsync(id, cancellationToken);
        _logger.LogInformation("{Admin} reset the password of {Username}", _user.Name, entity.Username);
    }

    public async Task DeleteUserAsync(int id, CancellationToken cancellationToken = default)
    {
        RequireAdmin();
        if (_user.UserId == id)
        {
            throw new ValidationException("You cannot delete your own account.", "SELF_DELETE");
        }

        var entity = await _db.AppUsers.FirstOrDefaultAsync(u => u.UserId == id, cancellationToken)
            ?? throw NotFound("User not found.");

        await _sessions.RevokeAllForUserAsync(id, cancellationToken);
        _db.AppUsers.Remove(entity);
        await _db.SaveChangesAsync(cancellationToken);
        _logger.LogInformation("{Admin} deleted user {Username}", _user.Name, entity.Username);
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    private async Task<GroupDto> ToGroupDtoAsync(UserGroup g, CancellationToken cancellationToken)
    {
        var scenarios = await _db.OrchestrationSteps
            .Where(s => s.GroupId == g.GroupId)
            .Select(s => s.ProjectName + "/" + s.Environment + "/" + s.ScenarioName)
            .Distinct()
            .CountAsync(cancellationToken);

        return new GroupDto
        {
            GroupId = g.GroupId,
            Name = g.Name,
            Description = g.Description,
            UserCount = await _db.AppUsers.CountAsync(u => u.GroupId == g.GroupId, cancellationToken),
            ScenarioCount = scenarios,
            ConnectionCount = await _db.ApiConfigs.CountAsync(c => c.GroupId == g.GroupId, cancellationToken),
            CreatedAt = g.CreatedAt
        };
    }

    private async Task<Dictionary<int, string>> GroupNamesAsync(CancellationToken cancellationToken) =>
        await _db.UserGroups.AsNoTracking().ToDictionaryAsync(g => g.GroupId, g => g.Name, cancellationToken);

    private static UserDto ToUserDto(AppUser u, Dictionary<int, string> groups) => new()
    {
        UserId = u.UserId,
        Username = u.Username,
        Role = u.Role,
        GroupId = u.GroupId,
        GroupName = u.GroupId.HasValue && groups.TryGetValue(u.GroupId.Value, out var name) ? name : null,
        Active = u.Active,
        CreatedAt = u.CreatedAt,
        LastLoginAt = u.LastLoginAt
    };

    private static string ValidateGroupName(string? name)
    {
        var value = (name ?? string.Empty).Trim();
        if (value.Length == 0 || value.Length > 100 || value.Any(char.IsControl))
        {
            throw new ValidationException("A group name must be 1 to 100 characters.", "GROUP_NAME_INVALID");
        }

        return value;
    }

    private static string ValidateUsername(string? name)
    {
        var value = (name ?? string.Empty).Trim();
        if (!UsernamePattern.IsMatch(value))
        {
            throw new ValidationException(
                "A user name must be 3 to 64 characters: letters, digits, '.', '_', '-' and '@' only.",
                "USERNAME_INVALID");
        }

        return value;
    }

    private void ValidatePassword(string? password, string username)
    {
        var min = _options.MinPasswordLength > 0 ? _options.MinPasswordLength : 8;
        if (string.IsNullOrEmpty(password) || password.Length < min || password.Length > 128)
        {
            throw new ValidationException(
                $"The password must be {min} to 128 characters long.", "PASSWORD_INVALID");
        }

        if (string.Equals(password, username, StringComparison.OrdinalIgnoreCase))
        {
            throw new ValidationException("The password must not be the same as the user name.", "PASSWORD_INVALID");
        }
    }

    private static string ValidateRole(string? role)
    {
        var value = (role ?? string.Empty).Trim().ToUpperInvariant();
        if (value != AuthConstants.Role_Admin && value != AuthConstants.Role_User)
        {
            throw new ValidationException("The role must be ADMIN or USER.", "ROLE_INVALID");
        }

        return value;
    }

    /// <summary>A USER must belong to an existing group; an ADMIN belongs to none.</summary>
    private async Task<int?> ValidateRoleGroupAsync(string role, int? groupId, CancellationToken cancellationToken)
    {
        if (role == AuthConstants.Role_Admin)
        {
            return null;
        }

        if (groupId == null || !await _db.UserGroups.AnyAsync(g => g.GroupId == groupId, cancellationToken))
        {
            throw new ValidationException("Choose the group this user belongs to.", "GROUP_REQUIRED");
        }

        return groupId;
    }

    private static string? NullIfBlank(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();

    private static OrchestrationException NotFound(string message) =>
        new(message, HttpStatusCode.NotFound, "NOT_FOUND");
}
