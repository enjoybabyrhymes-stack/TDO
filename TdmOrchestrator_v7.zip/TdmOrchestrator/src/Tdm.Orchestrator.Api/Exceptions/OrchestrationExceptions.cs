using System.Net;

namespace Tdm.Orchestrator.Domain.Exceptions;

/// <summary>Application-specific exception with HTTP status code context.</summary>
public class OrchestrationException : Exception
{
    public HttpStatusCode StatusCode { get; }
    public string? ErrorCode { get; }

    public OrchestrationException(string message, HttpStatusCode statusCode = HttpStatusCode.InternalServerError, string? errorCode = null)
        : base(message)
    {
        StatusCode = statusCode;
        ErrorCode = errorCode;
    }
}

/// <summary>Validation error during orchestration setup or execution.</summary>
public class ValidationException : OrchestrationException
{
    public ValidationException(string message, string? errorCode = null)
        : base(message, HttpStatusCode.BadRequest, errorCode)
    {
    }
}

/// <summary>Configuration not found or invalid.</summary>
public class ConfigurationException : OrchestrationException
{
    public ConfigurationException(string message)
        : base(message, HttpStatusCode.InternalServerError, "CONFIG_NOT_FOUND")
    {
    }
}
