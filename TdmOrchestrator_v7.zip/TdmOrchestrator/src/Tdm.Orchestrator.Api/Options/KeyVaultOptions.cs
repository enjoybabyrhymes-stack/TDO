namespace Tdm.Orchestrator.Options;

/// <summary>
/// Azure Key Vault settings. Bound from the "KeyVault" section.
/// When <see cref="Uri"/> is empty the vault is not used and configuration comes only from
/// appsettings / environment variables (the normal setup for local development).
/// </summary>
public class KeyVaultOptions
{
    public const string SectionName = "KeyVault";

    /// <summary>Vault address, e.g. https://my-vault.vault.azure.net/ . Not a secret.</summary>
    public string? Uri { get; set; }

    /// <summary>
    /// Client id of a user-assigned managed identity. Leave empty to use the system-assigned
    /// identity of the host.
    /// </summary>
    public string? ManagedIdentityClientId { get; set; }
}
