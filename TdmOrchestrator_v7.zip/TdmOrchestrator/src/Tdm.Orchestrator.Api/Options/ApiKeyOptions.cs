namespace Tdm.Orchestrator.Options;

/// <summary>
/// Configuration for API-key authentication. Bind from the "ApiKey" section of
/// appsettings.json / environment variables — nothing here is hardcoded.
/// </summary>
public class ApiKeyOptions
{
    /// <summary>The HTTP header clients must send the key in.</summary>
    public string HeaderName { get; set; } = "X-Api-Key";

    /// <summary>
    /// One or more valid keys. Supports multiple so different consumers (or different
    /// environments sharing one deployment) can each have their own key, which can be
    /// individually rotated/revoked without affecting others.
    ///
    /// SET THIS VIA ENVIRONMENT VARIABLE OR SECRETS MANAGER IN EVERY REAL ENVIRONMENT.
    /// Never commit real keys into appsettings.json.
    /// </summary>
    public string[] ValidKeys { get; set; } = Array.Empty<string>();
}
