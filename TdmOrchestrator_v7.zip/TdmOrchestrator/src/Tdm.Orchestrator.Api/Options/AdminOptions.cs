namespace Tdm.Orchestrator.Options;

/// <summary>
/// Access keys for the admin API and web UI (scenario and connection management).
/// These are deliberately separate from <see cref="ApiKeyOptions"/>: holding a key that can
/// run scenarios must not allow editing them. With no keys configured, admin access is disabled.
/// </summary>
public class AdminOptions
{
    public const string SectionName = "Admin";

    /// <summary>The HTTP header the admin key is sent in.</summary>
    public string HeaderName { get; set; } = "X-Admin-Key";

    /// <summary>Valid admin keys. Supply them from Key Vault or environment variables.</summary>
    public string[] ApiKeys { get; set; } = Array.Empty<string>();

    /// <summary>How long a username/password sign-in stays valid, in hours.</summary>
    public int SessionHours { get; set; } = 8;

    /// <summary>Minimum length of a user's password.</summary>
    public int MinPasswordLength { get; set; } = 8;
}
