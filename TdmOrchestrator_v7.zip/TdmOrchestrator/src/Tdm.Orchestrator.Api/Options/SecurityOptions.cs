namespace Tdm.Orchestrator.Options;

/// <summary>
/// Security policy toggles. Bind from the "Security" section of configuration.
/// </summary>
public class SecurityOptions
{
    /// <summary>
    /// When true, blocks outbound calls to ANY private network range (10.0.0.0/8,
    /// 172.16.0.0/12, 192.168.0.0/16, and IPv6 equivalents) in addition to the
    /// always-blocked loopback and link-local/cloud-metadata ranges.
    ///
    /// Default false, because many real deployments legitimately call internal
    /// systems on a private network (e.g. an on-prem HR system on a 10.x address).
    /// Set to true only if every OrchestrationStep in this deployment is fully
    /// trusted to never let caller-supplied input control the target host.
    /// </summary>
    public bool BlockAllPrivateNetworks { get; set; } = false;
}
