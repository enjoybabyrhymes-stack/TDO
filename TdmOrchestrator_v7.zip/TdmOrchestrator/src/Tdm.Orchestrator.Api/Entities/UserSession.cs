using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tdm.Orchestrator.Domain.Entities;

/// <summary>A sign-in. Only a SHA-256 hash of the session token is stored, never the token itself.</summary>
[Table("UserSessions")]
public class UserSession
{
    [Key]
    public long SessionId { get; set; }

    [Required, MaxLength(64)]
    public string TokenHash { get; set; } = string.Empty;

    public int UserId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public DateTime ExpiresAt { get; set; }
}
