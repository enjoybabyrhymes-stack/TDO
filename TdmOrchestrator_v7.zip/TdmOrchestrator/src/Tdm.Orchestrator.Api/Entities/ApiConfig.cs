using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tdm.Orchestrator.Domain.Entities;

/// <summary>
/// Database-driven configuration values. Supports base URLs for different environments
/// and reusable placeholder values referenced via "$KEY" tokens in orchestration steps.
/// </summary>
[Table("ApiConfig")]
public class ApiConfig
{
    [Key]
    public int Id { get; set; }

    [Required, MaxLength(150)]
    public string ConfigKey { get; set; } = string.Empty;

    [Required]
    public string ConfigValue { get; set; } = string.Empty;

    public string? Description { get; set; }

    /// <summary>The group that owns this connection. Null = not assigned yet: admin-only. A key is unique per group.</summary>
    public int? GroupId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}
