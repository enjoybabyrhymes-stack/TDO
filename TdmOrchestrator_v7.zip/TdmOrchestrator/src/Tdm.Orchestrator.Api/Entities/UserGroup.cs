using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tdm.Orchestrator.Domain.Entities;

/// <summary>A team. Scenarios, steps and connections belong to a group; its users see only that data.</summary>
[Table("UserGroups")]
public class UserGroup
{
    [Key]
    public int GroupId { get; set; }

    [Required, MaxLength(100)]
    public string Name { get; set; } = string.Empty;

    [MaxLength(500)]
    public string? Description { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
