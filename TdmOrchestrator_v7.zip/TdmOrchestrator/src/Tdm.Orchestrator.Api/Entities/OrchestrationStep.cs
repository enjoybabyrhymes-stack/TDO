using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Tdm.Orchestrator.Domain.Constants;

namespace Tdm.Orchestrator.Domain.Entities;

/// <summary>
/// Database-driven orchestration step definition. Each scenario is a sequence of steps
/// stored as rows in this table. To add or modify a scenario, edit the table data directly — 
/// no code changes required.
/// </summary>
[Table("OrchestrationSteps")]
public class OrchestrationStep
{
    [Key]
    public int ServiceId { get; set; }

    [Required, MaxLength(100)]
    public string ProjectName { get; set; } = string.Empty;

    [Required, MaxLength(100)]
    public string Environment { get; set; } = string.Empty;

    [Required, MaxLength(150)]
    public string ScenarioName { get; set; } = string.Empty;

    [Required]
    public int StepOrder { get; set; }

    public string? StepDescription { get; set; }

    /// <summary>RESTAPI (calls an external endpoint) or CONSOLIDATE (aggregates previous steps).</summary>
    [Required, MaxLength(30)]
    public string StepType { get; set; } = string.Empty;

    /// <summary>
    /// API Configuration key that resolves to a base URL. Leave null if Endpoint is a full URL.
    /// </summary>
    [MaxLength(150)]
    public string? BaseUrlConfigKey { get; set; }

    /// <summary>
    /// Endpoint path or full URL. Supports placeholder tokens like {step1.id} or {step2[0].id}.
    /// </summary>
    public string? Endpoint { get; set; }

    [MaxLength(10)]
    public string? HttpMethod { get; set; }

    /// <summary>
    /// JSON template for request body and/or headers. Supports "$token" placeholders
    /// for referencing previous step outputs or configuration values.
    /// </summary>
    public string? InputParamMap { get; set; }

    /// <summary>JSON template for CONSOLIDATE step output. Aggregates fields from previous steps.</summary>
    public string? OutputParamMap { get; set; }

    /// <summary>
    /// Number of EXTRA attempts allowed after the first try if a step's HTTP call fails
    /// with a server-side/network error (HTTP 5xx). 0 = no retries. Now enforced by
    /// TestDataOrchestrationService.ExecuteStepAsync.
    /// </summary>
    public int RetryCount { get; set; } = OrchestrationConstants.DefaultRetryCount;

    public int TimeoutSeconds { get; set; } = OrchestrationConstants.DefaultTimeoutSeconds;

    /// <summary>
    /// One-time delay (seconds) BEFORE this step runs. Not used for polling; see PollIntervalSeconds.
    /// </summary>
    public int WaitTimeSeconds { get; set; } = 0;

    /// <summary>
    /// Polling: seconds between status checks. 0 = this step does not use the dedicated polling settings.
    /// Polling is switched on by a "poll" block (the condition) in InputParamMap and timed by this column
    /// and PollMaxWaitSeconds. Steps with a poll block but both columns at 0 use the original convention
    /// (RetryCount = extra polls, WaitTimeSeconds = interval) so existing scenarios keep working.
    /// </summary>
    public int PollIntervalSeconds { get; set; } = 0;

    /// <summary>Polling: total seconds to keep checking before the step fails as timed out.</summary>
    public int PollMaxWaitSeconds { get; set; } = 0;

    /// <summary>The group that owns this step (all steps of a scenario share one). Null = not assigned yet: admin-only.</summary>
    public int? GroupId { get; set; }

    [Required, MaxLength(1)]
    public string ActiveFlag { get; set; } = OrchestrationConstants.ActiveFlag_Active;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
}
