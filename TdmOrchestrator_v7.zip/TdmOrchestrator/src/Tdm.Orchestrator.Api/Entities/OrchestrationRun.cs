using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tdm.Orchestrator.Domain.Entities;

/// <summary>
/// Audit record for each step execution within an orchestration run.
/// Enables tracing, debugging, and compliance tracking.
/// </summary>
[Table("OrchestrationRuns")]
public class OrchestrationRun
{
    [Key]
    public long RunId { get; set; }

    [MaxLength(100)]
    public string ProjectName { get; set; } = string.Empty;

    [MaxLength(100)]
    public string Environment { get; set; } = string.Empty;

    [MaxLength(150)]
    public string ScenarioName { get; set; } = string.Empty;

    public int ServiceId { get; set; }

    public int StepOrder { get; set; }

    /// <summary>Identifies one execution of a scenario: every step row of that execution shares it. Null for rows written before this column existed.</summary>
    [MaxLength(36)]
    public string? RunGroupId { get; set; }

    /// <summary>Fully resolved URL that was called (for debugging). Null for CONSOLIDATE steps.</summary>
    public string? RequestUrl { get; set; }

    public DateTime ExecutionStartTime { get; set; } = DateTime.UtcNow;

    public DateTime? ExecutionEndTime { get; set; }

    [MaxLength(20)]
    public string? Status { get; set; }

    /// <summary>
    /// How many attempts (including the first) were made for this step.
    /// 1 = succeeded on the first try. Only meaningful for RESTAPI steps —
    /// CONSOLIDATE steps don't call anything, so this stays 1.
    /// NOTE: new column — see PRODUCTION_HARDENING.md if you're applying this
    /// on top of a database that already has an OrchestrationRuns table.
    /// </summary>
    public int AttemptCount { get; set; } = 1;

    public string? ErrorMessage { get; set; }

    [MaxLength(100)]
    public string? ExecutedBy { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
