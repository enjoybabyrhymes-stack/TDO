using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tdm.Orchestrator.Domain.Entities;

/// <summary>
/// A person who signs in to the admin UI. Role ADMIN manages groups, users and all data; role USER works only
/// inside their group (GroupId is required for USER and empty for ADMIN).
/// </summary>
[Table("AppUsers")]
public class AppUser
{
    [Key]
    public int UserId { get; set; }

    [Required, MaxLength(100)]
    public string Username { get; set; } = string.Empty;

    /// <summary>PBKDF2 hash in the form "v1.iterations.salt.hash". The password itself is never stored.</summary>
    [Required, MaxLength(400)]
    public string PasswordHash { get; set; } = string.Empty;

    [Required, MaxLength(10)]
    public string Role { get; set; } = "USER";

    public int? GroupId { get; set; }

    public bool Active { get; set; } = true;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public DateTime? LastLoginAt { get; set; }
}
