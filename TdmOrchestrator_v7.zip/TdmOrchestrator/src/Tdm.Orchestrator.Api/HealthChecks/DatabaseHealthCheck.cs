using Microsoft.Extensions.Diagnostics.HealthChecks;
using Tdm.Orchestrator.Infrastructure.Persistence;

namespace Tdm.Orchestrator.Infrastructure.HealthChecks;

/// <summary>
/// Actually checks the database connection, instead of the previous setup where
/// AddHealthChecks() was registered with no checks at all — meaning /health/ready
/// always returned "healthy" even if the database was completely unreachable.
/// </summary>
public class DatabaseHealthCheck : IHealthCheck
{
    private readonly OrchestratorDbContext _db;

    public DatabaseHealthCheck(OrchestratorDbContext db)
    {
        _db = db;
    }

    public async Task<HealthCheckResult> CheckHealthAsync(
        HealthCheckContext context,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var canConnect = await _db.Database.CanConnectAsync(cancellationToken);
            return canConnect
                ? HealthCheckResult.Healthy("Database connection OK")
                : HealthCheckResult.Unhealthy("Cannot connect to the database");
        }
        catch (Exception ex)
        {
            return HealthCheckResult.Unhealthy("Database health check threw an exception", ex);
        }
    }
}
