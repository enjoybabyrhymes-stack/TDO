using Tdm.Orchestrator.Application.DTOs;
using Tdm.Orchestrator.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace Tdm.Orchestrator.Api.Controllers;

/// <summary>Orchestration execution endpoints.</summary>
[ApiController]
[Route("api/v1/orchestrator")]
[Produces("application/json")]
public class OrchestratorController : ControllerBase
{
    private readonly IOrchestratorService _orchestratorService;
    private readonly IOrchestrationValidator _validator;
    private readonly ILogger<OrchestratorController> _logger;

    public OrchestratorController(
        IOrchestratorService orchestratorService,
        IOrchestrationValidator validator,
        ILogger<OrchestratorController> logger)
    {
        _orchestratorService = orchestratorService;
        _validator = validator;
        _logger = logger;
    }

    /// <summary>
    /// Execute an orchestration scenario.
    /// </summary>
    [HttpPost("run/{project}/{environment}/{scenario}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public async Task<IActionResult> ExecuteScenario(
        [FromRoute] string project,
        [FromRoute] string environment,
        [FromRoute] string scenario,
        [FromBody] OrchestratorRunOptionsDto? options,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(project) || string.IsNullOrWhiteSpace(environment) || string.IsNullOrWhiteSpace(scenario))
        {
            return BadRequest(new { error = "Project, environment, and scenario are required" });
        }

        if (!await _validator.IsValidProjectAsync(project, cancellationToken))
        {
            return BadRequest(new ValidationErrorDto
            {
                Error = "Invalid project",
                Options = (await _validator.GetProjectsAsync(cancellationToken)).ToList()
            });
        }

        if (!await _validator.IsValidEnvironmentAsync(project, environment, cancellationToken))
        {
            return BadRequest(new ValidationErrorDto
            {
                Error = "Invalid environment",
                Options = (await _validator.GetEnvironmentsAsync(project, cancellationToken)).ToList()
            });
        }

        if (!await _validator.IsValidScenarioAsync(project, environment, scenario, cancellationToken))
        {
            return BadRequest(new ValidationErrorDto
            {
                Error = "Invalid scenario",
                Options = (await _validator.GetScenariosAsync(project, environment, cancellationToken)).ToList()
            });
        }

        var input = new OrchestratorInputDto
        {
            ProjectName = project,
            Environment = environment,
            Scenario = scenario,
            UserId = options?.UserId,
            TestCaseId = options?.TestCaseId,
            InputData = options?.InputData
        };

        _logger.LogInformation("Executing scenario {Project}/{Environment}/{Scenario}", project, environment, scenario);

        var result = await _orchestratorService.ExecuteAsync(input, cancellationToken);
        return Ok(result);
    }

    /// <summary>
    /// Get available projects.
    /// </summary>
    [HttpGet("projects")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public async Task<IActionResult> GetProjects(CancellationToken cancellationToken)
    {
        var projects = await _validator.GetProjectsAsync(cancellationToken);
        return Ok(new { projects });
    }

    /// <summary>
    /// Get available environments for a project.
    /// </summary>
    [HttpGet("environments")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> GetEnvironments([FromQuery] string project, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(project))
        {
            return BadRequest(new { error = "Project is required" });
        }

        if (!await _validator.IsValidProjectAsync(project, cancellationToken))
        {
            return BadRequest(new { error = "Invalid project" });
        }

        var environments = await _validator.GetEnvironmentsAsync(project, cancellationToken);
        return Ok(new { environments });
    }

    /// <summary>
    /// Get available scenarios for a project and environment.
    /// </summary>
    [HttpGet("scenarios")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> GetScenarios(
        [FromQuery] string project,
        [FromQuery] string environment,
        CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(project) || string.IsNullOrWhiteSpace(environment))
        {
            return BadRequest(new { error = "Project and environment are required" });
        }

        if (!await _validator.IsValidProjectAsync(project, cancellationToken))
        {
            return BadRequest(new { error = "Invalid project" });
        }

        if (!await _validator.IsValidEnvironmentAsync(project, environment, cancellationToken))
        {
            return BadRequest(new { error = "Invalid environment" });
        }

        var scenarios = await _validator.GetScenariosAsync(project, environment, cancellationToken);
        return Ok(new { scenarios });
    }
}
