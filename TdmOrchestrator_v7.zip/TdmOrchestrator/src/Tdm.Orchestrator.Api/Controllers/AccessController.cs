using Microsoft.AspNetCore.Mvc;
using Tdm.Orchestrator.Application.DTOs;
using Tdm.Orchestrator.Application.Interfaces;
using Tdm.Orchestrator.Infrastructure.Middleware;

namespace Tdm.Orchestrator.Api.Controllers;

/// <summary>Groups and users. Listing groups is open to every signed-in user (their own group); everything else is admin-only.</summary>
[ApiController]
[Route("api/v1/admin")]
[Produces("application/json")]
[ServiceFilter(typeof(AdminKeyFilter))]
public class AccessController : ControllerBase
{
    private readonly IAccessAdminService _access;

    public AccessController(IAccessAdminService access)
    {
        _access = access;
    }

    // ---- Groups -----------------------------------------------------------

    [HttpGet("groups")]
    public async Task<IActionResult> GetGroups(CancellationToken cancellationToken) =>
        Ok(await _access.GetGroupsAsync(cancellationToken));

    [HttpPost("groups")]
    public async Task<IActionResult> CreateGroup([FromBody] GroupSaveDto dto, CancellationToken cancellationToken) =>
        Ok(await _access.CreateGroupAsync(dto, cancellationToken));

    [HttpPut("groups/{id:int}")]
    public async Task<IActionResult> UpdateGroup(int id, [FromBody] GroupSaveDto dto, CancellationToken cancellationToken) =>
        Ok(await _access.UpdateGroupAsync(id, dto, cancellationToken));

    [HttpDelete("groups/{id:int}")]
    public async Task<IActionResult> DeleteGroup(int id, CancellationToken cancellationToken)
    {
        await _access.DeleteGroupAsync(id, cancellationToken);
        return NoContent();
    }

    // ---- Users ------------------------------------------------------------

    [HttpGet("users")]
    public async Task<IActionResult> GetUsers(CancellationToken cancellationToken) =>
        Ok(await _access.GetUsersAsync(cancellationToken));

    [HttpPost("users")]
    public async Task<IActionResult> CreateUser([FromBody] UserCreateDto dto, CancellationToken cancellationToken) =>
        Ok(await _access.CreateUserAsync(dto, cancellationToken));

    [HttpPut("users/{id:int}")]
    public async Task<IActionResult> UpdateUser(int id, [FromBody] UserUpdateDto dto, CancellationToken cancellationToken) =>
        Ok(await _access.UpdateUserAsync(id, dto, cancellationToken));

    [HttpPost("users/{id:int}/password")]
    public async Task<IActionResult> ResetPassword(int id, [FromBody] PasswordResetDto dto, CancellationToken cancellationToken)
    {
        await _access.ResetPasswordAsync(id, dto, cancellationToken);
        return NoContent();
    }

    [HttpDelete("users/{id:int}")]
    public async Task<IActionResult> DeleteUser(int id, CancellationToken cancellationToken)
    {
        await _access.DeleteUserAsync(id, cancellationToken);
        return NoContent();
    }
}
