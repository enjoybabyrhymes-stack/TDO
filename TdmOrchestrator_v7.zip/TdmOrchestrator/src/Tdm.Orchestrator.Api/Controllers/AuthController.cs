using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using Tdm.Orchestrator.Application.DTOs;
using Tdm.Orchestrator.Application.Services;
using Tdm.Orchestrator.Application.Utilities;
using Tdm.Orchestrator.Domain.Constants;
using Tdm.Orchestrator.Infrastructure.Middleware;
using Tdm.Orchestrator.Infrastructure.Persistence;

namespace Tdm.Orchestrator.Api.Controllers;

/// <summary>Sign in, sign out and "who am I" for the admin UI.</summary>
[ApiController]
[Route("api/v1/admin/auth")]
[Produces("application/json")]
public class AuthController : ControllerBase
{
    private readonly OrchestratorDbContext _db;
    private readonly ISessionService _sessions;
    private readonly CurrentUser _current;
    private readonly ILogger<AuthController> _logger;

    public AuthController(
        OrchestratorDbContext db, ISessionService sessions, CurrentUser current, ILogger<AuthController> logger)
    {
        _db = db;
        _sessions = sessions;
        _current = current;
        _logger = logger;
    }

    [HttpPost("login")]
    [EnableRateLimiting("login")]
    public async Task<IActionResult> Login([FromBody] LoginDto dto, CancellationToken cancellationToken)
    {
        var username = (dto.Username ?? string.Empty).Trim();
        var user = username.Length == 0
            ? null
            : await _db.AppUsers.FirstOrDefaultAsync(u => u.Username == username, cancellationToken);

        // Always verify a hash (a dummy one when the user does not exist) so timing does not reveal valid user names.
        var passwordOk = PasswordHashing.Verify(dto.Password ?? string.Empty, user?.PasswordHash ?? PasswordHashing.DummyHash);
        if (user == null || !user.Active || !passwordOk)
        {
            _logger.LogWarning("Failed sign-in for '{Username}' from {RemoteIp}", username, HttpContext.Connection.RemoteIpAddress);
            return Unauthorized(new { error = "Invalid user name or password." });
        }

        user.LastLoginAt = DateTime.UtcNow;
        await _db.SaveChangesAsync(cancellationToken);

        var (token, expires) = await _sessions.CreateAsync(user, cancellationToken);
        _logger.LogInformation("{Username} signed in", user.Username);

        return Ok(new LoginResultDto
        {
            Token = token,
            ExpiresAt = expires,
            User = await BuildInfoAsync(user.UserId, user.Username, user.Role, user.GroupId, false, cancellationToken)
        });
    }

    [HttpGet("me")]
    [ServiceFilter(typeof(AdminKeyFilter))]
    public async Task<IActionResult> Me(CancellationToken cancellationToken) =>
        Ok(await BuildInfoAsync(
            _current.UserId,
            _current.Name,
            _current.IsAdmin ? AuthConstants.Role_Admin : AuthConstants.Role_User,
            _current.GroupId,
            _current.UserId == null,
            cancellationToken));

    [HttpPost("logout")]
    [ServiceFilter(typeof(AdminKeyFilter))]
    public async Task<IActionResult> Logout(CancellationToken cancellationToken)
    {
        var authorization = Request.Headers.Authorization.ToString();
        if (authorization.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
        {
            await _sessions.RevokeAsync(authorization.Substring(7).Trim(), cancellationToken);
        }

        return NoContent();
    }

    private async Task<UserInfoDto> BuildInfoAsync(
        int? userId, string username, string role, int? groupId, bool viaAdminKey, CancellationToken cancellationToken)
    {
        string? groupName = null;
        if (groupId.HasValue)
        {
            groupName = await _db.UserGroups.AsNoTracking()
                .Where(g => g.GroupId == groupId)
                .Select(g => g.Name)
                .FirstOrDefaultAsync(cancellationToken);
        }

        return new UserInfoDto
        {
            UserId = userId,
            Username = username,
            Role = role,
            GroupId = groupId,
            GroupName = groupName,
            ViaAdminKey = viaAdminKey
        };
    }
}
