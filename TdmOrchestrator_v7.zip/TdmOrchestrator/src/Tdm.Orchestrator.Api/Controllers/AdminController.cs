using Microsoft.AspNetCore.Mvc;
using Tdm.Orchestrator.Application.DTOs;
using Tdm.Orchestrator.Application.Interfaces;
using Tdm.Orchestrator.Infrastructure.Middleware;

namespace Tdm.Orchestrator.Api.Controllers;

/// <summary>
/// Management API behind the admin UI: connections, scenarios, steps, validation, Postman export
/// and run history. Protected by the separate admin key (see <see cref="AdminKeyFilter"/>), not by
/// the key used to run scenarios.
/// </summary>
[ApiController]
[Route("api/v1/admin")]
[Produces("application/json")]
[ServiceFilter(typeof(AdminKeyFilter))]
public class AdminController : ControllerBase
{
    private readonly IScenarioAdminService _admin;

    public AdminController(IScenarioAdminService admin)
    {
        _admin = admin;
    }

    // ---- Connections ------------------------------------------------------

    [HttpGet("configs")]
    public async Task<IActionResult> GetConfigs(CancellationToken cancellationToken) =>
        Ok(await _admin.GetConfigsAsync(cancellationToken));

    [HttpPost("configs")]
    public async Task<IActionResult> CreateConfig([FromBody] ConfigSaveDto dto, CancellationToken cancellationToken) =>
        Ok(await _admin.CreateConfigAsync(dto, cancellationToken));

    [HttpPut("configs/{id:int}")]
    public async Task<IActionResult> UpdateConfig(int id, [FromBody] ConfigSaveDto dto, CancellationToken cancellationToken) =>
        Ok(await _admin.UpdateConfigAsync(id, dto, cancellationToken));

    [HttpDelete("configs/{id:int}")]
    public async Task<IActionResult> DeleteConfig(int id, CancellationToken cancellationToken)
    {
        await _admin.DeleteConfigAsync(id, cancellationToken);
        return NoContent();
    }

    // ---- Scenarios --------------------------------------------------------

    [HttpGet("scenarios")]
    public async Task<IActionResult> GetScenarios(CancellationToken cancellationToken) =>
        Ok(await _admin.GetScenariosAsync(cancellationToken));

    [HttpGet("scenarios/{project}/{environment}/{scenario}/steps")]
    public async Task<IActionResult> GetSteps(
        string project, string environment, string scenario, CancellationToken cancellationToken) =>
        Ok(await _admin.GetStepsAsync(project, environment, scenario, cancellationToken));

    [HttpPost("scenarios/clone")]
    public async Task<IActionResult> CloneScenario([FromBody] CloneScenarioDto dto, CancellationToken cancellationToken)
    {
        await _admin.CloneScenarioAsync(dto, cancellationToken);
        return NoContent();
    }

    [HttpPost("scenarios/{project}/{environment}/{scenario}/active")]
    public async Task<IActionResult> SetActive(
        string project, string environment, string scenario,
        [FromBody] ScenarioActiveDto dto, CancellationToken cancellationToken)
    {
        await _admin.SetScenarioActiveAsync(project, environment, scenario, dto.Active, cancellationToken);
        return NoContent();
    }

    [HttpGet("scenarios/check-name")]
    public async Task<ActionResult<ScenarioNameCheckDto>> CheckScenarioName(
        [FromQuery] string project, [FromQuery] string environment, [FromQuery] string scenario,
        CancellationToken cancellationToken)
    {
        return Ok(await _admin.CheckScenarioNameAsync(
            project ?? string.Empty, environment ?? string.Empty, scenario ?? string.Empty, cancellationToken));
    }

    [HttpPost("scenarios/{project}/{environment}/{scenario}/group")]
    public async Task<IActionResult> AssignGroup(
        string project, string environment, string scenario,
        [FromBody] AssignGroupDto dto, CancellationToken cancellationToken)
    {
        await _admin.AssignScenarioGroupAsync(project, environment, scenario, dto.GroupId, cancellationToken);
        return NoContent();
    }

    [HttpDelete("scenarios/{project}/{environment}/{scenario}")]
    public async Task<IActionResult> DeleteScenario(
        string project, string environment, string scenario, CancellationToken cancellationToken)
    {
        await _admin.DeleteScenarioAsync(project, environment, scenario, cancellationToken);
        return NoContent();
    }

    [HttpGet("scenarios/{project}/{environment}/{scenario}/validate")]
    public async Task<IActionResult> Validate(
        string project, string environment, string scenario, CancellationToken cancellationToken) =>
        Ok(await _admin.ValidateScenarioAsync(project, environment, scenario, cancellationToken));

    [HttpGet("scenarios/{project}/{environment}/{scenario}/postman")]
    public async Task<IActionResult> Postman(
        string project, string environment, string scenario, CancellationToken cancellationToken) =>
        Ok(await _admin.BuildPostmanExportAsync(project, environment, scenario, cancellationToken));

    // ---- Steps ------------------------------------------------------------

    [HttpPost("steps")]
    public async Task<IActionResult> CreateStep([FromBody] StepDto dto, CancellationToken cancellationToken) =>
        Ok(await _admin.CreateStepAsync(dto, cancellationToken));

    [HttpPut("steps/{id:int}")]
    public async Task<IActionResult> UpdateStep(int id, [FromBody] StepDto dto, CancellationToken cancellationToken) =>
        Ok(await _admin.UpdateStepAsync(id, dto, cancellationToken));

    [HttpPost("steps/{id:int}/move")]
    public async Task<IActionResult> MoveStep(int id, [FromBody] MoveStepDto dto, CancellationToken cancellationToken)
    {
        await _admin.MoveStepAsync(id, string.Equals(dto?.Direction, "up", StringComparison.OrdinalIgnoreCase), cancellationToken);
        return NoContent();
    }

    [HttpDelete("steps/{id:int}")]
    public async Task<IActionResult> DeleteStep(int id, CancellationToken cancellationToken)
    {
        await _admin.DeleteStepAsync(id, cancellationToken);
        return NoContent();
    }

    // ---- Run history ------------------------------------------------------

    [HttpGet("runs")]
    public async Task<IActionResult> GetRuns(
        [FromQuery] string? project, [FromQuery] string? environment, [FromQuery] string? scenario,
        [FromQuery] int take = 50, CancellationToken cancellationToken = default) =>
        Ok(await _admin.GetRunsAsync(project, environment, scenario, take, cancellationToken));
}
