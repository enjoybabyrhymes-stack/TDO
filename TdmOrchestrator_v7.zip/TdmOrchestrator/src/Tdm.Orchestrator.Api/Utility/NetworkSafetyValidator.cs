using System.Net;
using System.Net.Sockets;

namespace Tdm.Orchestrator.Application.Utilities;

/// <summary>
/// SSRF (Server-Side Request Forgery) protection. HttpApiClient's original scheme
/// check (http/https only) blocks obviously wrong protocols, but does nothing to
/// stop a step whose target host is influenced by caller input from reaching
/// internal infrastructure. This resolves the target hostname to an actual IP and
/// checks it against known-dangerous ranges before the call is allowed through.
///
/// Loopback addresses (localhost / 127.0.0.1 / ::1) can be allowed explicitly
/// for local development scenarios such as Mockoon. They remain blocked by
/// default and should not be allowed in production.
/// </summary>
public static class NetworkSafetyValidator
{
    /// <summary>
    /// Returns (true, null) if the target is safe to call, or (false, reason) if it
    /// should be blocked.
    ///
    /// "Always blocked" ranges apply regardless of configuration, except loopback
    /// when allowLoopback is explicitly enabled for local development.
    ///
    /// The full private-network block is opt-in via
    /// SecurityOptions.BlockAllPrivateNetworks because many legitimate deployments
    /// call internal systems on a private network.
    /// </summary>
    public static async Task<(bool IsSafe, string? Reason)> IsSafeTargetAsync(
        Uri uri,
        bool blockAllPrivateNetworks,
        bool allowLoopback = false)
    {
        IPAddress[] addresses;

        try
        {
            addresses =
                (uri.HostNameType == UriHostNameType.IPv4 ||
                 uri.HostNameType == UriHostNameType.IPv6)
                    ? new[] { IPAddress.Parse(uri.Host) }
                    : await Dns.GetHostAddressesAsync(uri.Host);
        }
        catch (Exception ex)
        {
            return (
                false,
                $"Could not resolve host '{uri.Host}': {ex.Message}"
            );
        }

        if (addresses.Length == 0)
        {
            return (
                false,
                $"Host '{uri.Host}' did not resolve to any address."
            );
        }

        foreach (var ip in addresses)
        {
            if (IsAlwaysBlocked(ip, allowLoopback))
            {
                return (
                    false,
                    $"Target resolves to a blocked address ({ip}) — " +
                    "loopback and link-local/cloud-metadata addresses are not allowed " +
                    "unless explicitly permitted for local development."
                );
            }

            if (blockAllPrivateNetworks && IsPrivateNetwork(ip))
            {
                return (
                    false,
                    $"Target resolves to a private network address ({ip}), " +
                    "which is blocked by current security policy " +
                    "(Security:BlockAllPrivateNetworks)."
                );
            }
        }

        return (true, null);
    }

    /// <summary>
    /// Ranges blocked regardless of configuration:
    ///
    /// - Loopback (127.0.0.1 / ::1), unless explicitly allowed for local development.
    /// - IPv4 link-local (169.254.0.0/16), which includes cloud metadata endpoints
    ///   such as 169.254.169.254.
    /// - IPv6 link-local addresses.
    /// </summary>
    private static bool IsAlwaysBlocked(
        IPAddress ip,
        bool allowLoopback)
    {
        // Allow localhost only when explicitly enabled by the caller.
        if (!allowLoopback && IPAddress.IsLoopback(ip))
        {
            return true;
        }

        if (ip.AddressFamily == AddressFamily.InterNetwork)
        {
            var b = ip.GetAddressBytes();

            // 169.254.0.0/16
            // Includes cloud instance metadata endpoint 169.254.169.254.
            if (b[0] == 169 && b[1] == 254)
            {
                return true;
            }
        }
        else if (ip.AddressFamily == AddressFamily.InterNetworkV6)
        {
            // IPv6 link-local
            if (ip.IsIPv6LinkLocal)
            {
                return true;
            }
        }

        return false;
    }

    /// <summary>
    /// The standard RFC 1918 / RFC 4193 private ranges.
    /// </summary>
    private static bool IsPrivateNetwork(IPAddress ip)
    {
        if (ip.AddressFamily == AddressFamily.InterNetwork)
        {
            var b = ip.GetAddressBytes();

            // 10.0.0.0/8
            if (b[0] == 10)
            {
                return true;
            }

            // 172.16.0.0/12
            if (b[0] == 172 && b[1] >= 16 && b[1] <= 31)
            {
                return true;
            }

            // 192.168.0.0/16
            if (b[0] == 192 && b[1] == 168)
            {
                return true;
            }
        }
        else if (ip.AddressFamily == AddressFamily.InterNetworkV6)
        {
            // IPv6 site-local
            if (ip.IsIPv6SiteLocal)
            {
                return true;
            }

            // IPv6 unique local addresses fc00::/7
            var b = ip.GetAddressBytes();

            if ((b[0] & 0xFE) == 0xFC)
            {
                return true;
            }
        }

        return false;
    }
}
