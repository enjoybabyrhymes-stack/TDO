using System.Security.Cryptography;

namespace Tdm.Orchestrator.Application.Utilities;

/// <summary>Password hashing with PBKDF2-SHA256 and a random salt per password. Format: v1.iterations.salt.hash</summary>
public static class PasswordHashing
{
    private const int Iterations = 600_000;
    private const int SaltSize = 16;
    private const int HashSize = 32;

    /// <summary>
    /// Verified against when a username does not exist, so a wrong user name and a wrong password take the same time
    /// and the response does not reveal which user names exist.
    /// </summary>
    public static readonly string DummyHash = Hash("not-a-real-password");

    public static string Hash(string password)
    {
        var salt = RandomNumberGenerator.GetBytes(SaltSize);
        var hash = Rfc2898DeriveBytes.Pbkdf2(password, salt, Iterations, HashAlgorithmName.SHA256, HashSize);
        return $"v1.{Iterations}.{Convert.ToBase64String(salt)}.{Convert.ToBase64String(hash)}";
    }

    public static bool Verify(string password, string stored)
    {
        var parts = stored.Split('.');
        if (parts.Length != 4 || parts[0] != "v1" || !int.TryParse(parts[1], out var iterations) ||
            iterations < 1 || iterations > 5_000_000)
        {
            return false;
        }

        byte[] salt;
        byte[] expected;
        try
        {
            salt = Convert.FromBase64String(parts[2]);
            expected = Convert.FromBase64String(parts[3]);
        }
        catch (FormatException)
        {
            return false;
        }

        var actual = Rfc2898DeriveBytes.Pbkdf2(password, salt, iterations, HashAlgorithmName.SHA256, expected.Length);
        return CryptographicOperations.FixedTimeEquals(actual, expected);
    }
}
