using System.Text;
using System.Text.Json.Nodes;
using Microsoft.Extensions.Options;
using Tdm.Orchestrator.Application.Interfaces;
using Tdm.Orchestrator.Application.Utilities;
using Tdm.Orchestrator.Options;

namespace Tdm.Orchestrator.Infrastructure.Http;

/// <summary>
/// HTTP client for external API calls with timeout, SSRF, and error handling.
/// </summary>
public class HttpApiClient : IHttpApiClient
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<HttpApiClient> _logger;
    private readonly SecurityOptions _securityOptions;
    private readonly IHostEnvironment _environment;

    public HttpApiClient(
        HttpClient httpClient,
        ILogger<HttpApiClient> logger,
        IOptions<SecurityOptions> securityOptions,
        IHostEnvironment environment)
    {
        _httpClient = httpClient;
        _logger = logger;
        _securityOptions = securityOptions.Value;
        _environment = environment;
    }

    public async Task<HttpResponseDto> CallApiAsync(
        string url,
        string httpMethod,
        JsonNode? body,
        IReadOnlyDictionary<string, string>? headers,
        int timeoutSeconds,
        CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(url))
        {
            throw new ArgumentException("URL cannot be empty", nameof(url));
        }

        var dto = new HttpResponseDto { RequestUrl = url };

        // Validate URL format
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri))
        {
            _logger.LogError("Invalid URL format: {Url}", url);
            dto.StatusCode = 400;
            dto.Response = JsonValue.Create("Invalid URL format");
            return dto;
        }

        // Validate URL scheme (http/https only)
        if (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps)
        {
            _logger.LogError("Invalid URL scheme: {Scheme}", uri.Scheme);
            dto.StatusCode = 400;
            dto.Response = JsonValue.Create("Only HTTP and HTTPS are allowed");
            return dto;
        }

        // SSRF protection:
        //
        // In Development we allow loopback addresses so that local tools
        // such as Mockoon can be used. In Production loopback remains blocked.
        var allowLoopback = _environment.IsDevelopment();

        var (isSafe, reason) = await NetworkSafetyValidator.IsSafeTargetAsync(
            uri, _securityOptions.BlockAllPrivateNetworks, allowLoopback);

        if (!isSafe)
        {
            _logger.LogError("Blocked potentially unsafe target {Url}: {Reason}", url, reason);
            dto.StatusCode = 400;
            dto.Response = JsonValue.Create($"Request blocked by security policy: {reason}");
            return dto;
        }

        // NOTE: the HttpClient injected here has Timeout set to Timeout.InfiniteTimeSpan
        // (see Program.cs) specifically so that this per-call timeout — driven by each
        // step's configured TimeoutSeconds — is the only thing that can time out a
        // request. A finite HttpClient.Timeout would silently override this with a
        // fixed ceiling regardless of what the step asked for.
        var effectiveTimeout = timeoutSeconds > 0 ? timeoutSeconds : 30;
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(effectiveTimeout));
        using var linkedCts = CancellationTokenSource.CreateLinkedTokenSource(cts.Token, cancellationToken);

        try
        {
            using var request = new HttpRequestMessage(new HttpMethod(httpMethod.ToUpperInvariant()), url);

            if (headers != null)
            {
                foreach (var (key, value) in headers)
                {
                    if (!string.IsNullOrWhiteSpace(key) && !string.IsNullOrWhiteSpace(value))
                    {
                        request.Headers.TryAddWithoutValidation(key, value);
                    }
                }
            }

            if (body != null && !httpMethod.Equals("GET", StringComparison.OrdinalIgnoreCase))
            {
                request.Content = new StringContent(body.ToJsonString(), Encoding.UTF8, "application/json");
            }

            _logger.LogInformation("Calling {Method} {Url}", httpMethod, url);

            using var response = await _httpClient.SendAsync(request, linkedCts.Token);
            var content = await response.Content.ReadAsStringAsync(linkedCts.Token);

            dto.StatusCode = (int)response.StatusCode;
            dto.Response = string.IsNullOrWhiteSpace(content) ? null : JsonNode.Parse(content);

            if ((int)response.StatusCode >= 400)
            {
                _logger.LogWarning("API returned status {StatusCode} for {Url}", response.StatusCode, url);
            }
        }
        catch (OperationCanceledException)
        {
            _logger.LogError("Request to {Url} timed out after {Timeout}s", url, effectiveTimeout);
            dto.StatusCode = 504;
            dto.Response = JsonValue.Create("Request timeout");
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "HTTP error calling {Url}", url);
            dto.StatusCode = 502;
            dto.Response = JsonValue.Create($"HTTP error: {ex.Message}");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error calling {Url}", url);
            dto.StatusCode = 500;
            dto.Response = JsonValue.Create($"Error: {ex.Message}");
        }

        return dto;
    }
}
