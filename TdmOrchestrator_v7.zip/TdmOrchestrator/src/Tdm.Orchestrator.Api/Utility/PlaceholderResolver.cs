using System.Text.Json.Nodes;
using System.Text.RegularExpressions;

namespace Tdm.Orchestrator.Application.Utilities;

/// <summary>
/// Resolves endpoint and JSON-template placeholders used by the orchestration engine.
///
/// Supported features:
///   - endpoint tokens: {step1.id}, {step2[0].id}
///   - dollar tokens: $input.state, $step1.applicationId, $step2[0].id, $now
///   - whole-value substitution that preserves JSON types
///   - embedded string substitution: "Bearer $InsuranceApi.ApiKey"
///   - array length: $step2.length
///   - conditional objects using $when / $then
///
/// Conditional syntax:
/// {
///   "$when": { "field": "step1.insured.state", "equals": "Florida" },
///   "$then": { "code": "FL.HurricaneCoverageQuestion", "answer": "NO" }
/// }
///
/// Supported $when operators: equals, notEquals, greaterThan, greaterThanOrEqual,
/// lessThan, lessThanOrEqual, contains.
///
/// If the condition is true, the conditional object is replaced by the resolved
/// $then value. If false, it is omitted from its containing object/array.
/// </summary>
public static class PlaceholderResolver
{
    private static readonly Regex EndpointTokenPattern =
        new(@"\{([^{}]+)\}", RegexOptions.Compiled);

    private static readonly Regex ArrayIndexPattern =
        new(@"^(.+)\[(\d+)\]$", RegexOptions.Compiled);

    // Matches $identifier(.identifier | [n])* — e.g. $step1.id, $step2[0].title,
    // $InsuranceApi.ApiKey, $input.state, $now.
    private static readonly Regex DollarTokenPattern = new(
        @"\$([A-Za-z_][A-Za-z0-9_]*(?:(?:\.[A-Za-z_][A-Za-z0-9_]*)|(?:\[\d+\]))*)",
        RegexOptions.Compiled);

    /// <summary>Resolves {step1.id} style tokens inside an endpoint URL template.</summary>
    public static string ResolveEndpoint(
        string endpointTemplate,
        IReadOnlyDictionary<string, JsonNode?> stepsResponseMap,
        IReadOnlyDictionary<string, string>? configValues = null)
    {
        if (string.IsNullOrWhiteSpace(endpointTemplate))
        {
            return endpointTemplate;
        }

        return EndpointTokenPattern.Replace(endpointTemplate, match =>
        {
            var path = match.Groups[1].Value;
            var resolved = ResolveValueFromMap(stepsResponseMap, path, configValues);
            var text = resolved?.ToString() ?? string.Empty;

            // URL-encode only the resolved value. Literal URL text is left unchanged.
            return Uri.EscapeDataString(text);
        });
    }

    /// <summary>
    /// Resolves a JSON template string (request body/headers OR a CONSOLIDATE step's
    /// output template) against the steps executed so far.
    /// </summary>
    public static JsonNode? ResolveTemplate(
        string? templateJson,
        IReadOnlyDictionary<string, JsonNode?> stepsResponseMap,
        IReadOnlyDictionary<string, string>? configValues = null)
    {
        if (string.IsNullOrWhiteSpace(templateJson))
        {
            return null;
        }

        var node = JsonNode.Parse(templateJson);
        return ResolveNode(node, stepsResponseMap, configValues, out _);
    }

    /// <summary>
    /// Recursively resolves placeholders and conditional objects.
    /// The omit flag is used so a false conditional can be removed from an
    /// object property or array rather than being serialized as null.
    /// </summary>
    private static JsonNode? ResolveNode(
        JsonNode? node,
        IReadOnlyDictionary<string, JsonNode?> map,
        IReadOnlyDictionary<string, string>? configValues,
        out bool omit)
    {
        omit = false;

        if (node is null)
        {
            return null;
        }

        // A JSON object containing $when is a conditional wrapper.
        if (node is JsonObject conditionalObject &&
            conditionalObject.ContainsKey("$when"))
        {
            return ResolveConditional(
                conditionalObject,
                map,
                configValues,
                out omit);
        }

        switch (node)
        {
            case JsonObject obj:
            {
                var resultObj = new JsonObject();

                foreach (var kv in obj)
                {
                    var resolved = ResolveNode(
                        kv.Value,
                        map,
                        configValues,
                        out var childOmit);

                    // A false conditional child is omitted entirely.
                    if (childOmit)
                    {
                        continue;
                    }

                    resultObj[kv.Key] = resolved;
                }

                return resultObj;
            }

            case JsonArray arr:
            {
                var resultArr = new JsonArray();

                foreach (var item in arr)
                {
                    var resolved = ResolveNode(
                        item,
                        map,
                        configValues,
                        out var childOmit);

                    // A false conditional array element is removed entirely.
                    if (childOmit)
                    {
                        continue;
                    }

                    resultArr.Add(resolved);
                }

                return resultArr;
            }

            case JsonValue val when
                val.TryGetValue<string>(out var text) &&
                text.Contains('$'):
                return ResolveStringValue(text, map, configValues);

            default:
                return node.DeepClone();
        }
    }

    /// <summary>
    /// Evaluates a {$when: ..., $then: ...} object.
    ///
    /// Supported conditions:
    ///   { "field": "...", "equals": "..." }
    ///   { "field": "...", "notEquals": "..." }
    ///   { "field": "...", "greaterThan": ... }
    ///   { "field": "...", "greaterThanOrEqual": ... }
    ///   { "field": "...", "lessThan": ... }
    ///   { "field": "...", "lessThanOrEqual": ... }
    ///   { "field": "...", "contains": ... }
    ///
    /// greaterThan/lessThan (and their "OrEqual" variants) compare numerically when
    /// both sides can be read as numbers, otherwise fall back to an ordinal string
    /// comparison. contains checks substring membership when the field is a string,
    /// or element membership (via the same equality rules as "equals") when the
    /// field is an array.
    ///
    /// If the condition is true, $then is recursively resolved and returned.
    /// If false, omit=true so the parent removes this object/property/array item.
    /// </summary>
    private static JsonNode? ResolveConditional(
        JsonObject conditionalObject,
        IReadOnlyDictionary<string, JsonNode?> map,
        IReadOnlyDictionary<string, string>? configValues,
        out bool omit)
    {
        omit = false;

        if (conditionalObject["$when"] is not JsonObject whenObject)
        {
            throw new InvalidOperationException(
                "Invalid conditional template: '$when' must be a JSON object.");
        }

        if (!whenObject.TryGetPropertyValue("field", out var fieldNode) ||
            string.IsNullOrWhiteSpace(fieldNode?.ToString()))
        {
            throw new InvalidOperationException(
                "Invalid conditional template: '$when.field' is required.");
        }

        var fieldPath = fieldNode!.ToString();
        var actualValue = ResolveValueFromMap(
            map,
            fieldPath,
            configValues);

        var conditionMatched = EvaluateOperators(whenObject, actualValue);

        if (!conditionMatched)
        {
            omit = true;
            return null;
        }

        if (!conditionalObject.TryGetPropertyValue("$then", out var thenNode))
        {
            throw new InvalidOperationException(
                "Invalid conditional template: '$then' is required when '$when' matches.");
        }

        // Resolve $input/$step/$now tokens inside the $then value too.
        return ResolveNode(
            thenNode,
            map,
            configValues,
            out omit);
    }

    /// <summary>
    /// Dispatches a $when condition object to the correct comparison based on
    /// which operator key it contains: equals, notEquals, greaterThan,
    /// greaterThanOrEqual, lessThan, lessThanOrEqual, or contains.
    /// </summary>
    private static bool EvaluateOperators(JsonObject whenObject, object? actualValue)
    {
        if (whenObject.TryGetPropertyValue("equals", out var equalsNode))
        {
            return ValuesEqual(actualValue, equalsNode);
        }

        if (whenObject.TryGetPropertyValue("notEquals", out var notEqualsNode))
        {
            return !ValuesEqual(actualValue, notEqualsNode);
        }

        if (whenObject.TryGetPropertyValue("greaterThan", out var greaterThanNode))
        {
            return TryCompareValues(actualValue, greaterThanNode, out var cmp) && cmp > 0;
        }

        if (whenObject.TryGetPropertyValue("greaterThanOrEqual", out var greaterThanOrEqualNode))
        {
            return TryCompareValues(actualValue, greaterThanOrEqualNode, out var cmp) && cmp >= 0;
        }

        if (whenObject.TryGetPropertyValue("lessThan", out var lessThanNode))
        {
            return TryCompareValues(actualValue, lessThanNode, out var cmp) && cmp < 0;
        }

        if (whenObject.TryGetPropertyValue("lessThanOrEqual", out var lessThanOrEqualNode))
        {
            return TryCompareValues(actualValue, lessThanOrEqualNode, out var cmp) && cmp <= 0;
        }

        if (whenObject.TryGetPropertyValue("contains", out var containsNode))
        {
            return ValueContains(actualValue, containsNode);
        }

        throw new InvalidOperationException(
            "Invalid conditional template: '$when' must contain one of: equals, " +
            "notEquals, greaterThan, greaterThanOrEqual, lessThan, lessThanOrEqual, contains.");
    }

    /// <summary>
    /// Evaluates a standalone condition object of the same shape used by $when
    /// (e.g. { "field": "step2.status", "equals": "approved" }) against the given
    /// steps response map. For callers outside template resolution — e.g. a
    /// polling step deciding whether to keep waiting — that need the exact same
    /// field-lookup and comparison rules $when already uses.
    /// </summary>
    public static bool EvaluateCondition(
        JsonObject conditionObject,
        IReadOnlyDictionary<string, JsonNode?> map,
        IReadOnlyDictionary<string, string>? configValues = null)
    {
        if (!conditionObject.TryGetPropertyValue("field", out var fieldNode) ||
            string.IsNullOrWhiteSpace(fieldNode?.ToString()))
        {
            throw new InvalidOperationException("Invalid condition: 'field' is required.");
        }

        var fieldPath = fieldNode!.ToString();
        var actualValue = ResolveValueFromMap(map, fieldPath, configValues);

        return EvaluateOperators(conditionObject, actualValue);
    }

    /// <summary>
    /// Compares a resolved value with the expected JSON value from a $when condition.
    /// String comparison is case-insensitive so values such as true/TRUE and
    /// Florida/florida behave consistently. JSON booleans/numbers are also compared
    /// by their actual value where possible.
    /// </summary>
    private static bool ValuesEqual(object? actualValue, JsonNode? expectedNode)
    {
        if (actualValue is null || expectedNode is null)
        {
            return actualValue is null && expectedNode is null;
        }

        if (actualValue is JsonNode actualNode)
        {
            actualValue = UnwrapJsonNode(actualNode);
        }

        if (expectedNode is JsonValue expectedValue)
        {
            if (expectedValue.TryGetValue<bool>(out var expectedBool) &&
                TryConvertToBool(actualValue, out var actualBool))
            {
                return actualBool == expectedBool;
            }

            if (expectedValue.TryGetValue<long>(out var expectedLong) &&
                TryConvertToDecimal(actualValue, out var actualNumber))
            {
                return actualNumber == expectedLong;
            }

            if (expectedValue.TryGetValue<double>(out var expectedDouble) &&
                TryConvertToDecimal(actualValue, out var actualDouble))
            {
                return actualDouble == (decimal)expectedDouble;
            }

            if (expectedValue.TryGetValue<string>(out var expectedString))
            {
                return string.Equals(
                    actualValue?.ToString(),
                    expectedString,
                    StringComparison.OrdinalIgnoreCase);
            }
        }

        return string.Equals(
            actualValue?.ToString(),
            expectedNode.ToString(),
            StringComparison.OrdinalIgnoreCase);
    }

    private static bool TryConvertToBool(object? value, out bool result)
    {
        if (value is bool boolValue)
        {
            result = boolValue;
            return true;
        }

        return bool.TryParse(value?.ToString(), out result);
    }

    private static bool TryConvertToDecimal(object? value, out decimal result)
    {
        switch (value)
        {
            case int i:
                result = i;
                return true;
            case long l:
                result = l;
                return true;
            case double d:
                result = (decimal)d;
                return true;
            case decimal m:
                result = m;
                return true;
            default:
                return decimal.TryParse(
                    value?.ToString(),
                    out result);
        }
    }

    /// <summary>
    /// Compares a resolved value against the expected JSON value from a $when
    /// condition, for use by greaterThan/lessThan (and their "OrEqual" variants).
    /// Prefers a numeric comparison when both sides can be read as numbers;
    /// otherwise falls back to an ordinal (case-insensitive) string comparison,
    /// which also makes ISO-8601 style date/time strings compare correctly.
    /// Returns false when neither comparison is possible (e.g. one side is null).
    /// </summary>
    private static bool TryCompareValues(
        object? actualValue,
        JsonNode? expectedNode,
        out int comparison)
    {
        comparison = 0;

        if (actualValue is JsonNode actualNode)
        {
            actualValue = UnwrapJsonNode(actualNode);
        }

        if (actualValue is null || expectedNode is not JsonValue expectedValue)
        {
            return false;
        }

        if (TryConvertToDecimal(actualValue, out var actualNumber) &&
            TryGetDecimalFromExpected(expectedValue, out var expectedNumber))
        {
            comparison = actualNumber.CompareTo(expectedNumber);
            return true;
        }

        if (expectedValue.TryGetValue<string>(out var expectedString))
        {
            comparison = string.Compare(
                actualValue.ToString(),
                expectedString,
                StringComparison.OrdinalIgnoreCase);
            return true;
        }

        return false;
    }

    /// <summary>
    /// Reads a $when comparison value (e.g. "greaterThan": 5) as a decimal,
    /// including numeric strings such as "greaterThan": "5".
    /// </summary>
    private static bool TryGetDecimalFromExpected(JsonValue expectedValue, out decimal result)
    {
        if (expectedValue.TryGetValue<long>(out var longValue))
        {
            result = longValue;
            return true;
        }

        if (expectedValue.TryGetValue<double>(out var doubleValue))
        {
            result = (decimal)doubleValue;
            return true;
        }

        if (expectedValue.TryGetValue<string>(out var stringValue) &&
            decimal.TryParse(stringValue, out result))
        {
            return true;
        }

        result = 0;
        return false;
    }

    /// <summary>
    /// Evaluates the "contains" operator. When the resolved field is a JSON array,
    /// checks whether any element equals the expected value (using the same rules
    /// as "equals"). Otherwise treats the field as a string and checks for a
    /// case-insensitive substring match.
    /// </summary>
    private static bool ValueContains(object? actualValue, JsonNode? expectedNode)
    {
        if (actualValue is JsonNode actualNode)
        {
            actualValue = UnwrapJsonNode(actualNode);
        }

        if (actualValue is null || expectedNode is null)
        {
            return false;
        }

        if (actualValue is JsonArray array)
        {
            foreach (var item in array)
            {
                if (ValuesEqual(item, expectedNode))
                {
                    return true;
                }
            }

            return false;
        }

        var expectedText = expectedNode is JsonValue expectedValue &&
                            expectedValue.TryGetValue<string>(out var expectedString)
            ? expectedString
            : expectedNode.ToString();

        return actualValue.ToString()?.Contains(
            expectedText,
            StringComparison.OrdinalIgnoreCase) ?? false;
    }

    /// <summary>
    /// If the ENTIRE string is exactly one "$token", the resolved value's real type
    /// (number, bool, nested object/array) is preserved. Otherwise every "$token"
    /// found inside the string is substituted in place.
    /// </summary>
    private static JsonNode? ResolveStringValue(
        string text,
        IReadOnlyDictionary<string, JsonNode?> map,
        IReadOnlyDictionary<string, string>? configValues)
    {
        var fullMatch = DollarTokenPattern.Match(text);

        if (fullMatch.Success &&
            fullMatch.Index == 0 &&
            fullMatch.Length == text.Length)
        {
            var resolved = ResolveValueFromMap(
                map,
                fullMatch.Groups[1].Value,
                configValues);

            return ToJsonNode(resolved);
        }

        var replaced = DollarTokenPattern.Replace(text, m =>
        {
            var resolved = ResolveValueFromMap(
                map,
                m.Groups[1].Value,
                configValues);

            return resolved?.ToString() ?? string.Empty;
        });

        return JsonValue.Create(replaced);
    }

    private static JsonNode? ToJsonNode(object? value)
    {
        return value switch
        {
            null => null,
            JsonNode jn => jn.DeepClone(),
            string s => JsonValue.Create(s),
            int i => JsonValue.Create(i),
            long l => JsonValue.Create(l),
            double d => JsonValue.Create(d),
            decimal m => JsonValue.Create(m),
            bool b => JsonValue.Create(b),
            _ => JsonValue.Create(value?.ToString())
        };
    }

    /// <summary>
    /// Resolves a dotted/bracket path (e.g. "step2[0].title", "step2.length",
    /// "now", or a plain ApiConfig key) against the steps response map, falling
    /// back to configValues when the first segment isn't a known step key.
    /// </summary>
    public static object? ResolveValueFromMap(
        IReadOnlyDictionary<string, JsonNode?> map,
        string path,
        IReadOnlyDictionary<string, string>? configValues = null)
    {
        if (string.IsNullOrWhiteSpace(path))
        {
            return null;
        }

        if (path == "now")
        {
            return DateTime.UtcNow.ToString("o");
        }

        var parts = path.Split('.');
        var firstArrayMatch = ArrayIndexPattern.Match(parts[0]);
        var firstKey = firstArrayMatch.Success
            ? firstArrayMatch.Groups[1].Value
            : parts[0];

        // Not a known step key at all -> try ApiConfig fallback.
        if (!map.ContainsKey(firstKey))
        {
            if (configValues != null &&
                configValues.TryGetValue(path, out var configVal))
            {
                return configVal;
            }

            return null;
        }

        JsonNode? current = ResolveFirstSegment(
            map,
            parts[0]);

        for (var i = 1;
             i < parts.Length && current != null;
             i++)
        {
            var part = parts[i];

            if (part == "length")
            {
                return current is JsonArray arr
                    ? arr.Count
                    : (object?)null;
            }

            var arrayMatch = ArrayIndexPattern.Match(part);

            if (arrayMatch.Success)
            {
                var name = arrayMatch.Groups[1].Value;
                var index = int.Parse(arrayMatch.Groups[2].Value);

                current = current is JsonObject obj &&
                          obj[name] is JsonArray childArr &&
                          index < childArr.Count
                    ? childArr[index]
                    : null;
            }
            else
            {
                current = current is JsonObject obj2 &&
                          obj2.ContainsKey(part)
                    ? obj2[part]
                    : null;
            }
        }

        return UnwrapJsonNode(current);
    }

    private static JsonNode? ResolveFirstSegment(
        IReadOnlyDictionary<string, JsonNode?> map,
        string firstPart)
    {
        var arrayMatch = ArrayIndexPattern.Match(firstPart);

        if (arrayMatch.Success)
        {
            var key = arrayMatch.Groups[1].Value;
            var index = int.Parse(arrayMatch.Groups[2].Value);

            return map.TryGetValue(key, out var node) &&
                   node is JsonArray arr &&
                   index < arr.Count
                ? arr[index]
                : null;
        }

        return map.TryGetValue(firstPart, out var direct)
            ? direct
            : null;
    }

    private static object? UnwrapJsonNode(JsonNode? node)
    {
        switch (node)
        {
            case null:
                return null;

            case JsonArray arr:
                return arr;

            case JsonValue val:
                if (val.TryGetValue<string>(out var s)) return s;
                if (val.TryGetValue<long>(out var l)) return l;
                if (val.TryGetValue<double>(out var d)) return d;
                if (val.TryGetValue<bool>(out var b)) return b;
                return val.ToString();

            default:
                return node;
        }
    }
}