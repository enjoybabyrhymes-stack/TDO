namespace Tdm.Orchestrator.Domain.Constants;

/// <summary>Orchestration engine constants and defaults.</summary>
public static class OrchestrationConstants
{
    public const string StepType_RestApi = "RESTAPI";
    public const string StepType_Consolidate = "CONSOLIDATE";

    public const string HttpMethod_Get = "GET";
    public const string HttpMethod_Post = "POST";
    public const string HttpMethod_Put = "PUT";
    public const string HttpMethod_Patch = "PATCH";
    public const string HttpMethod_Delete = "DELETE";

    public const string ActiveFlag_Active = "A";
    public const string ActiveFlag_Inactive = "I";

    public const int DefaultTimeoutSeconds = 30;
    public const int DefaultRetryCount = 0;
}
