namespace Tdm.Orchestrator.Domain.Constants;

public static class AuthConstants
{
    public const string Role_Admin = "ADMIN";
    public const string Role_User = "USER";
}
