using System.Threading.RateLimiting;
using Azure.Core;
using Azure.Identity;
using Microsoft.AspNetCore.RateLimiting;
using Tdm.Orchestrator.Domain.Entities;
using Tdm.Orchestrator.Domain.Exceptions;
using Tdm.Orchestrator.Application.Services;
using Tdm.Orchestrator.Application.Interfaces;
using Tdm.Orchestrator.Infrastructure.Http;
using Tdm.Orchestrator.Infrastructure.HealthChecks;
using Tdm.Orchestrator.Infrastructure.Persistence;
using Tdm.Orchestrator.Infrastructure.Middleware;
using Tdm.Orchestrator.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.FileProviders;

var builder = WebApplication.CreateBuilder(args);

// ---------------------------------------------------------------------------
// Azure Key Vault (optional). When KeyVault:Uri is set, secrets are loaded into
// configuration at startup, so the database connection string and API keys never
// need to appear in files or app settings.
//
// Secret names use "--" in place of ":" (Key Vault names cannot contain a colon):
//   ConnectionStrings--OrchestratorDb   -> ConnectionStrings:OrchestratorDb
//   ApiKey--ValidKeys--0                -> ApiKey:ValidKeys:0
//
// Vault values override appsettings and environment variables. Rotating a secret
// takes effect after the application restarts.
// ---------------------------------------------------------------------------
var keyVaultOptions = builder.Configuration
    .GetSection(KeyVaultOptions.SectionName)
    .Get<KeyVaultOptions>() ?? new KeyVaultOptions();

if (!string.IsNullOrWhiteSpace(keyVaultOptions.Uri))
{
    if (!Uri.TryCreate(keyVaultOptions.Uri, UriKind.Absolute, out var vaultUri) ||
        vaultUri.Scheme != Uri.UriSchemeHttps)
    {
        throw new InvalidOperationException(
            "KeyVault:Uri must be an absolute https address, e.g. https://<vault-name>.vault.azure.net/ .");
    }

    // In deployed environments only the managed identity is used, which is predictable and
    // avoids probing other credential sources. Locally, DefaultAzureCredential lets developers
    // authenticate with 'az login' or Visual Studio.
    TokenCredential credential = builder.Environment.IsDevelopment()
        ? new DefaultAzureCredential()
        : string.IsNullOrWhiteSpace(keyVaultOptions.ManagedIdentityClientId)
            ? new ManagedIdentityCredential(ManagedIdentityId.SystemAssigned)
            : new ManagedIdentityCredential(
                ManagedIdentityId.FromUserAssignedClientId(keyVaultOptions.ManagedIdentityClientId));

    try
    {
        builder.Configuration.AddAzureKeyVault(vaultUri, credential);
    }
    catch (Exception ex)
    {
        throw new InvalidOperationException(
            $"Could not load secrets from Key Vault '{vaultUri.Host}'. Check that the application's " +
            "identity has the 'Key Vault Secrets User' role and that the vault network rules allow the app.", ex);
    }
}

// ---------------------------------------------------------------------------
// Configuration binding — these are the ONLY things that should change between
// environments (dev/QA/prod/client). Everything below reads from configuration,
// nothing is hardcoded. See PRODUCTION_HARDENING.md "Per-Environment Checklist"
// for the exact list of environment variables to set per environment.
// ---------------------------------------------------------------------------
builder.Services.Configure<ApiKeyOptions>(builder.Configuration.GetSection("ApiKey"));
builder.Services.Configure<SecurityOptions>(builder.Configuration.GetSection("Security"));
builder.Services.Configure<AdminOptions>(builder.Configuration.GetSection(AdminOptions.SectionName));

// EF Core database configuration
var sqlConnectionString = builder.Configuration.GetConnectionString("OrchestratorDb");
builder.Services.AddDbContext<OrchestratorDbContext>(options =>
{
    options.UseSqlServer(sqlConnectionString);
});

// HTTP client with configuration.
// Timeout is intentionally infinite here: HttpApiClient enforces the actual
// per-call timeout itself, using a CancellationTokenSource built from each
// step's own TimeoutSeconds (see Utility/RestApiUtility.cs). Setting a finite
// value on the shared HttpClient would silently cap every step at that fixed
// ceiling — e.g. a step configured with TimeoutSeconds = 120 would still be
// cut off at 60s — regardless of what the step's own configuration says.
builder.Services.AddHttpClient<IHttpApiClient, HttpApiClient>(client =>
{
    client.Timeout = Timeout.InfiniteTimeSpan;
});

// Application services
builder.Services.AddScoped<IOrchestratorService, TestDataOrchestrationService>();
builder.Services.AddScoped<IConfigurationService, ConfigurationService>();
builder.Services.AddScoped<IOrchestrationValidator, OrchestrationValidator>();
builder.Services.AddScoped<IScenarioAdminService, ScenarioAdminService>();
builder.Services.AddScoped<AdminKeyFilter>();

// Who is calling the admin API (filled in by AdminKeyFilter), sessions, and group/user management.
builder.Services.AddScoped<CurrentUser>();
builder.Services.AddScoped<ICurrentUser>(sp => sp.GetRequiredService<CurrentUser>());
builder.Services.AddScoped<ISessionService, SessionService>();
builder.Services.AddScoped<IAccessAdminService, AccessAdminService>();

// Controllers and API documentation
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Health checks — now actually checks the database, not just "is the process alive"
builder.Services.AddHealthChecks()
    .AddCheck<DatabaseHealthCheck>("database");

// Rate limiting — partitioned per API key (falls back to IP address if no key was
// sent, e.g. an unauthenticated request that's about to get rejected anyway).
// 100 requests/minute is a starting placeholder — tune based on real client usage;
// see PRODUCTION_HARDENING.md.
builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;

    // Sign-in attempts: 10 per minute per client address. Slows down password guessing.
    options.AddPolicy("login", httpContext =>
        RateLimitPartition.GetFixedWindowLimiter(
            httpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown",
            _ => new FixedWindowRateLimiterOptions
            {
                PermitLimit = 10,
                Window = TimeSpan.FromMinutes(1),
                QueueLimit = 0
            }));

    options.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(context =>
    {
        // The admin web page is static and holds no data; a redirect or asset request must never be throttled.
        if (context.Request.Path.StartsWithSegments("/admin-ui", StringComparison.OrdinalIgnoreCase))
            return RateLimitPartition.GetNoLimiter("admin-ui");

        var partitionKey = context.Request.Headers.TryGetValue("X-Api-Key", out var key)
            ? key.ToString()
            : context.Connection.RemoteIpAddress?.ToString() ?? "unknown";

        return RateLimitPartition.GetFixedWindowLimiter(partitionKey, _ => new FixedWindowRateLimiterOptions
        {
            PermitLimit = 100,
            Window = TimeSpan.FromMinutes(1),
            QueueLimit = 0
        });
    });
});

var app = builder.Build();

// Database schema creation on startup (EnsureCreated — see PRODUCTION_HARDENING.md
// for the tradeoffs of this vs. EF migrations before this touches a real, persistent
// database with existing data).
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<OrchestratorDbContext>();
    db.Database.EnsureCreated();

    // EnsureCreated never alters tables that already exist, so databases made by an earlier release need the new
    // columns and tables (polling settings, groups, users). Automatic in Development; elsewhere set
    // Database:AutoUpgrade=true, or run database/003_AddPollingColumns.sql and 004_AddGroupsAndUsers.sql once.
    var autoUpgrade = builder.Configuration.GetValue<bool?>("Database:AutoUpgrade") ?? app.Environment.IsDevelopment();
    if (autoUpgrade)
    {
        try
        {
            SchemaUpgrade.Apply(db);
        }
        catch (Exception ex)
        {
            app.Logger.LogWarning(ex,
                "Could not upgrade the database automatically. Run database/003_AddPollingColumns.sql and database/004_AddGroupsAndUsers.sql.");
        }
    }
}

// ---------------------------------------------------------------------------
// Middleware pipeline — order matters here:
//   1. Exception handling wraps EVERYTHING below, so a failure anywhere
//      (including in rate limiting or auth) still returns a clean error.
//   2. HTTPS redirection.
//   3. Rate limiting — runs before auth, so repeated bad-key attempts get
//      throttled too, not just successfully authenticated traffic.
//   4. API key auth — the actual gate. Health check paths are exempted inside
//      the middleware itself so probes don't need a key.
// ---------------------------------------------------------------------------
app.UseMiddleware<ExceptionHandlingMiddleware>();

if (!app.Environment.IsDevelopment())
{
    // Adds Strict-Transport-Security so browsers/clients remember to use HTTPS
    // for this host. No effect on server-to-server API callers that already
    // use HTTPS, and skipped in Development since local HTTPS certs are
    // typically self-signed.
    app.UseHsts();
}

app.UseHttpsRedirection();

// Admin web UI (static files in wwwroot/admin-ui, served at /admin-ui/). The page itself holds no data;
// every call it makes goes to the admin API, which is protected by the admin key.
// Served before the rate limiter so page assets do not use up the per-client request budget.
// "/admin-ui" (no trailing slash) is redirected to "/admin-ui/" here, by exact match. This must NOT be an
// endpoint (MapGet): endpoint routing also matches "/admin-ui/", which caused an endless redirect loop.
app.Use(async (context, next) =>
{
    if (string.Equals(context.Request.Path.Value, "/admin-ui", StringComparison.OrdinalIgnoreCase))
    {
        context.Response.Redirect("/admin-ui/");
        return;
    }
    await next();
});

// Serve from an explicit wwwroot folder (next to the project) so the UI is found regardless of how the app is started.
var webRoot = Path.Combine(app.Environment.ContentRootPath, "wwwroot");
if (Directory.Exists(webRoot))
{
    var files = new PhysicalFileProvider(webRoot);
    app.UseDefaultFiles(new DefaultFilesOptions { FileProvider = files });
    app.UseStaticFiles(new StaticFileOptions { FileProvider = files });
}
else
{
    app.UseDefaultFiles();
    app.UseStaticFiles();
}

app.UseRateLimiter();
app.UseMiddleware<ApiKeyAuthMiddleware>();

// Health check endpoints
app.MapHealthChecks("/health/live");
app.MapHealthChecks("/health/ready");

// Swagger — Development only
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.MapControllers();

app.Run();
