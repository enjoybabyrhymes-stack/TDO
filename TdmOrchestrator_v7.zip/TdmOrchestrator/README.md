# TDM Orchestrator API

Data orchestration service that composes and executes multi-step REST API scenarios. Scenarios are
defined as rows in an Azure SQL database, so workflows change without code changes or redeployment.

## Features

- **Database-driven scenarios** — projects, environments, scenarios and steps live in `OrchestrationSteps`.
- **Step chaining** — pass fields from one step's response into later steps (`$step1.id`, `{input.id}`).
- **Consolidation** — aggregate selected fields from several steps into a single response.
- **Retries and polling** — per-step retry on 5xx, or poll an endpoint until a condition is met.
- **Security** — API-key authentication (fail-closed), rate limiting, HSTS/HTTPS, SSRF protection on outbound calls.
- **Audit trail** — every executed step is recorded in `OrchestrationRuns`.
- **Operations** — health probes, structured logging.

## Architecture

```
Client ─► Security pipeline ─► OrchestratorController ─► TestDataOrchestrationService ─► Azure SQL
          (rate limit,          (validates project /       │  (steps, config, run log)
           API key, HTTPS)       environment / scenario)   └► HttpApiClient (+ SSRF guard) ─► target APIs
```

| Layer | Contents |
|---|---|
| `Controllers/` | `OrchestratorController` — HTTP surface |
| `Services/` | Orchestration engine, validator, configuration service and their interfaces |
| `Utility/` | `PlaceholderResolver`, `HttpApiClient`, `NetworkSafetyValidator` |
| `Middleware/` | Exception handling, API-key authentication |
| `Data/`, `Entities/` | EF Core context and table models |
| `database/` | T-SQL schema and permission scripts |

## API

| Method | Route | Purpose |
|---|---|---|
| POST | `/api/v1/orchestrator/run/{project}/{environment}/{scenario}` | Execute a scenario |
| GET | `/api/v1/orchestrator/projects` | List projects |
| GET | `/api/v1/orchestrator/environments?project=` | List environments |
| GET | `/api/v1/orchestrator/scenarios?project=&environment=` | List scenarios |
| GET | `/health/live` | Liveness (no key required) |
| GET | `/health/ready` | Readiness, includes database check (no key required) |

All other routes require the `X-Api-Key` header.

## Configuration

| Setting | Env variable | Required | Notes |
|---|---|---|---|
| `KeyVault:Uri` | `KeyVault__Uri` | Recommended in Azure | Loads secrets from Azure Key Vault at startup (see docs) |
| `KeyVault:ManagedIdentityClientId` | `KeyVault__ManagedIdentityClientId` | No | Only for a user-assigned managed identity |
| `ConnectionStrings:OrchestratorDb` | `ConnectionStrings__OrchestratorDb` | Yes | Or Key Vault secret `ConnectionStrings--OrchestratorDb` |
| `ApiKey:ValidKeys` | `ApiKey__ValidKeys__0`, `__1`, … | Yes | Or Key Vault secrets `ApiKey--ValidKeys--0`, … ; with no keys every request returns 503 |
| `Security:BlockAllPrivateNetworks` | `Security__BlockAllPrivateNetworks` | No | `true` blocks outbound calls to private ranges |
| `ASPNETCORE_ENVIRONMENT` | same | Yes | Use `Production` (disables Swagger) |
| `ASPNETCORE_FORWARDEDHEADERS_ENABLED` | same | Behind a proxy | `true` behind App Service / Front Door / ingress |

No secrets are stored in the repository. See [docs/AZURE_DEPLOYMENT.md](docs/AZURE_DEPLOYMENT.md) for the
full deployment guide, including passwordless access with a managed identity.

## Local development

Prerequisites: .NET 10 SDK and SQL Server LocalDB (or any SQL Server instance).

```bash
sqlcmd -S "(localdb)\MSSQLLocalDB" -Q "CREATE DATABASE TdmOrchestrator"
sqlcmd -S "(localdb)\MSSQLLocalDB" -d TdmOrchestrator -i database/001_InitialSchema.sql
dotnet run --project src/Tdm.Orchestrator.Api
```

`appsettings.Development.json` points at LocalDB and defines a development-only API key. Swagger is
available at `/swagger` in Development.

## Container

```bash
docker build -t tdm-orchestrator .
docker run -p 8080:8080 \
  -e ConnectionStrings__OrchestratorDb="<connection string>" \
  -e ApiKey__ValidKeys__0="<key>" \
  tdm-orchestrator
```

## Admin UI
Open `/admin-ui/` and sign in with an admin key (`Admin:ApiKeys`, sent as `X-Admin-Key`). Add connections (base URLs),
create scenarios and steps, run **Check**, then use **Use in Postman** to copy the run URL and sample body. Running a
scenario still uses the separate run key (`X-Api-Key`). In Azure keep the admin key in Key Vault as `Admin--ApiKeys--0`
and restrict access to `/admin-ui` and `/api/v1/admin` (network rules or Entra ID in front) for production.
Restart the app after changing keys.

The UI is a **React + TypeScript** app (Vite) whose source is in [`admin-ui/`](admin-ui/). The compiled build is committed in
`src/Tdm.Orchestrator.Api/wwwroot/admin-ui/`, so `dotnet run` serves it with no Node needed. To change the UI (Node 20+):

```bash
cd admin-ui
npm install
npm run dev      # http://localhost:5173/admin-ui/ with hot reload; proxies /api to http://localhost:5000 (run the API first)
npm run build    # type-checks, then writes the production build into the API's wwwroot/admin-ui (commit the result)
```

Set `TDM_API_URL` if the API is not on `http://localhost:5000`.

## Users, groups and admins
The admin UI has two kinds of account, both created by an administrator under **Users**:

| Role | Can do |
|---|---|
| **Administrator** | Everything: manage groups and users, see and edit every group's scenarios, connections and run history, move a scenario to another group. |
| **User** (belongs to one group) | Full control of **their group's** scenarios, steps, connections and run history. Cannot see other groups, the Groups/Users pages, or unassigned data. |

A group is a team. Scenario names are unique across the whole system; connection names are unique **per group**
(two teams can each have `Partner.BaseUrl`). A scenario's steps use only the connections of its own group.

**First-time setup**
1. Sign in with the admin key ("Administrator? Sign in with the admin key"). This always works and is meant for bootstrapping.
2. **Groups**: add a group per team. **Users**: add yourself (and others) as Administrators, and a user per person with their group.
3. Existing scenarios and connections have no group, so only administrators see them. Open each scenario and use
   **Change group…**, and edit each connection to choose its group (a scenario and its connections must be in the same group).
4. Hand out the user names and passwords. Resetting a password, disabling a user or changing their group signs them out.

Running a scenario is unchanged: Postman keeps using the shared `X-Api-Key`.

Passwords are stored as PBKDF2 hashes, sessions are server-side (token hash only) and last `Admin:SessionHours` (default 8).
`Admin:MinPasswordLength` defaults to 8. Sign-in is limited to 10 attempts per minute per IP.

**Database:** run `database/004_AddGroupsAndUsers.sql` and `database/005_AddRunGroupId.sql` once on an existing database (idempotent), or set
`Database:AutoUpgrade=true` for one start. In Development it is applied automatically.

## Building scenarios faster
- **Import steps** (Steps tab → *Import…*): upload or paste a **Postman collection** (v2.x) or an **OpenAPI / Swagger** file
  (JSON or YAML). Pick the requests you want and a base URL connection; one step per request is created in file order.
  Path parameters, required query parameters and body fields become `{input.name}` / `$input.name` placeholders (switch
  this off to keep the example values). Authorization headers, scripts and non-JSON bodies are not imported.
- **Build from JSON** (Add/Edit step → Request): paste an example request, tick the fields the user will fill in, rename
  them if you like. The request template is written for you and the "users will send" preview shows the `inputData` they need.
- **Response fields** (Add/Edit step → Response): paste an example response, tick the fields later steps may use (or add
  one by name, e.g. `applicant.id`, `items[0].sku`). In later steps a picker, "Use a field from an earlier step…", inserts the
  right `$stepN.field` (or `{stepN.field}` in the endpoint) for you, and the polling condition field suggests this step's
  ticked fields. The ticked list is stored in the step's `OutputParamMap`, which API steps do not otherwise use, so there is no schema change.
- **Flow** tab: the scenario drawn as a flow: user inputs, each step, polling loops, dependencies on earlier steps and the response.
- **Unique scenario names:** the New scenario and Clone dialogs check the name as you type. A scenario is identified by
  project + environment + name (case-insensitive) across all groups, because that triple is the run URL.

## Polling (wait until a status changes)

For work that finishes later, for example a policy that moves to *approved* after 20–30 minutes, tick **Keep checking
this call until a condition is met** in the step editor and set:

| Setting | Meaning |
|---|---|
| Stop when response field / condition / value | e.g. `step2.status` **equals** `approved` |
| Check every (seconds) | Pause between checks (`PollIntervalSeconds`) |
| Give up after (minutes) | Total time before the step fails (`PollMaxWaitSeconds`) |
| Request body for the re-checks | Optional; empty means the same body is sent again |

The call is made once immediately and then every interval. Timeout applies to each call; *Wait before step* is a one-time
delay. The whole scenario runs inside one HTTP request, so keep the total under about 230 s when it runs behind Azure's
front end (the **Check** tab warns about this). Existing database: run `database/003_AddPollingColumns.sql` once.

## Further reading

- [docs/AZURE_DEPLOYMENT.md](docs/AZURE_DEPLOYMENT.md) — database setup, identity, deployment checklist
- [PRODUCTION_HARDENING.md](PRODUCTION_HARDENING.md) — security notes and open items
- [CHANGELOG.md](CHANGELOG.md) — release history
