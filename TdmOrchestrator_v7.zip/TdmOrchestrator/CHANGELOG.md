# Run history shows which step failed

- **Run history is now one row per run** (scenario execution). A failed run shows **"Failed at step N"** with the error message
  inline; click a row to see every step (status, tries, called URL, error). The failing step is highlighted and steps after it are
  marked as not run. A **Failed runs only** filter is included.
- **Behaviour change:** a REST step that gets an HTTP status of 400 or higher (404, 401, 500, ...) now **fails the step and stops the run**
  with a message like `Step 2 (Get app) failed: HTTP 404 from GET <url>: <body>`. Before, such responses were passed on to the next step.
  Retries still happen only for 5xx. If a step is expected to return 4xx, untick it or give it its own scenario.
- A polling timeout now reports the last HTTP status it saw.
- New column `OrchestrationRuns.RunGroupId` groups the steps of one run. **Run `database/005_AddRunGroupId.sql` before starting this version**
  (or set `Database:AutoUpgrade=true`). Older rows have no group id and show as single-step runs.

---

# Build from JSON: one live preview

- The converter now shows a single **Preview** beside the field list. It updates as each field is ticked or renamed, highlights the
  chosen inputs, and lists "Users will send: ..." underneath. The separate "Users will send" JSON box is gone.

---

# Step numbers stay tidy

- **Deleting a step renumbers the rest** (delete step 1: step 2 becomes step 1, and so on; gaps are closed). References such as
  `$step2.id`, `{step2.id}` and `"step2.status"` in the remaining steps are rewritten to follow the steps. A reference to the deleted
  step becomes `step0`, which never exists, so it shows up as a broken reference (Check tab, Flow tab) instead of silently pointing at another step.
- **No two steps with the same order number** in one scenario: refused by the server when adding or editing (`STEP_ORDER_DUPLICATE`),
  and flagged live in the step editor. Not a database constraint, so existing databases with duplicates keep working; fix them by renumbering.
- Moving a step up or down is now one call, `POST /api/v1/admin/steps/{id}/move` `{ "direction": "up"|"down" }`, and references follow the moved steps.
- The delete confirmation says how many steps will be renumbered and which steps use values from the deleted one.

---

# Pick response fields for later steps

- New **Response** section in the step editor: tick the fields of a step's response that later steps can use.
- Later steps get a "Use a field from an earlier step…" picker (inserts `$stepN.field` / `{stepN.field}`), and the polling
  condition field suggests the step's own ticked fields. The Flow tab shows "returns · field" chips.
- Stored as `{"fields":[{"path","example"}]}` in `OutputParamMap` of API steps (ignored by the engine); no database change.
  Consolidate steps still use `OutputParamMap` as their output template.

---

# Easier scenario building

- **Import:** create steps from a Postman collection or an OpenAPI / Swagger file (JSON or YAML), client-side parsing, no new endpoint.
- **Step editor redesigned:** three short sections (Basics, Request, Waiting & retries) instead of one long form; Back / Next buttons.
- **Build from JSON:** pick the user-input fields from an example request instead of typing `$input.name` by hand.
- **Flow tab** showing the scenario as a flow diagram.
- **Unique scenario names:** live check while typing. New endpoint `GET /api/v1/admin/scenarios/check-name?project=&environment=&scenario=`
  returns `{available, visible, message}`; another group's scenario is reported without revealing it. Saving a step still enforces uniqueness on the server.
- UI dependency added: `yaml` (for OpenAPI YAML files).

Not compiled here (no .NET SDK): run `dotnet build` before release.

---

# Users, groups and admins

Different teams can now have their own sign-ins and see only their own data.

- **Roles:** Administrator (everything) and User (belongs to one group, full control of that group's scenarios,
  steps, connections and run history). Only administrators create groups and users.
- **Sign-in:** user name + password in the admin UI. The admin key still works for bootstrapping the first administrator.
  Sessions are server-side and expire after `Admin:SessionHours`; password reset, disable, delete or a group change signs the user out.
- **Database:** new tables `UserGroups`, `AppUsers`, `UserSessions`; nullable `GroupId` on `OrchestrationSteps` and
  `ApiConfig` (NULL = unassigned, visible to administrators only). `ApiConfig` uniqueness is now (GroupId, ConfigKey).
  Run `database/004_AddGroupsAndUsers.sql` on existing databases (or `Database:AutoUpgrade=true`).
- **Engine:** a scenario resolves its connections only from its own group. After upgrading, assign each existing
  scenario and its connections to a group, or runs will look for connections with no group.
- **API:** `/api/v1/admin/auth/{login,me,logout}`, `/groups`, `/users`, `POST /scenarios/{p}/{e}/{s}/group`.
  Non-admin calls are filtered to the caller's group on the server, not just hidden in the UI.
- **Admin UI:** login form, Groups and Users pages, group columns/pickers for administrators.
- The run API (`X-Api-Key`) is unchanged.

Not compiled here (no .NET SDK): run `dotnet build` and test sign-in, a user's group isolation and a scenario run before release.

---

# Polling gets its own settings

Waiting for something to change (for example a policy reaching "approved") used to borrow the step's **Retries** and
**Wait** fields, which also meant "retry on 5xx" and "delay before the step". Polling now has dedicated settings.

- **Database:** two new columns on `OrchestrationSteps`: `PollIntervalSeconds` (check every N seconds) and
  `PollMaxWaitSeconds` (give up after N seconds), both default 0. New installs get them from `001_InitialSchema.sql`.
  Existing databases: run `database/003_AddPollingColumns.sql` once (idempotent). In Development the app adds the
  columns itself at startup.
- **Engine:** a step with a `poll` block uses the new columns when `PollIntervalSeconds` > 0. Steps saved before this
  release (poll block, columns at 0) behave exactly as before, so nothing breaks.
- **Admin UI:** the step editor has a **Polling** section: the field to watch, the condition, how often to check, and
  when to give up (in minutes), plus an optional request body for the re-checks. Editing an old-style polling step
  converts it and clears its Retries/Wait. The steps list shows a "Polling" summary.
- **Admin API:** `StepDto` gained `pollIntervalSeconds` and `pollMaxWaitSeconds` (validated; REST steps only). The Check
  tab includes polling time in its worst-case run estimate and flags polling without a condition.
- Note: `Wait` is still a one-time delay before a step runs, for every step type. A polling step with the old settings
  therefore waited once up front *and* used the same number as its interval; the new settings avoid that.

Not compiled here (no .NET SDK): run `dotnet build` and a quick scenario test before release.

---

# Fix: admin UI redirect loop (429 on /admin-ui)

- `Program.cs`: `/admin-ui` is now redirected to `/admin-ui/` by exact-path middleware instead of `MapGet`, which also matched
  `/admin-ui/` and redirected forever (each loop counted against the rate limiter, producing HTTP 429).
- Static files are served from an explicit `wwwroot` folder; the admin web page is exempt from the rate limiter
  (the admin API remains limited).

---

# Admin UI rewritten in React

- The admin UI is now a React 18 + TypeScript single-page app built with Vite (source in `admin-ui/`). Same features, same
  look and same admin API as before: scenarios, step editor (with value insertion and JSON checks), clone/enable/delete,
  Postman request and collection download, validation check, connections, run history.
- Build output replaces the old `app.js`/`app.css`/`index.html` in `wwwroot/admin-ui/`; no server changes were needed.
- Existing `#/scenarios`, `#/scenario/...`, `#/connections` and `#/runs` links still work.
- Small behaviour changes: delete confirmations are in-page dialogs instead of browser pop-ups; load errors show a
  "Try again" card.

---

# Azure SQL migration

The database provider was changed and optional Azure Key Vault configuration was added at startup. No orchestration logic was modified.

## Changed
- `Npgsql.EntityFrameworkCore.PostgreSQL` replaced with `Microsoft.EntityFrameworkCore.SqlServer`.
- `Program.cs`: `UseNpgsql(...)` replaced with `UseSqlServer(...)`; connection string key is now
  `ConnectionStrings:OrchestratorDb` (was `ConnectionStrings:Postgres`). `EnsureCreated()` at startup is unchanged.
- PostgreSQL-specific EF migrations removed (they cannot run on SQL Server). Schema is created by `EnsureCreated()`
  as before; `database/001_InitialSchema.sql` is provided as an optional script for a DBA-managed deployment.
- Pinned `System.Security.Cryptography.Pkcs` 10.0.13 (patched; the transitive 10.0.x version has known advisories).
- `InvariantGlobalization` set to `false` in the csproj: Microsoft.Data.SqlClient does not support invariant mode.
- `appsettings.json`: database password and API key removed (secrets must come from the environment).
- Project placed under `src/`; files renamed to match the class they contain (no namespace or code changes).

## Added
- **Azure Key Vault support.** When `KeyVault:Uri` is set, secrets are loaded into configuration at startup using the
  managed identity (`DefaultAzureCredential` in Development). New packages: `Azure.Identity`,
  `Azure.Extensions.AspNetCore.Configuration.Secrets`. Disabled when the setting is empty.
- `Dockerfile`, `.dockerignore`, `database/` scripts, `docs/AZURE_DEPLOYMENT.md`, root `README.md`.

- **Admin UI** at `/admin-ui/` and admin API at `/api/v1/admin` (additive; the orchestration engine is untouched).
  Lets users manage connections (base URLs), scenarios and steps, validate a scenario, copy the Postman request or
  download a Postman collection, and browse run history, without writing SQL. Protected by a separate admin key
  (`X-Admin-Key`, `Admin:ApiKeys`); fails closed (503) when no admin key is configured. Secret-looking connection
  values are masked and never returned. `ApiKeyAuthMiddleware` only gained the `/api/v1/admin` prefix exemption.

## Verification note
Prepared without a .NET SDK: C# not compiled or run (the admin UI JavaScript was exercised in a browser against a mock server). Run `dotnet build` and a smoke test against Azure SQL before release.

---

# Critical Fix + New Polling Feature

## 1. CRITICAL: the project did not compile at all

**File changed:** `Utility/PlaceholderResolver.cs`

While building the polling feature below, I found `ResolveConditional` calls a method
named `EvaluateOperators` that was **never defined anywhere in the project**. This is not
a style issue or a logic bug — it's a compile error (`CS0103`). As uploaded, this codebase
cannot build, which means every `$when`/`$then` conditional in your `InputParamMap` data
today — the height/weight toggle, the state-based HIV question, the GA Whole Life
underwriting skip, the replacement-policy block — has never actually run, because the
service can't start.

Three helper methods (`ValuesEqual`, `TryCompareValues`, `ValueContains`) already existed
in the file, fully implemented, but were unreachable — nothing called them, because the one
method that was supposed to dispatch to them was missing. That's a strong signal this was an
accidental deletion during a previous edit, not a deliberate incomplete feature.

**Fix:** implemented `EvaluateOperators` to dispatch to exactly those three existing helpers,
matching the operator list already documented on the class (`equals`, `notEquals`,
`greaterThan`, `greaterThanOrEqual`, `lessThan`, `lessThanOrEqual`, `contains`). Nothing else
in `ResolveConditional` was touched — this restores the behavior the code was already written
and documented to have, it doesn't change it.

**I could not compile this to confirm** — this sandbox has no `dotnet` SDK and no access to
`nuget.org`, so I've never been able to run `dotnet build` against this project in this
conversation. I checked this by hand as rigorously as I could (every brace/paren across every
file balances, every new call matches a confirmed interface signature, every pattern mirrors
already-proven code elsewhere in the same file) — but **run `dotnet build` yourself before
deploying anything from this pass.** This is the first thing to verify.

## 2. New: steps can now poll until a condition is met

**File changed:** `Services/TestDataOrchestrationService.cs`

Added support for an optional `"poll"` block inside a step's `InputParamMap`, alongside
`"body"`:

```json
{
  "body": { ... the step's normal first-call payload ... },
  "poll": {
    "condition": { "field": "step2.status", "equals": "approved" },
    "body": { ... optional: a different payload for every re-call after the first ... }
  }
}
```

No new database columns. When a step has a `"poll"` block:
- The step calls its own endpoint once with `body`, same as always.
- If `poll.condition` doesn't match that response, it waits and calls the **same endpoint
  again** — using `poll.body` if given, or the original `body` otherwise — repeating until
  the condition matches or it runs out of attempts.
- Each attempt's response overwrites what's stored for that step, so both the condition check
  and any later step referencing `$stepN.xxx` see the latest data, not the first call's.
- If it never matches, the step fails with a clear "timed out after N poll attempts" error —
  same as any other step failure, the run doesn't hang or silently move on.

`RetryCount` and `WaitTimeSeconds` are reused for this — **only on a step that has a `"poll"`
block.** On such a step they mean something different than usual: `RetryCount` becomes the
max number of *additional* poll attempts (not retries on a 5xx), and `WaitTimeSeconds`
becomes the delay *between* poll attempts (not a one-time delay before the step runs). Steps
without a `"poll"` block are completely unaffected — same retry-on-5xx behavior as before.

Also added `PlaceholderResolver.EvaluateCondition(...)`, a small public method that reuses the
exact same field-lookup and operator logic `$when`/`$then` already uses, so the poll condition
check and template conditionals stay in sync instead of duplicating comparison logic.

---

# What Changed in This Round (Production-Readiness & Optimization Pass)

This pass hardens and cleans up the project from the last upload. Every change below is
either dead-code removal, a pure performance/readability improvement, or a fix for a real
bug — nothing in the API's request/response contract, validation rules, retry behavior, or
orchestration logic changed. The one item that changes observable behavior (item 1) is a bug
fix, flagged clearly so you can revert it if you were relying on the old behavior.

## 1. Bug fix: per-step timeouts over 60 seconds were silently capped

**File changed:** `Program.cs`

`OrchestrationStep.TimeoutSeconds` is supposed to control how long the engine waits for a
step's HTTP call before giving up, and `HttpApiClient` already builds a
`CancellationTokenSource` from that exact value. But the shared `HttpClient` registered in
`Program.cs` also had its own fixed `Timeout = TimeSpan.FromSeconds(60)`. `HttpClient.Timeout`
races against whatever token you pass to `SendAsync` — whichever fires first wins. So any step
configured with `TimeoutSeconds` above 60 was quietly cut off at 60s anyway, with no error or
log line telling you why.

Fixed by setting `client.Timeout = Timeout.InfiniteTimeSpan` and letting the per-step
`CancellationTokenSource` be the only thing that can time out a request — the standard pattern
Microsoft recommends for `IHttpClientFactory` clients that need a caller-supplied timeout.
Steps with `TimeoutSeconds <= 60` behave exactly as before; steps configured above 60 will now
actually get the time they were configured for.

## 2. Security: removed a real database password and API key from source

**Files changed:** `appsettings.json`, `appsettings.Development.json` (new)

`appsettings.json` had a live-looking Postgres password and a fixed API key
(`dev-test-key-12345`) committed in plaintext. `appsettings.json` applies to **every**
environment unless explicitly overridden, so any deployment that didn't override these — for
example, one that only set `ASPNETCORE_ENVIRONMENT=Production` without also setting the
connection string and API key env vars — would have been running with this exact password and
a hardcoded skeleton-key API credential, anyone with the source could use.

Fixed by:
- Blanking both values in `appsettings.json`, so any non-Development environment now fails
  fast at startup (same "fail closed" pattern already used for the API-key gate) unless
  `ConnectionStrings__Postgres` and `ApiKey__ValidKeys` are set explicitly.
- Adding `appsettings.Development.json` with the original local values, so `dotnet run` still
  works out of the box for local development with **zero** change in behavior — ASP.NET Core
  loads this file automatically because `Properties/launchSettings.json` sets
  `ASPNETCORE_ENVIRONMENT=Development` for the `http` profile.

This also corrects a discrepancy from the previous round: the changelog below states the
password field had already been blanked, but it hadn't been — it's blanked now.

## 3. Removed dead code

None of this was reachable from any registered service or entry point, so removing it changes
nothing at runtime:

- `Services/OrchestratorService.cs` — the unused duplicate engine flagged in
  `PRODUCTION_HARDENING.md` as safe to delete.
- `Models/HttpResponseDto.cs` — an empty stub; the real `HttpResponseDto` lives in
  `Services/ITestDataOrchestrationService.cs`.
- `Data/SeedData.cs` — `DatabaseInitializer.Initialize()` was a no-op and was never called
  anywhere.
- `Utility/PlaceholderResolver.cs.backup` and `.backuplatest` — stray backup files (not
  compiled — the `.csproj` only picks up `*.cs`).
- Large commented-out duplicate implementations at the bottom of
  `Utility/NetworkSafetyValidator.cs` and `Utility/RestApiUtility.cs`.

## 4. Read-only validation queries now skip EF Core change tracking

**File changed:** `Services/RequestValidatorService.cs`

Every method on `OrchestrationValidator` (`IsValidProjectAsync`, `GetScenariosAsync`, etc.) is
a read-only existence check or lookup — the results are never modified and saved back. They
were missing `.AsNoTracking()`, so EF Core was doing change-tracking bookkeeping for every row
on every single validation call, for no benefit. Added `.AsNoTracking()` via a shared private
`ActiveSteps()` helper that also removes the duplicated `Where(active)` filter that was
copy-pasted across all six methods. Query results are identical; this only removes
unnecessary tracking overhead.

## 5. Formatting cleanup — no logic changes

**Files changed:** `Services/TestDataOrchestrationService.cs`, `Utility/RestApiUtility.cs`,
`Utility/NetworkSafetyValidator.cs`

Fixed inconsistent indentation and merged statements that were fragmented across many
unnecessary line breaks. Verified line-by-line (comments and whitespace stripped) that these
files are token-for-token identical to the previous version aside from the two additions in
items 1 and 3.

## 6. `OrchestrationStep` defaults now reference the shared constants

**File changed:** `Entities/OrchestrationStep.cs`

`RetryCount = 0`, `TimeoutSeconds = 30`, and `ActiveFlag = "A"` were hardcoded a second time
here, duplicating `OrchestrationConstants.DefaultRetryCount`, `DefaultTimeoutSeconds`, and
`ActiveFlag_Active` from `Constants/CommonConstant.cs`. Now references the constants instead —
same values, one source of truth.

## 7. Repo hygiene

Added a `.gitignore` (the zip previously had no way to keep `bin/`/`obj/` build output and
local secrets files out of version control).

## Not changed, but worth knowing about

- `Utility/ConfigFetcher.cs` loads the **entire** `ApiConfig` table into memory on every single
  orchestration run, even though a run typically only needs a handful of keys. Left as-is
  since this table is presumably small and adding caching would trade off consistency
  (config changes would take effect with a delay) — flagging in case your `ApiConfig` table
  grows large enough for this to matter.
- The case-insensitive lookups (`x.ToLower() == y.ToLower()`) in `RequestValidatorService.cs`
  and `TestDataOrchestrationService.cs` still can't use a plain index — Postgres would need a
  functional index on `lower(ProjectName)` etc. to make these sargable. Not added here since
  `EnsureCreated()` won't retrofit an index change onto an existing database anyway (see the
  "Known gaps" note below on migrations); worth a real migration if this table grows large.
- Did not add response caching, output caching, or response compression — these change
  observable behavior (staleness, or introduce BREACH-class considerations over HTTPS) and
  felt outside the bounds of "don't change functionality" without an explicit ask.

---

# Previous Round



This zip is your complete `TdmAPIOrchestrator` project, with two functional changes applied
on top of everything you originally uploaded, plus the `EnsureCreated()` switch from earlier
in our conversation. Everything else is byte-for-byte what you gave me.

## 1. Retry Count now actually works

**File changed:** `Services/TestDataOrchestrationService.cs`

Previously, `OrchestrationStep.RetryCount` existed as a database column but nothing in the
engine ever read it — a step configured with `RetryCount = 3` behaved identically to one with
`RetryCount = 0`.

Now, `ExecuteStepAsync` wraps the external API call (RESTAPI steps only — CONSOLIDATE steps
don't call anything, so retries don't apply) in a loop:

- `RetryCount` = the number of EXTRA attempts allowed after the first try.
  (`RetryCount = 2` → up to 3 total attempts.)
- Only **server-side/network failures are retried** — any HTTP status `>= 500`. This includes
  the `502`/`504` statuses `HttpApiClient` already returns for connection errors and timeouts.
- **Client errors (4xx) are never retried** — a bad request or invalid URL won't succeed just
  by calling it again, so we don't waste attempts on those.
- A short **linear backoff** runs between attempts (1s, then 2s, then 3s, ...) so a struggling
  downstream service isn't hammered immediately.
- Each retry attempt is logged (`_logger.LogWarning`), and if a step ultimately succeeds after
  retrying, that's logged too — so the behavior is visible in your logs during a demo.

**Nothing about the database schema changed.** `RetryCount` already existed as a column; this
just makes the engine respect the value that's already there. No migration needed.

### Try it yourself

Set a step's `RetryCount` to something like `2`, then point its `Endpoint` at something that
will fail with a 5xx (or temporarily break a real integration) — you'll see the retry attempts
show up in the application logs before it finally gives up (or succeeds).

## 2. PATCH is now a documented constant

**File changed:** `Constants/CommonConstant.cs`

Added:
```csharp
public const string HttpMethod_Patch = "PATCH";
```

**Important:** PATCH already worked before this change — `HttpMethod` is a free-text column,
and `HttpApiClient` passes whatever string is there straight to .NET's `HttpMethod` class,
which accepts any verb. This addition is purely so `PATCH` is visible alongside `GET`/`POST`/
`PUT`/`DELETE` in the one file that documents supported methods — no behavior changed.

## Reminder: EnsureCreated (from earlier in our conversation)

`Program.cs` uses `db.Database.EnsureCreated()` instead of `db.Database.Migrate()`, per your
request to stop using EF migrations. The `Migrations/` folder is still included in this zip for
reference, but nothing in the app reads it anymore. See our earlier conversation for the
tradeoffs of this choice (schema changes won't auto-apply to an existing database).

## Known gaps NOT addressed in this package (flagged earlier, still open)

- No authentication on the Orchestrator API itself.
- ~~The duplicate `OrchestratorService.cs` is still present but unused~~ — removed in the
  production-readiness pass above.
- ~~`appsettings.json`'s password field has been blanked~~ — this was inaccurate; it has
  actually been blanked in the production-readiness pass above.
