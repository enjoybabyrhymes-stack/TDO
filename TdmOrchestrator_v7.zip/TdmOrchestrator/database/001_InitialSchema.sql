/* ============================================================================
   TDM Orchestrator — initial schema for Azure SQL / SQL Server
   Idempotent: safe to run more than once.

   Run against the target database (not master), as a user with DDL rights:
     sqlcmd -S <server>.database.windows.net -d <database> -G -i 001_InitialSchema.sql

   Requirements
   - Database collation must be case-insensitive (the Azure SQL default,
     SQL_Latin1_General_CP1_CI_AS). Scenario lookups rely on this.
   - Keep this script in step with src/Tdm.Orchestrator.Api/Entities/*.cs.
   ============================================================================ */
SET NOCOUNT ON;
SET XACT_ABORT ON;
BEGIN TRANSACTION;

/* ---- ApiConfig: key/value settings (e.g. downstream base URLs) ---------- */
IF OBJECT_ID(N'dbo.ApiConfig', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ApiConfig
    (
        Id          INT IDENTITY(1,1) NOT NULL,
        ConfigKey   NVARCHAR(150)     NOT NULL,
        ConfigValue NVARCHAR(MAX)     NOT NULL,
        Description NVARCHAR(MAX)     NULL,
        CreatedAt   DATETIME2(7)      NOT NULL CONSTRAINT DF_ApiConfig_CreatedAt DEFAULT SYSUTCDATETIME(),
        UpdatedAt   DATETIME2(7)      NOT NULL,
        CONSTRAINT PK_ApiConfig PRIMARY KEY CLUSTERED (Id)
    );

    CREATE UNIQUE NONCLUSTERED INDEX IX_ApiConfig_Key ON dbo.ApiConfig (ConfigKey);
END;

/* ---- OrchestrationSteps: scenario definitions -------------------------- */
IF OBJECT_ID(N'dbo.OrchestrationSteps', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.OrchestrationSteps
    (
        ServiceId        INT IDENTITY(1,1) NOT NULL,
        ProjectName      NVARCHAR(100)     NOT NULL,
        Environment      NVARCHAR(100)     NOT NULL,
        ScenarioName     NVARCHAR(150)     NOT NULL,
        StepOrder        INT               NOT NULL,
        StepDescription  NVARCHAR(MAX)     NULL,
        StepType         NVARCHAR(30)      NOT NULL,
        BaseUrlConfigKey NVARCHAR(150)     NULL,
        Endpoint         NVARCHAR(MAX)     NULL,
        HttpMethod       NVARCHAR(10)      NULL,
        InputParamMap    NVARCHAR(MAX)     NULL,
        OutputParamMap   NVARCHAR(MAX)     NULL,
        RetryCount       INT               NOT NULL,
        TimeoutSeconds   INT               NOT NULL,
        WaitTimeSeconds  INT               NOT NULL,
        PollIntervalSeconds INT            NOT NULL CONSTRAINT DF_OrchestrationSteps_PollInterval DEFAULT 0,
        PollMaxWaitSeconds  INT            NOT NULL CONSTRAINT DF_OrchestrationSteps_PollMaxWait  DEFAULT 0,
        ActiveFlag       NVARCHAR(1)       NOT NULL,
        CreatedAt        DATETIME2(7)      NOT NULL,
        UpdatedAt        DATETIME2(7)      NOT NULL,
        CONSTRAINT PK_OrchestrationSteps PRIMARY KEY CLUSTERED (ServiceId)
    );

    CREATE NONCLUSTERED INDEX IX_OrchestrationSteps_Lookup
        ON dbo.OrchestrationSteps (ProjectName, Environment, ScenarioName, StepOrder);

    CREATE NONCLUSTERED INDEX IX_OrchestrationSteps_Active
        ON dbo.OrchestrationSteps (ActiveFlag);
END;

/* ---- OrchestrationRuns: per-step execution audit trail ------------------ */
IF OBJECT_ID(N'dbo.OrchestrationRuns', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.OrchestrationRuns
    (
        RunId              BIGINT IDENTITY(1,1) NOT NULL,
        ProjectName        NVARCHAR(100)        NOT NULL,
        Environment        NVARCHAR(100)        NOT NULL,
        ScenarioName       NVARCHAR(150)        NOT NULL,
        ServiceId          INT                  NOT NULL,
        StepOrder          INT                  NOT NULL,
        RunGroupId         NVARCHAR(36)         NULL,
        RequestUrl         NVARCHAR(MAX)        NULL,
        ExecutionStartTime DATETIME2(7)         NOT NULL CONSTRAINT DF_OrchestrationRuns_Start DEFAULT SYSUTCDATETIME(),
        ExecutionEndTime   DATETIME2(7)         NULL,
        Status             NVARCHAR(20)         NULL,
        AttemptCount       INT                  NOT NULL,
        ErrorMessage       NVARCHAR(MAX)        NULL,
        ExecutedBy         NVARCHAR(100)        NULL,
        CreatedAt          DATETIME2(7)         NOT NULL,
        CONSTRAINT PK_OrchestrationRuns PRIMARY KEY CLUSTERED (RunId)
    );

    CREATE NONCLUSTERED INDEX IX_OrchestrationRuns_Scenario
        ON dbo.OrchestrationRuns (ProjectName, Environment, ScenarioName);
END;

COMMIT TRANSACTION;
