/*
  003_AddPollingColumns.sql
  Adds the dedicated polling settings to dbo.OrchestrationSteps:
    PollIntervalSeconds - seconds between status checks (0 = not used)
    PollMaxWaitSeconds  - total seconds to keep checking before giving up (0 = not used)

  Safe to run more than once. Existing rows get 0, so steps saved before this script keep their current behaviour.
  Run it once on every database created before this release (Development databases get it applied automatically
  at startup). Run as a login that may alter the table (db_owner / DBA), not the application login.
*/
SET XACT_ABORT ON;
BEGIN TRANSACTION;

IF COL_LENGTH(N'dbo.OrchestrationSteps', N'PollIntervalSeconds') IS NULL
    ALTER TABLE dbo.OrchestrationSteps
        ADD PollIntervalSeconds INT NOT NULL CONSTRAINT DF_OrchestrationSteps_PollInterval DEFAULT 0;

IF COL_LENGTH(N'dbo.OrchestrationSteps', N'PollMaxWaitSeconds') IS NULL
    ALTER TABLE dbo.OrchestrationSteps
        ADD PollMaxWaitSeconds INT NOT NULL CONSTRAINT DF_OrchestrationSteps_PollMaxWait DEFAULT 0;

COMMIT TRANSACTION;
