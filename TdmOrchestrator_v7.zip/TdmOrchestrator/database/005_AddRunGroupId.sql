/* Groups the step rows of one scenario execution so Run history can show a run with the step that failed.
   Safe to run more than once. Run it BEFORE starting the new version of the API. */
SET NOCOUNT ON;
IF COL_LENGTH('dbo.OrchestrationRuns', 'RunGroupId') IS NULL
    ALTER TABLE dbo.OrchestrationRuns ADD RunGroupId NVARCHAR(36) NULL;
PRINT 'OrchestrationRuns.RunGroupId is in place.';
