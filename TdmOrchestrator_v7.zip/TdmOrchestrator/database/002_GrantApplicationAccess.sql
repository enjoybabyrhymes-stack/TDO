/* ============================================================================
   TDM Orchestrator — least-privilege access for the application identity.

   TEMPLATE: replace [<app-identity>] before running, as a Microsoft Entra admin
   connected to the target database (not master).

   <app-identity> is the name of the App Service / Container App (system-assigned
   managed identity) or the name of the user-assigned managed identity.
   ============================================================================ */

CREATE USER [<app-identity>] FROM EXTERNAL PROVIDER;

-- Scenario definitions and settings are managed by operators, not by the app.
GRANT SELECT ON dbo.OrchestrationSteps TO [<app-identity>];
GRANT SELECT ON dbo.ApiConfig          TO [<app-identity>];

-- The app only appends to the audit trail.
GRANT SELECT, INSERT ON dbo.OrchestrationRuns TO [<app-identity>];
