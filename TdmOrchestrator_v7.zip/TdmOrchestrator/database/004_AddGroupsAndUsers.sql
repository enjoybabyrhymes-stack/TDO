/*
  004_AddGroupsAndUsers.sql
  Adds groups, users and sign-in sessions, and links steps and connections to a group.

    dbo.UserGroups    - a team
    dbo.AppUsers      - people who sign in to the admin UI (role ADMIN, or USER inside one group)
    dbo.UserSessions  - sign-ins (only a hash of the session token is stored)
    GroupId (nullable) on dbo.OrchestrationSteps and dbo.ApiConfig

  A connection name is now unique PER GROUP (IX_ApiConfig_Group_Key) instead of globally.

  Existing steps and connections get GroupId = NULL, meaning "not assigned yet": only administrators can see them
  until an admin assigns them to a group in the admin UI. Runs through the API are not affected.

  Safe to run more than once. Run as a login that may alter the schema (db_owner / DBA), after 001 and 003.
  Development databases get the same changes automatically at startup.
*/
SET XACT_ABORT ON;
BEGIN TRANSACTION;

IF OBJECT_ID(N'dbo.UserGroups', N'U') IS NULL
    CREATE TABLE dbo.UserGroups (
        GroupId     INT IDENTITY(1,1) NOT NULL,
        Name        NVARCHAR(100)     NOT NULL,
        Description NVARCHAR(500)     NULL,
        CreatedAt   DATETIME2(7)      NOT NULL,
        CONSTRAINT PK_UserGroups PRIMARY KEY CLUSTERED (GroupId)
    );

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_UserGroups_Name' AND object_id = OBJECT_ID(N'dbo.UserGroups'))
    CREATE UNIQUE NONCLUSTERED INDEX IX_UserGroups_Name ON dbo.UserGroups (Name);

IF OBJECT_ID(N'dbo.AppUsers', N'U') IS NULL
    CREATE TABLE dbo.AppUsers (
        UserId       INT IDENTITY(1,1) NOT NULL,
        Username     NVARCHAR(100)     NOT NULL,
        PasswordHash NVARCHAR(400)     NOT NULL,
        Role         NVARCHAR(10)      NOT NULL,
        GroupId      INT               NULL,
        Active       BIT               NOT NULL,
        CreatedAt    DATETIME2(7)      NOT NULL,
        LastLoginAt  DATETIME2(7)      NULL,
        CONSTRAINT PK_AppUsers PRIMARY KEY CLUSTERED (UserId)
    );

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_AppUsers_Username' AND object_id = OBJECT_ID(N'dbo.AppUsers'))
    CREATE UNIQUE NONCLUSTERED INDEX IX_AppUsers_Username ON dbo.AppUsers (Username);

IF OBJECT_ID(N'dbo.UserSessions', N'U') IS NULL
    CREATE TABLE dbo.UserSessions (
        SessionId BIGINT IDENTITY(1,1) NOT NULL,
        TokenHash NVARCHAR(64)         NOT NULL,
        UserId    INT                  NOT NULL,
        CreatedAt DATETIME2(7)         NOT NULL,
        ExpiresAt DATETIME2(7)         NOT NULL,
        CONSTRAINT PK_UserSessions PRIMARY KEY CLUSTERED (SessionId)
    );

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_UserSessions_TokenHash' AND object_id = OBJECT_ID(N'dbo.UserSessions'))
    CREATE UNIQUE NONCLUSTERED INDEX IX_UserSessions_TokenHash ON dbo.UserSessions (TokenHash);

IF COL_LENGTH(N'dbo.OrchestrationSteps', N'GroupId') IS NULL
    ALTER TABLE dbo.OrchestrationSteps ADD GroupId INT NULL;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_OrchestrationSteps_Group' AND object_id = OBJECT_ID(N'dbo.OrchestrationSteps'))
    CREATE NONCLUSTERED INDEX IX_OrchestrationSteps_Group ON dbo.OrchestrationSteps (GroupId);

IF COL_LENGTH(N'dbo.ApiConfig', N'GroupId') IS NULL
    ALTER TABLE dbo.ApiConfig ADD GroupId INT NULL;

-- A connection name is unique per group instead of globally.
IF EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_ApiConfig_Key' AND object_id = OBJECT_ID(N'dbo.ApiConfig'))
    DROP INDEX IX_ApiConfig_Key ON dbo.ApiConfig;

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_ApiConfig_Group_Key' AND object_id = OBJECT_ID(N'dbo.ApiConfig'))
    CREATE UNIQUE NONCLUSTERED INDEX IX_ApiConfig_Group_Key ON dbo.ApiConfig (GroupId, ConfigKey);

COMMIT TRANSACTION;
