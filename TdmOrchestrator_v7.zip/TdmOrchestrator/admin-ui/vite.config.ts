import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';

// Production build goes straight into the API's wwwroot, where ASP.NET serves it at /admin-ui/.
const outDir = fileURLToPath(new URL('../src/Tdm.Orchestrator.Api/wwwroot/admin-ui', import.meta.url));

export default defineConfig({
  base: '/admin-ui/',
  plugins: [react()],
  build: { outDir, emptyOutDir: true },
  server: {
    port: 5173,
    // `npm run dev`: forward API calls to the running .NET app (dotnet run => http://localhost:5000).
    proxy: { '/api': { target: process.env.TDM_API_URL || 'http://localhost:5000', changeOrigin: true } }
  }
});
