import { useEffect, useRef, type ReactNode } from 'react';

interface Props { title: string; narrow?: boolean; wide?: boolean; onClose: () => void; children: ReactNode; footer: ReactNode }

/** Modal dialog: Esc or a click on the backdrop closes it; focus moves to the first field. */
export function Modal({ title, narrow, wide, onClose, children, footer }: Props) {
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const first = box.current?.querySelector<HTMLElement>('input:not([type=hidden]), select, textarea');
    first?.focus();
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [onClose]);

  return (
    <div className="modal-backdrop" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className={'modal' + (narrow ? ' narrow' : '') + (wide ? ' wide' : '')} role="dialog" aria-modal="true" aria-label={title} ref={box}>
        <h2>{title}</h2>
        {children}
        <div className="modal-foot">{footer}</div>
      </div>
    </div>
  );
}
