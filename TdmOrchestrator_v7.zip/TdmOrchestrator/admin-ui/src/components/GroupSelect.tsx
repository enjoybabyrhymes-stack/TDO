import type { Group } from '../types';

interface Props {
  id: string;
  groups: Group[];
  value: string;
  onChange: (value: string) => void;
  /** Offer an empty choice (for example "Not assigned"). */
  emptyLabel?: string;
}

export function GroupSelect({ id, groups, value, onChange, emptyLabel }: Props) {
  return (
    <select id={id} value={value} onChange={(e) => onChange(e.target.value)}>
      {emptyLabel !== undefined
        ? <option value="">{emptyLabel}</option>
        : <option value="" disabled>Choose a group…</option>}
      {groups.map((g) => <option key={g.groupId} value={String(g.groupId)}>{g.name}</option>)}
    </select>
  );
}
