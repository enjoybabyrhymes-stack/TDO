import type { NameCheck } from '../hooks';

/** Live feedback under the scenario name fields. */
export function NameStatus({ check, onOpen }: { check: NameCheck; onOpen?: () => void }) {
  if (check.state === 'idle') return <div className="name-status" aria-live="polite" />;
  if (check.state === 'checking') return <div className="name-status muted" aria-live="polite">Checking the name…</div>;
  if (check.state === 'free') return <div className="name-status ok" aria-live="polite">✓ This name is available.</div>;
  return (
    <div className="name-status bad" aria-live="polite">
      ✕ {check.message ?? 'That scenario name is already in use.'}
      {check.visible && onOpen && <> <button type="button" className="link" onClick={onOpen}>Open it</button></>}
    </div>
  );
}
