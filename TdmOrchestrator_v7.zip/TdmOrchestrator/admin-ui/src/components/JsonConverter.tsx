import { useMemo, useState } from 'react';
import { applyInputs, collectLeaves, INPUT_NAME_RE, pathLabel, suggestName } from '../jsonFields';
import { errMessage } from '../util';

interface Props {
  /** Text to start from (the step's current request template, if it is JSON). */
  initial: string;
  onUse: (template: string) => void;
  onBack: () => void;
}

/** The template text, with every chosen input shown highlighted. */
function highlight(text: string) {
  return text.split(/("\$input\.[A-Za-z_][A-Za-z0-9_]*")/g).map((part, i) =>
    i % 2 === 1 ? <mark key={i}>{part}</mark> : part);
}

const show = (v: unknown) => (typeof v === 'string' ? v : JSON.stringify(v));

/**
 * "Build from JSON": paste a sample request, tick the fields the end user will type in, name them.
 * The result is a request template using $input.name placeholders.
 */
export function JsonConverter({ initial, onUse, onBack }: Props) {
  const [text, setText] = useState(() => { try { JSON.parse(initial); return initial.trim(); } catch { return ''; } });
  // path id -> chosen input name. A field is an input exactly when it is in this map.
  const [chosen, setChosen] = useState<Map<string, string>>(new Map());

  const parsed = useMemo(() => {
    if (!text.trim()) return { value: undefined as unknown, error: '' };
    try { return { value: JSON.parse(text) as unknown, error: '' }; }
    catch (ex) { return { value: undefined as unknown, error: errMessage(ex) }; }
  }, [text]);

  const leaves = useMemo(() => (parsed.value === undefined ? [] : collectLeaves(parsed.value)), [parsed.value]);
  // Keep only choices that still exist after the pasted JSON is edited.
  const active = useMemo(() => {
    const ids = new Set(leaves.map((l) => l.id));
    return new Map([...chosen].filter(([id]) => ids.has(id)));
  }, [chosen, leaves]);

  const toggle = (id: string, path: (string | number)[], on: boolean) => {
    const next = new Map(active);
    if (on) next.set(id, suggestName(path, new Set(next.values())));
    else next.delete(id);
    setChosen(next);
  };
  const rename = (id: string, name: string) => setChosen(new Map(active).set(id, name));
  const all = () => {
    const next = new Map<string, string>(); const taken = new Set<string>();
    for (const l of leaves) { const n = suggestName(l.path, taken); taken.add(n); next.set(l.id, n); }
    setChosen(next);
  };

  const badNames = [...active.values()].filter((n) => !INPUT_NAME_RE.test(n));
  const template = parsed.value !== undefined ? JSON.stringify(applyInputs(parsed.value, active), null, 2) : '';
  const names = new Set(active.values());
  const canUse = !!template && active.size > 0 && badNames.length === 0;

  return (
    <div className="converter">
      <p className="muted small" style={{ marginTop: 0 }}>
        Paste an example of the JSON this call sends. Tick the fields the person running the scenario should fill in;
        everything you leave unticked stays fixed. The request template is written for you, with no <code>$input</code> typing.
      </p>
      <label htmlFor="jc-text">Example JSON</label>
      <textarea id="jc-text" className="mono" spellCheck={false} style={{ minHeight: 110 }} value={text}
        placeholder={'{\n  "customer": { "name": "Asha", "age": 31 },\n  "state": "FL"\n}'}
        onChange={(e) => setText(e.target.value)} />
      {parsed.error && <div className="json-status bad">Not valid JSON: {parsed.error}</div>}

      {leaves.length > 0 && (
        <div className="conv-split">
          <div className="conv-left">
            <div className="conv-head">
              <strong>{leaves.length} field{leaves.length === 1 ? '' : 's'}</strong>
              <span className="muted small">{active.size} chosen as user input</span>
              <span className="spacer" />
              <button className="btn btn-sm" type="button" onClick={all}>Choose all</button>{' '}
              <button className="btn btn-sm" type="button" onClick={() => setChosen(new Map())}>Clear</button>
            </div>
            <div className="conv-list" role="group" aria-label="Fields">
              {leaves.map((l) => {
                const name = active.get(l.id);
                const on = name !== undefined;
                return (
                  <div key={l.id} className={'conv-row' + (on ? ' on' : '')}>
                    <label className="check conv-pick">
                      <input type="checkbox" checked={on} onChange={(e) => toggle(l.id, l.path, e.target.checked)} />
                      <span className="mono">{pathLabel(l.path)}</span>
                    </label>
                    <span className="conv-sample muted" title={show(l.sample)}>{show(l.sample)}</span>
                    {on
                      ? <input aria-label={`Input name for ${pathLabel(l.path)}`} className={'mono conv-name' + (INPUT_NAME_RE.test(name!) ? '' : ' bad')}
                          value={name} onChange={(e) => rename(l.id, e.target.value.trim())} />
                      : <span className="conv-name muted small">fixed value</span>}
                  </div>
                );
              })}
            </div>
            {badNames.length > 0 && <p className="error">Input names can use letters, digits and “_”, and cannot start with a digit.</p>}
          </div>

          <div className="conv-right">
            <div className="conv-head"><strong>Preview</strong><span className="muted small">updates as you tick</span></div>
            <pre className="conv-pre" aria-label="Preview">{highlight(template)}</pre>
            <div className="conv-users" aria-label="Users will send">
              {names.size === 0
                ? <span className="muted small">Tick a field to make it a user input.</span>
                : <><span className="muted small">Users will send:</span>{[...names].map((n) => <span key={n} className="flow-chip input">{n}</span>)}</>}
            </div>
          </div>
        </div>
      )}

      <div className="conv-actions">
        <button className="btn" type="button" onClick={onBack}>Back to the step</button>
        <button className="btn btn-primary" type="button" disabled={!canUse} onClick={() => onUse(template)}>Use this template</button>
      </div>
      {leaves.length > 0 && active.size === 0 && <p className="muted small">Tick at least one field to continue.</p>}
    </div>
  );
}
