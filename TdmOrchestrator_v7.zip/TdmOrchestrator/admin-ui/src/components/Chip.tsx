import type { ReactNode } from 'react';
export const Chip = ({ kind, children }: { kind?: 'ok' | 'warn' | 'bad' | 'blue'; children: ReactNode }) =>
  <span className={'chip' + (kind ? ' ' + kind : '')}>{children}</span>;
