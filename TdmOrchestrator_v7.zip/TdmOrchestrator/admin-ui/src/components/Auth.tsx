import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { api, SESSION_STORE, setCredential, setUnauthorizedHandler, type Credential } from '../api';
import type { LoginResult, UserInfo } from '../types';

interface AuthValue {
  /** False while a saved sign-in is being checked after a page reload. */
  ready: boolean;
  user: UserInfo | null;
  isAdmin: boolean;
  signInWithPassword: (username: string, password: string) => Promise<void>;
  signInWithKey: (key: string) => Promise<void>;
  signOut: () => void;
}
const AuthCtx = createContext<AuthValue>(null!);
export const useAuth = () => useContext(AuthCtx);

function readSaved(): Credential {
  try {
    const raw = sessionStorage.getItem(SESSION_STORE);
    if (!raw) return null;
    const c = JSON.parse(raw);
    return c && (c.kind === 'token' || c.kind === 'key') && typeof c.value === 'string' ? c : null;
  } catch { return null; }
}
function save(c: Credential) {
  try { if (c) sessionStorage.setItem(SESSION_STORE, JSON.stringify(c)); else sessionStorage.removeItem(SESSION_STORE); } catch { /* ignore */ }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const saved = useMemo(readSaved, []);
  const [user, setUser] = useState<UserInfo | null>(null);
  const [ready, setReady] = useState(!saved);
  const current = useRef<Credential>(saved);
  if (saved) setCredential(saved);

  const clear = useCallback(() => {
    current.current = null;
    setCredential(null);
    save(null);
    setUser(null);
  }, []);

  useEffect(() => { setUnauthorizedHandler(clear); }, [clear]);

  // Restore a sign-in after a page reload.
  useEffect(() => {
    if (!saved) return;
    let live = true;
    api<UserInfo>('/auth/me').then(
      (u) => { if (live) { setUser(u); setReady(true); } },
      () => { if (live) { clear(); setReady(true); } }
    );
    return () => { live = false; };
  }, [saved, clear]);

  const signInWithPassword = useCallback(async (username: string, password: string) => {
    const result = await api<LoginResult>('/auth/login', { method: 'POST', body: { username, password }, anonymous: true });
    const c: Credential = { kind: 'token', value: result.token };
    current.current = c; setCredential(c); save(c); setUser(result.user);
  }, []);

  const signInWithKey = useCallback(async (key: string) => {
    const c: Credential = { kind: 'key', value: key };
    setCredential(c);
    try {
      const u = await api<UserInfo>('/auth/me');
      current.current = c; save(c); setUser(u);
    } catch (ex) {
      setCredential(null);
      throw ex;
    }
  }, []);

  const signOut = useCallback(() => {
    // Tell the server to forget the session (best effort), then clear it here.
    if (current.current?.kind === 'token') api('/auth/logout', { method: 'POST' }).catch(() => {});
    clear();
  }, [clear]);

  const value = useMemo<AuthValue>(
    () => ({ ready, user, isAdmin: user?.role === 'ADMIN', signInWithPassword, signInWithKey, signOut }),
    [ready, user, signInWithPassword, signInWithKey, signOut]);

  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}
