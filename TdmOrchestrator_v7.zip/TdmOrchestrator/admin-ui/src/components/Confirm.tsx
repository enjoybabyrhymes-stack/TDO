import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from 'react';
import { Modal } from './Modal';

type ConfirmFn = (message: string, okLabel?: string) => Promise<boolean>;
const ConfirmCtx = createContext<ConfirmFn>(() => Promise.resolve(false));
export const useConfirm = () => useContext(ConfirmCtx);

export function ConfirmProvider({ children }: { children: ReactNode }) {
  const [ask, setAsk] = useState<{ message: string; okLabel: string } | null>(null);
  const resolver = useRef<(v: boolean) => void>();

  const confirm = useCallback<ConfirmFn>((message, okLabel = 'Delete') => {
    setAsk({ message, okLabel });
    return new Promise<boolean>((resolve) => { resolver.current = resolve; });
  }, []);

  const done = useCallback((v: boolean) => { setAsk(null); resolver.current?.(v); }, []);

  return (
    <ConfirmCtx.Provider value={confirm}>
      {children}
      {ask && (
        <Modal title="Please confirm" narrow onClose={() => done(false)}
          footer={<>
            <button className="btn" type="button" onClick={() => done(false)}>Cancel</button>
            <button className="btn btn-primary" type="button" onClick={() => done(true)}>{ask.okLabel}</button>
          </>}>
          <p>{ask.message}</p>
        </Modal>
      )}
    </ConfirmCtx.Provider>
  );
}
