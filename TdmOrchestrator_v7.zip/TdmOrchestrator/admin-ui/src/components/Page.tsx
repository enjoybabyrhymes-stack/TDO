import type { ReactNode } from 'react';

export function PageHead({ title, subtitle, crumbs, actions }: { title: ReactNode; subtitle?: ReactNode; crumbs?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="page-head">
      <div>
        {crumbs && <div className="crumbs">{crumbs}</div>}
        <h1>{title}</h1>
        {subtitle && <p className="muted">{subtitle}</p>}
      </div>
      {actions && <div className="actions">{actions}</div>}
    </div>
  );
}

export function ErrorCard({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <div className="card card-pad">
      <p className="error" role="alert">{message}</p>
      <button className="btn" type="button" onClick={onRetry}>Try again</button>
    </div>
  );
}

export const Loading = () => <p className="muted">Loading…</p>;
