import { useMemo, useState } from 'react';
import { collectLeaves, pathLabel } from '../jsonFields';
import { trimArrays, type OutField } from '../outputFields';
import { errMessage } from '../util';

interface Props {
  stepOrder: number;
  fields: OutField[];
  onChange: (fields: OutField[]) => void;
}

const show = (v: unknown) => (v === undefined ? '' : typeof v === 'string' ? v : JSON.stringify(v));

/** Tick the fields of this step's response that later steps may use. */
export function ResponseFields({ stepOrder, fields, onChange }: Props) {
  const [text, setText] = useState('');
  const [manual, setManual] = useState('');

  const parsed = useMemo(() => {
    if (!text.trim()) return { leaves: [] as ReturnType<typeof collectLeaves>, error: '' };
    try { return { leaves: collectLeaves(trimArrays(JSON.parse(text))), error: '' }; }
    catch (ex) { return { leaves: [], error: errMessage(ex) }; }
  }, [text]);

  const chosen = new Set(fields.map((f) => f.path));
  const toggle = (path: string, example: unknown, on: boolean) =>
    onChange(on ? [...fields.filter((f) => f.path !== path), { path, example }] : fields.filter((f) => f.path !== path));
  const sampled = new Set(parsed.leaves.map((l) => pathLabel(l.path)));
  const extra = fields.filter((f) => !sampled.has(f.path));
  const addManual = () => {
    const p = manual.trim().replace(/^\$?step\d+\.?/, '');
    if (p && !chosen.has(p)) onChange([...fields, { path: p }]);
    setManual('');
  };

  return (
    <div className="resp-fields">
      <p className="help" style={{ marginTop: 0 }}>
        Later steps can use the values this step returns. Paste an example of its response and tick the fields they need.
        Ticked fields then appear in a picker when you write the next steps, so nobody types <code>$step{stepOrder}.…</code> by hand.
      </p>

      {fields.length > 0 && (
        <div className="chosen-fields" aria-label="Chosen response fields">
          {fields.map((f) => (
            <span key={f.path} className="flow-chip dep">
              <span className="mono">{f.path}</span>
              <button type="button" className="chip-x" aria-label={`Remove ${f.path}`} onClick={() => toggle(f.path, undefined, false)}>×</button>
            </span>
          ))}
        </div>
      )}

      <label htmlFor="rf-text">Example response JSON <span className="hint">optional, saves typing</span></label>
      <textarea id="rf-text" className="mono" spellCheck={false} style={{ minHeight: 100 }} value={text}
        placeholder={'{\n  "applicationId": "A-1001",\n  "status": "PENDING",\n  "applicant": { "id": 7 }\n}'}
        onChange={(e) => setText(e.target.value)} />
      {parsed.error && <div className="json-status bad">Not valid JSON: {parsed.error}</div>}

      {parsed.leaves.length > 0 && (
        <>
          <div className="conv-head">
            <strong>{parsed.leaves.length} field{parsed.leaves.length === 1 ? '' : 's'}</strong>
            <span className="muted small">{parsed.leaves.filter((l) => chosen.has(pathLabel(l.path))).length} ticked</span>
          </div>
          <div className="conv-list" role="group" aria-label="Response fields">
            {parsed.leaves.map((l) => {
              const path = pathLabel(l.path);
              const on = chosen.has(path);
              return (
                <label key={l.id} className={'conv-row resp-row' + (on ? ' on' : '')}>
                  <span className="check conv-pick">
                    <input type="checkbox" checked={on} onChange={(e) => toggle(path, l.sample, e.target.checked)} />
                    <span className="mono">{path}</span>
                  </span>
                  <span className="conv-sample muted" title={show(l.sample)}>{show(l.sample)}</span>
                </label>
              );
            })}
          </div>
          <p className="help">Only the first two items of a list are shown. <code>items[0].id</code> means the first item.</p>
        </>
      )}

      {extra.length > 0 && parsed.leaves.length > 0 && <p className="help">Also chosen (not in the example): {extra.map((f) => f.path).join(', ')}</p>}

      <label htmlFor="rf-manual">Add a field by name <span className="hint">for example applicant.id or items[0].sku</span></label>
      <div className="inline-add">
        <input id="rf-manual" className="mono" value={manual} placeholder="status" onChange={(e) => setManual(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addManual(); } }} />
        <button type="button" className="btn" onClick={addManual} disabled={!manual.trim()}>Add</button>
      </div>
    </div>
  );
}
