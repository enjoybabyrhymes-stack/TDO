import { useMemo, useRef, useState } from 'react';
import { api } from '../api';
import type { ConfigItem, Step } from '../types';
import { errMessage } from '../util';
import { buildTemplate, inputNames, parseImport, type ImportResult } from '../importers';
import { Modal } from './Modal';
import { useToast } from './Toasts';

interface Props {
  p: string; e: string; s: string; groupId?: number;
  steps: Step[]; configs: ConfigItem[];
  onClose: () => void; onDone: () => void;
}

/** Import a Postman collection or an OpenAPI/Swagger file: one step is created for each request chosen. */
export function ImportDialog({ p, e, s, groupId, steps, configs, onClose, onDone }: Props) {
  const toast = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [text, setText] = useState('');
  const [result, setResult] = useState<ImportResult | null>(null);
  const [picked, setPicked] = useState<Set<string>>(new Set());
  const [base, setBase] = useState('');
  const [asInputs, setAsInputs] = useState(true);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState('');

  const read = (value: string) => {
    setText(value); setErr('');
    if (!value.trim()) { setResult(null); return; }
    try {
      const r = parseImport(value);
      if (r.steps.length === 0) throw new Error('No requests were found in this file.');
      setResult(r); setPicked(new Set(r.steps.map((x) => x.key)));
    } catch (ex) { setResult(null); setErr(errMessage(ex)); }
  };

  const onFile = async (f: File | undefined) => { if (f) read(await f.text()); };

  const chosen = useMemo(() => (result?.steps ?? []).filter((x) => picked.has(x.key)), [result, picked]);
  const rows = useMemo(() => chosen.map((st) => {
    const template = buildTemplate(st, asInputs);
    return { st, template, inputs: inputNames(st, template) };
  }), [chosen, asInputs]);

  const toggle = (key: string, on: boolean) => setPicked((cur) => { const n = new Set(cur); if (on) n.add(key); else n.delete(key); return n; });

  const run = async () => {
    setErr('');
    const start = steps.length ? Math.max(...steps.map((x) => x.stepOrder)) + 1 : 1;
    setBusy(true);
    let done = 0;
    try {
      for (const [i, { st, template }] of rows.entries()) {
        setProgress(`Creating step ${i + 1} of ${rows.length}…`);
        await api('/steps', {
          method: 'POST',
          body: {
            projectName: p, environment: e, scenarioName: s, groupId: groupId ?? null,
            stepOrder: start + i, stepType: 'RESTAPI', stepDescription: st.name.slice(0, 200),
            baseUrlConfigKey: base, httpMethod: st.method, endpoint: st.endpoint,
            inputParamMap: template, outputParamMap: '',
            retryCount: 0, timeoutSeconds: 30, waitTimeSeconds: 0, pollIntervalSeconds: 0, pollMaxWaitSeconds: 0, active: true
          }
        });
        done++;
      }
      toast(`${done} step${done === 1 ? '' : 's'} created.`); onClose(); onDone();
    } catch (ex) {
      setErr(`${done} step${done === 1 ? '' : 's'} created before this failed: ${errMessage(ex)}`);
      setBusy(false); setProgress('');
      if (done > 0) onDone();
    }
  };

  return (
    <Modal title="Import steps" onClose={onClose}
      footer={<>
        <button className="btn" type="button" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary" type="button" disabled={busy || rows.length === 0} onClick={run}>
          {busy ? progress : rows.length ? `Create ${rows.length} step${rows.length === 1 ? '' : 's'}` : 'Create steps'}
        </button>
      </>}>
      <p className="muted small" style={{ marginTop: 0 }}>
        Upload a <strong>Postman collection</strong> (v2.x JSON) or an <strong>OpenAPI / Swagger</strong> file (JSON or YAML).
        Each request becomes a step, in file order, added after the existing steps.
      </p>
      <div className="import-pick">
        <input ref={fileRef} type="file" accept=".json,.yaml,.yml,application/json" hidden aria-label="Import file" onChange={(ev) => { void onFile(ev.target.files?.[0]); ev.target.value = ''; }} />
        <button className="btn" type="button" onClick={() => fileRef.current?.click()}>Choose a file…</button>
        <span className="muted small">or paste its contents below</span>
      </div>
      <textarea id="imp-text" className="mono" spellCheck={false} style={{ minHeight: 90 }} value={text}
        placeholder="Paste a Postman collection or an OpenAPI / Swagger document" onChange={(ev) => read(ev.target.value)} />
      <p className="error">{err}</p>

      {result && (
        <>
          <div className="banner ok" style={{ marginBottom: 12 }}>
            Found <strong>{result.steps.length}</strong> request{result.steps.length === 1 ? '' : 's'} in the {result.kind}
            {result.title ? <> “{result.title}”</> : null}.
          </div>
          <div className="row">
            <div>
              <label htmlFor="imp-base">Base URL <span className="hint">{result.serverHint ? `file uses ${result.serverHint}` : '(from Connections)'}</span></label>
              <select id="imp-base" value={base} onChange={(ev) => setBase(ev.target.value)}>
                <option value="">None — I will enter full URLs</option>
                {configs.map((c) => <option key={c.id} value={c.configKey}>{c.configKey}{c.isSecret ? '' : ' — ' + c.configValue}</option>)}
              </select>
            </div>
          </div>
          <label className="check">
            <input type="checkbox" checked={asInputs} onChange={(ev) => setAsInputs(ev.target.checked)} />
            Make the body fields inputs the user fills in <span className="hint">(uncheck to keep the example values fixed)</span>
          </label>

          <div className="conv-head">
            <strong>Requests</strong><span className="muted small">{picked.size} of {result.steps.length} selected</span><span className="spacer" />
            <button className="btn btn-sm" type="button" onClick={() => setPicked(new Set(result.steps.map((x) => x.key)))}>All</button>{' '}
            <button className="btn btn-sm" type="button" onClick={() => setPicked(new Set())}>None</button>
          </div>
          <div className="conv-list imp-list" role="group" aria-label="Requests">
            {result.steps.map((st) => {
              const on = picked.has(st.key);
              const row = rows.find((r) => r.st.key === st.key);
              return (
                <label key={st.key} className={'imp-row' + (on ? ' on' : '')}>
                  <input type="checkbox" checked={on} onChange={(ev) => toggle(st.key, ev.target.checked)} />
                  <span className="method">{st.method}</span>
                  <span className="imp-main">
                    <span className="imp-name">{st.name}</span>
                    <span className="mono muted small imp-path">{st.endpoint}</span>
                    {on && row && row.inputs.length > 0 && <span className="small muted">User provides: {row.inputs.join(', ')}</span>}
                    {st.notes.map((n) => <span key={n} className="small imp-note">{n}</span>)}
                  </span>
                </label>
              );
            })}
          </div>
          <p className="muted small">Authorization headers and scripts are not imported. Put secrets in a connection, and review each step afterwards.</p>
        </>
      )}
    </Modal>
  );
}
