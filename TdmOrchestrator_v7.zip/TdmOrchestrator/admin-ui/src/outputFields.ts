// The response fields of an API step that the author ticked as "later steps may use this".
// Stored with the step (in its OutputParamMap, which API steps do not otherwise use) as:
//   { "fields": [ { "path": "applicationId", "example": "A-1001" }, ... ] }

export interface OutField { path: string; example?: unknown }

export function parseFields(text?: string | null): OutField[] {
  if (!text || !text.trim()) return [];
  try {
    const v = JSON.parse(text) as { fields?: unknown };
    if (!v || !Array.isArray(v.fields)) return [];
    return v.fields
      .filter((f): f is { path: string; example?: unknown } => typeof f === 'object' && f !== null && typeof (f as { path?: unknown }).path === 'string' && (f as { path: string }).path.trim() !== '')
      .map((f) => ({ path: f.path.trim(), example: f.example }));
  } catch { return []; }
}

export const serializeFields = (fields: OutField[]): string =>
  fields.length ? JSON.stringify({ fields: fields.map((f) => (f.example === undefined ? { path: f.path } : { path: f.path, example: f.example })) }) : '';

/** `$step1.applicationId`, `$step2[0].title`, or the {step1.applicationId} form used inside endpoints. */
export function stepToken(order: number, path: string, braces: boolean): string {
  const tail = path.startsWith('[') ? path : '.' + path;
  return braces ? `{step${order}${tail}}` : `$step${order}${tail}`;
}

/** A response sample with long arrays cut down, so the field list stays readable. */
export function trimArrays(value: unknown, keep = 2): unknown {
  if (Array.isArray(value)) return value.slice(0, keep).map((v) => trimArrays(v, keep));
  if (typeof value === 'object' && value !== null) {
    return Object.fromEntries(Object.entries(value as Record<string, unknown>).map(([k, v]) => [k, trimArrays(v, keep)]));
  }
  return value;
}
