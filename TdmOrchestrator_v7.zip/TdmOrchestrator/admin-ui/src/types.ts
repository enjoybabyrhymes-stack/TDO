export interface ConfigItem {
  id: number;
  configKey: string;
  configValue: string;
  description?: string | null;
  isSecret: boolean;
  groupId?: number | null;
  groupName?: string | null;
  updatedAt: string;
}

export interface ScenarioSummary {
  projectName: string;
  environment: string;
  scenarioName: string;
  stepCount: number;
  activeStepCount: number;
  groupId?: number | null;
  groupName?: string | null;
  updatedAt: string;
}

export interface Step {
  serviceId: number;
  projectName: string;
  environment: string;
  scenarioName: string;
  stepOrder: number;
  stepDescription?: string | null;
  stepType: string;
  baseUrlConfigKey?: string | null;
  endpoint?: string | null;
  httpMethod?: string | null;
  inputParamMap?: string | null;
  outputParamMap?: string | null;
  retryCount: number;
  timeoutSeconds: number;
  waitTimeSeconds: number;
  pollIntervalSeconds: number;
  pollMaxWaitSeconds: number;
  groupId?: number | null;
  active: boolean;
  updatedAt: string;
}

export interface ValidationIssue {
  severity: 'error' | 'warning' | string;
  stepOrder?: number | null;
  message: string;
}

export interface PostmanExport {
  collection: { variable?: { value?: string }[]; [k: string]: unknown };
  sampleBody: unknown;
  requiredInputs: string[];
  runPath: string;
}

export interface RunItem {
  runId: number;
  projectName: string;
  environment: string;
  scenarioName: string;
  stepOrder: number;
  runGroupId?: string | null;
  requestUrl?: string | null;
  executionStartTime: string;
  executionEndTime?: string | null;
  status?: string | null;
  attemptCount: number;
  errorMessage?: string | null;
  executedBy?: string | null;
}

export interface RunFilters {
  project: string;
  environment: string;
  scenario: string;
  take: string;
}

export interface UserInfo {
  userId?: number | null;
  username: string;
  role: 'ADMIN' | 'USER' | string;
  groupId?: number | null;
  groupName?: string | null;
  viaAdminKey: boolean;
}

export interface LoginResult { token: string; expiresAt: string; user: UserInfo }

export interface Group {
  groupId: number;
  name: string;
  description?: string | null;
  userCount: number;
  scenarioCount: number;
  connectionCount: number;
  createdAt: string;
}

export interface AppUser {
  userId: number;
  username: string;
  role: 'ADMIN' | 'USER' | string;
  groupId?: number | null;
  groupName?: string | null;
  active: boolean;
  createdAt: string;
  lastLoginAt?: string | null;
}
