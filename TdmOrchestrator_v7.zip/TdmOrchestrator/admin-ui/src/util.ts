export const NAME_RE = /^[A-Za-z0-9_.\-]+$/;
export const NAME_HINT = 'letters, digits, “_”, “-” and “.”';

/** The API returns UTC timestamps without a zone suffix; treat those as UTC. */
export function fmtTime(iso?: string | null): string {
  if (!iso) return '';
  const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(iso) ? iso : iso + 'Z');
  return isNaN(d.getTime()) ? '' : d.toLocaleString();
}

export const scenarioPath = (p: string, e: string, s: string, tab?: string) =>
  `/scenario/${encodeURIComponent(p)}/${encodeURIComponent(e)}/${encodeURIComponent(s)}${tab && tab !== 'steps' ? '/' + tab : ''}`;

export const enc = encodeURIComponent;

export const errMessage = (err: unknown) => (err instanceof Error ? err.message : 'Something went wrong.');
