// Reads a Postman collection or an OpenAPI/Swagger document and turns each request into a step proposal.
import { parse as parseYaml } from 'yaml';
import { applyInputs, collectLeaves, suggestName } from './jsonFields';

export interface ImportedStep {
  key: string;
  name: string;
  method: string;
  /** Path (and query string) after the base URL, using {input.name} placeholders. */
  endpoint: string;
  /** Example request body as an object, or undefined when the call has none. */
  body?: unknown;
  notes: string[];
}

export interface ImportResult {
  kind: 'Postman collection' | 'OpenAPI' | 'Swagger 2';
  title: string;
  /** Scheme + host found in the file, shown as a hint when choosing the connection. */
  serverHint: string;
  steps: ImportedStep[];
}

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);
const str = (v: unknown) => (typeof v === 'string' ? v : '');
const METHODS = ['get', 'post', 'put', 'patch', 'delete'];

export function parseImport(text: string): ImportResult {
  let doc: unknown;
  try { doc = JSON.parse(text); }
  catch {
    try { doc = parseYaml(text); } catch { throw new Error('This is not valid JSON or YAML.'); }
  }
  if (!isObj(doc)) throw new Error('This does not look like a Postman collection or an OpenAPI/Swagger file.');
  if (Array.isArray(doc.item) && isObj(doc.info)) return fromPostman(doc);
  if (doc.openapi || doc.swagger) return fromOpenApi(doc);
  throw new Error('This does not look like a Postman collection or an OpenAPI/Swagger file.');
}

// ---- Postman ----------------------------------------------------------------------------------

/** {{name}} -> {input.name} (for URLs) */
const urlVars = (s: string) => s.replace(/\{\{\s*([A-Za-z_][\w.-]*)\s*\}\}/g, (_, n: string) => `{input.${n.replace(/[.-]/g, '_')}}`);
/** {{name}} -> $input.name (for JSON text) */
const bodyVars = (s: string) => s.replace(/\{\{\s*([A-Za-z_][\w.-]*)\s*\}\}/g, (_, n: string) => `$input.${n.replace(/[.-]/g, '_')}`);

function fromPostman(doc: Obj): ImportResult {
  const steps: ImportedStep[] = [];
  let serverHint = '';

  const walk = (items: unknown[], folder: string) => {
    for (const it of items) {
      if (!isObj(it)) continue;
      if (Array.isArray(it.item)) { walk(it.item, folder ? `${folder} / ${str(it.name)}` : str(it.name)); continue; }
      const req = it.request;
      if (!isObj(req)) continue;
      const notes: string[] = [];
      const method = (str(req.method) || 'GET').toUpperCase();

      let raw = '';
      let pathParts: string[] | null = null;
      let query: { key: string; value: string }[] = [];
      if (typeof req.url === 'string') raw = req.url;
      else if (isObj(req.url)) {
        raw = str(req.url.raw);
        if (Array.isArray(req.url.path)) pathParts = req.url.path.map((p) => (typeof p === 'string' ? p : str((p as Obj)?.value)));
        if (Array.isArray(req.url.query)) {
          query = req.url.query.filter((q): q is Obj => isObj(q) && !q.disabled).map((q) => ({ key: str(q.key), value: str(q.value) }));
        }
      }

      let path: string;
      if (pathParts) {
        path = '/' + pathParts.join('/');
        const host = raw.match(/^(https?:\/\/[^/{]+)/);
        if (host && !serverHint) serverHint = host[1];
      } else {
        const noQuery = raw.split('?')[0];
        const m = noQuery.match(/^(?:https?:\/\/[^/]+|\{\{[^}]+\}\})(\/.*)?$/);
        path = m ? m[1] ?? '/' : noQuery.startsWith('/') ? noQuery : '/' + noQuery;
        const host = noQuery.match(/^(https?:\/\/[^/]+)/);
        if (host && !serverHint) serverHint = host[1];
      }
      path = urlVars(path).replace(/\/:([A-Za-z_]\w*)/g, '/{input.$1}');
      const qs = query.filter((q) => q.key).map((q) => `${q.key}=${urlVars(q.value)}`).join('&');
      const endpoint = path + (qs ? '?' + qs : '');

      let body: unknown;
      if (isObj(req.body)) {
        const mode = str(req.body.mode);
        if (mode === 'raw') {
          const rawBody = str(req.body.raw).trim();
          if (rawBody) {
            try { body = JSON.parse(bodyVars(rawBody)); }
            catch { notes.push('The body is not JSON, so it was left out.'); }
          }
        } else if (mode) notes.push(`A “${mode}” body is not supported, so it was left out.`);
      }

      steps.push({
        key: `p${steps.length}`,
        name: [folder && `${folder}`, str(it.name)].filter(Boolean).join(' · ') || `${method} ${path}`,
        method, endpoint, body, notes
      });
    }
  };
  walk(doc.item as unknown[], '');
  const title = isObj(doc.info) ? str(doc.info.name) : '';
  return { kind: 'Postman collection', title, serverHint, steps };
}

// ---- OpenAPI / Swagger ---------------------------------------------------------------------------

function resolveRef(root: Obj, ref: string): unknown {
  if (!ref.startsWith('#/')) return undefined;
  return ref.slice(2).split('/').reduce<unknown>((cur, k) => (isObj(cur) ? cur[k.replace(/~1/g, '/').replace(/~0/g, '~')] : undefined), root);
}

/** A small example value for a schema (follows $ref, allOf, enums, examples; stops at depth 6). */
function sampleFor(schema: unknown, root: Obj, depth = 0, seen: string[] = []): unknown {
  if (!isObj(schema) || depth > 6) return undefined;
  if (typeof schema.$ref === 'string') {
    if (seen.includes(schema.$ref)) return undefined;
    return sampleFor(resolveRef(root, schema.$ref), root, depth + 1, [...seen, schema.$ref]);
  }
  if (schema.example !== undefined) return schema.example;
  if (schema.default !== undefined) return schema.default;
  if (Array.isArray(schema.enum) && schema.enum.length) return schema.enum[0];
  if (Array.isArray(schema.allOf)) {
    const out: Obj = {};
    for (const part of schema.allOf) { const s = sampleFor(part, root, depth + 1, seen); if (isObj(s)) Object.assign(out, s); }
    return out;
  }
  for (const k of ['oneOf', 'anyOf'] as const) {
    const list = schema[k];
    if (Array.isArray(list) && list.length) return sampleFor(list[0], root, depth + 1, seen);
  }
  const type = str(schema.type) || (isObj(schema.properties) ? 'object' : '');
  switch (type) {
    case 'object': {
      const out: Obj = {};
      const props = isObj(schema.properties) ? schema.properties : {};
      for (const k of Object.keys(props)) { const v = sampleFor(props[k], root, depth + 1, seen); if (v !== undefined) out[k] = v; }
      return out;
    }
    case 'array': { const v = sampleFor(schema.items, root, depth + 1, seen); return v === undefined ? [] : [v]; }
    case 'integer': case 'number': return 0;
    case 'boolean': return false;
    case 'string': return str(schema.format) === 'date-time' ? '2026-01-01T00:00:00Z' : str(schema.format) === 'date' ? '2026-01-01' : 'string';
    default: return undefined;
  }
}

function fromOpenApi(doc: Obj): ImportResult {
  const swagger2 = !!doc.swagger;
  const steps: ImportedStep[] = [];
  let serverHint = '';
  if (swagger2) {
    const host = str(doc.host);
    const scheme = Array.isArray(doc.schemes) && doc.schemes.length ? str(doc.schemes[0]) : 'https';
    if (host) serverHint = `${scheme}://${host}${str(doc.basePath).replace(/\/$/, '')}`;
  } else if (Array.isArray(doc.servers) && isObj(doc.servers[0])) serverHint = str(doc.servers[0].url);

  const paths = isObj(doc.paths) ? doc.paths : {};
  for (const path of Object.keys(paths)) {
    const item = paths[path];
    if (!isObj(item)) continue;
    const shared = Array.isArray(item.parameters) ? item.parameters : [];
    for (const method of METHODS) {
      const op = item[method];
      if (!isObj(op)) continue;
      const notes: string[] = [];
      const params = [...shared, ...(Array.isArray(op.parameters) ? op.parameters : [])]
        .map((p) => (isObj(p) && typeof p.$ref === 'string' ? resolveRef(doc, p.$ref) : p)).filter(isObj);

      let endpoint = path.replace(/\{([^}]+)\}/g, (_, n: string) => `{input.${n.replace(/[^\w]/g, '_')}}`);
      const required = params.filter((p) => str(p.in) === 'query' && p.required === true);
      if (required.length) endpoint += '?' + required.map((p) => `${str(p.name)}={input.${str(p.name).replace(/[^\w]/g, '_')}}`).join('&');
      if (params.some((p) => str(p.in) === 'query' && p.required !== true)) notes.push('Optional query parameters were left out.');

      let body: unknown;
      if (swagger2) {
        const bp = params.find((p) => str(p.in) === 'body');
        if (bp) body = sampleFor(bp.schema, doc);
      } else if (isObj(op.requestBody)) {
        const rb = typeof op.requestBody.$ref === 'string' ? resolveRef(doc, op.requestBody.$ref) : op.requestBody;
        const content = isObj(rb) && isObj(rb.content) ? rb.content : {};
        const json = Object.keys(content).find((k) => k.includes('json'));
        if (json && isObj(content[json])) {
          const media = content[json] as Obj;
          if (media.example !== undefined) body = media.example;
          else if (isObj(media.examples)) { const first = Object.values(media.examples)[0]; if (isObj(first)) body = first.value; }
          if (body === undefined) body = sampleFor(media.schema, doc);
        } else if (Object.keys(content).length) notes.push('This call sends something other than JSON, so the body was left out.');
      }

      steps.push({
        key: `o${steps.length}`,
        name: str(op.summary) || str(op.operationId) || `${method.toUpperCase()} ${path}`,
        method: method.toUpperCase(), endpoint, body, notes
      });
    }
  }
  const title = isObj(doc.info) ? str(doc.info.title) : '';
  return { kind: swagger2 ? 'Swagger 2' : 'OpenAPI', title, serverHint, steps };
}

// ---- Turning proposals into steps ------------------------------------------------------------------

/** Request template for a proposal. With `asInputs`, every body field the file did not already parameterise becomes $input.name. */
export function buildTemplate(step: ImportedStep, asInputs: boolean): string {
  if (step.body === undefined) return '';
  let body: unknown = step.body;
  if (asInputs) {
    const chosen = new Map<string, string>(); const taken = new Set<string>();
    for (const l of collectLeaves(body)) {
      if (typeof l.sample === 'string' && l.sample.includes('$input.')) continue;
      const name = suggestName(l.path, taken); taken.add(name); chosen.set(l.id, name);
    }
    body = applyInputs(body, chosen);
  }
  return JSON.stringify({ body }, null, 2);
}

/** Names the user will have to supply: placeholders in the endpoint and in the template. */
export function inputNames(step: ImportedStep, template: string): string[] {
  const found = new Set<string>();
  for (const m of step.endpoint.matchAll(/\{input\.([A-Za-z_]\w*)\}/g)) found.add(m[1]);
  for (const m of template.matchAll(/\$input\.([A-Za-z_]\w*)/g)) found.add(m[1]);
  return [...found];
}
