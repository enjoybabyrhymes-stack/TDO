// Turns a sample JSON document into a list of fields, and back into a request template in which the
// fields the end user fills in are replaced by "$input.name" placeholders.

export type Path = (string | number)[];
export interface LeafField { id: string; path: Path; sample: unknown }

type Json = unknown;
const isObj = (v: Json): v is Record<string, Json> => typeof v === 'object' && v !== null && !Array.isArray(v);

export function collectLeaves(value: Json, path: Path = [], out: LeafField[] = []): LeafField[] {
  if (Array.isArray(value)) value.forEach((v, i) => collectLeaves(v, [...path, i], out));
  else if (isObj(value)) Object.keys(value).forEach((k) => collectLeaves(value[k], [...path, k], out));
  else out.push({ id: pathId(path), path, sample: value });
  return out;
}

export const pathId = (path: Path) => JSON.stringify(path);

/** Human-readable path: customer.address.city, items[0].sku */
export function pathLabel(path: Path): string {
  return path.reduce<string>((acc, seg) => (typeof seg === 'number' ? `${acc}[${seg}]` : acc ? `${acc}.${seg}` : seg), '');
}

const camel = (s: string) => s.replace(/[^A-Za-z0-9]+(.)?/g, (_, c: string | undefined) => (c ? c.toUpperCase() : ''));
const clean = (s: string) => {
  const c = camel(s).replace(/^[^A-Za-z_]+/, '');
  return c ? c[0].toLowerCase() + c.slice(1) : '';
};

/** Valid placeholder name: letters, digits and underscore, not starting with a digit. */
export const INPUT_NAME_RE = /^[A-Za-z_][A-Za-z0-9_]*$/;

/** A friendly default input name for a field, unique among `taken`. */
export function suggestName(path: Path, taken: Set<string>): string {
  const keys = path.filter((s): s is string => typeof s === 'string');
  const last = keys[keys.length - 1] ?? 'value';
  const candidates = [clean(last)];
  if (keys.length > 1) candidates.push(clean(keys[keys.length - 2] + '_' + last));
  for (const c of candidates) if (c && !taken.has(c)) return c;
  const base = candidates[0] || 'value';
  for (let i = 2; ; i++) if (!taken.has(base + i)) return base + i;
}

/** Copy of `value` where each selected path is replaced by "$input.<name>". */
export function applyInputs(value: Json, selected: Map<string, string>, path: Path = []): Json {
  if (Array.isArray(value)) return value.map((v, i) => applyInputs(v, selected, [...path, i]));
  if (isObj(value)) {
    const out: Record<string, Json> = {};
    for (const k of Object.keys(value)) out[k] = applyInputs(value[k], selected, [...path, k]);
    return out;
  }
  const name = selected.get(pathId(path));
  return name ? `$input.${name}` : value;
}

/** What the end user sends in "inputData": every chosen name with its example value. */
export function sampleInput(leaves: LeafField[], selected: Map<string, string>): Record<string, Json> {
  const out: Record<string, Json> = {};
  for (const l of leaves) {
    const n = selected.get(l.id);
    if (n && !(n in out)) out[n] = l.sample;
  }
  return out;
}
