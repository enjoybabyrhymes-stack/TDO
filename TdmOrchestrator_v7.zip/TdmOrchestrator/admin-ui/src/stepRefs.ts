import type { Step } from './types';

/** Text of a step that may contain step references. API steps keep their ticked response fields in OutputParamMap, which has none. */
export const refText = (st: Step) => [st.endpoint ?? '', st.inputParamMap ?? '', st.stepType === 'RESTAPI' ? '' : st.outputParamMap ?? ''].join('\n');

/** Step numbers this step reads values from ($step2.id, {step2.id}, "step2.status"), without itself. */
export const stepsOf = (st: Step): number[] =>
  [...new Set([...refText(st).matchAll(/\bstep(\d+)(?=[.[])/g)].map((m) => Number(m[1])))]
    .filter((n) => n !== st.stepOrder).sort((a, b) => a - b);

/** The other steps that use a value from step number `order`. */
export const usersOfStep = (steps: Step[], order: number): Step[] =>
  steps.filter((x) => x.stepOrder !== order && stepsOf(x).includes(order));
