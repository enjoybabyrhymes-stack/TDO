import { useEffect } from 'react';
import { Navigate, NavLink, Route, Routes, useLocation } from 'react-router-dom';
import { useAuth } from './components/Auth';
import { Loading } from './components/Page';
import { Login } from './pages/Login';
import { Scenarios } from './pages/Scenarios';
import { ScenarioPage } from './pages/ScenarioPage';
import { Connections } from './pages/Connections';
import { Runs } from './pages/Runs';
import { Groups } from './pages/Groups';
import { Users } from './pages/Users';

export function App() {
  const { ready, user, isAdmin, signOut } = useAuth();
  const { pathname } = useLocation();

  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);

  if (!ready) return <div className="main"><Loading /></div>;
  if (!user) return <Login />;

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark">T</span><span>TDM Orchestrator</span></div>
        <nav className="nav">
          <NavLink to="/scenarios" className={({ isActive }) => (isActive || pathname.startsWith('/scenario/') ? 'active' : '')}>Scenarios</NavLink>
          <NavLink to="/connections">Connections</NavLink>
          <NavLink to="/runs">Run history</NavLink>
          {isAdmin && <NavLink to="/groups">Groups</NavLink>}
          {isAdmin && <NavLink to="/users">Users</NavLink>}
        </nav>
        <div className="sidebar-foot">
          <div className="sidebar-user">
            <div className="who">{user.viaAdminKey ? 'Admin key' : user.username}</div>
            <div className="where">{isAdmin ? 'Administrator' : `Group: ${user.groupName ?? '—'}`}</div>
          </div>
          <button className="btn btn-ghost" type="button" onClick={signOut}>Sign out</button>
        </div>
      </aside>
      <main className="main">
        <Routes>
          <Route path="/scenarios" element={<Scenarios />} />
          <Route path="/scenario/:project/:environment/:scenario/:tab?" element={<ScenarioPage />} />
          <Route path="/connections" element={<Connections />} />
          <Route path="/runs" element={<Runs />} />
          <Route path="/groups" element={isAdmin ? <Groups /> : <Navigate to="/scenarios" replace />} />
          <Route path="/users" element={isAdmin ? <Users /> : <Navigate to="/scenarios" replace />} />
          <Route path="*" element={<Navigate to="/scenarios" replace />} />
        </Routes>
      </main>
    </div>
  );
}
