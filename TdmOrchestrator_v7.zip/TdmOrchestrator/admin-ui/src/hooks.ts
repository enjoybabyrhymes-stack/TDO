import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from './api';
import type { Group } from './types';
import { useToast } from './components/Toasts';
import { errMessage } from './util';

/** Loads data on mount and whenever `deps` change; `reload()` fetches again. Ignores stale responses. */
export function useAsync<T>(fn: () => Promise<T>, deps: unknown[]) {
  const [state, setState] = useState<{ data?: T; error?: string; loading: boolean }>({ loading: true });
  const [tick, setTick] = useState(0);
  const fnRef = useRef(fn);
  fnRef.current = fn;

  useEffect(() => {
    let live = true;
    setState((s) => ({ data: s.data, loading: true }));
    fnRef.current().then(
      (data) => { if (live) setState({ data, loading: false }); },
      (err) => { if (live) setState({ error: errMessage(err), loading: false }); }
    );
    return () => { live = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, tick]);

  const reload = useCallback(() => setTick((t) => t + 1), []);
  return { ...state, reload };
}

/** Wraps an action so failures show as a red toast instead of an unhandled rejection. */
export function useGuard() {
  const toast = useToast();
  return useCallback(async <R,>(fn: () => Promise<R>): Promise<R | undefined> => {
    try { return await fn(); } catch (err) { toast(errMessage(err), true); return undefined; }
  }, [toast]);
}

/** Groups for the pickers (administrators get all groups; other users get their own). */
export function useGroups() {
  return useAsync(() => api<Group[]>('/groups'), []);
}

export interface NameCheck { state: 'idle' | 'checking' | 'free' | 'taken'; message?: string; visible?: boolean }

/** Asks the server, shortly after typing stops, whether project/environment/scenario is already used. */
export function useScenarioNameCheck(project: string, environment: string, scenario: string, skip = false): NameCheck {
  const [res, setRes] = useState<NameCheck>({ state: 'idle' });
  useEffect(() => {
    const [p, e, s] = [project, environment, scenario].map((v) => v.trim());
    if (skip || !p || !e || !s) { setRes({ state: 'idle' }); return; }
    setRes({ state: 'checking' });
    let live = true;
    const t = setTimeout(async () => {
      try {
        const q = new URLSearchParams({ project: p, environment: e, scenario: s });
        const r = await api<{ available: boolean; visible: boolean; message?: string }>(`/scenarios/check-name?${q}`);
        if (live) setRes(r.available ? { state: 'free' } : { state: 'taken', message: r.message, visible: r.visible });
      } catch { if (live) setRes({ state: 'idle' }); }
    }, 350);
    return () => { live = false; clearTimeout(t); };
  }, [project, environment, scenario, skip]);
  return res;
}
