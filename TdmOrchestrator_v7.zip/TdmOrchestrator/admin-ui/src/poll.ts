// Helpers that move the polling form <-> the "poll" block stored inside a step's request template (InputParamMap).
//
//   { "body": {...}, "headers": {...},
//     "poll": { "condition": { "field": "step1.status", "equals": "approved" }, "body": {...} } }
//
// Timing (check every N seconds, give up after N seconds) is NOT in the template: it has its own columns.

import type { Step } from './types';

export const POLL_OPS = [
  { key: 'equals', label: 'equals', numeric: false },
  { key: 'notEquals', label: 'does not equal', numeric: false },
  { key: 'contains', label: 'contains', numeric: false },
  { key: 'greaterThan', label: 'is greater than', numeric: true },
  { key: 'greaterThanOrEqual', label: 'is at least', numeric: true },
  { key: 'lessThan', label: 'is less than', numeric: true },
  { key: 'lessThanOrEqual', label: 'is at most', numeric: true }
] as const;

type Obj = Record<string, unknown>;
const isObj = (v: unknown): v is Obj => typeof v === 'object' && v !== null && !Array.isArray(v);
const pretty = (v: unknown) => JSON.stringify(v, null, 2);

export interface PollFormState {
  on: boolean;
  field: string;
  op: string;
  value: string;
  /** Set when the stored condition is not a simple "field + one operator"; then it is edited as raw JSON. */
  advanced: string | null;
  recheckBody: string;
  /** Other keys of the poll block (for example "headers") are kept untouched. */
  extras: Obj;
  intervalSeconds: string;
  giveUpMinutes: string;
  migratedFromLegacy: boolean;
}

export const emptyPollForm = (): PollFormState => ({
  on: false, field: '', op: 'equals', value: '', advanced: null, recheckBody: '', extras: {},
  intervalSeconds: '60', giveUpMinutes: '30', migratedFromLegacy: false
});

/** Split a stored request template into the part shown in the template box and the poll form. */
export function parseTemplate(raw: string | null | undefined, step: Step | null): { template: string; poll: PollFormState } {
  const poll = emptyPollForm();
  const text = (raw ?? '').trim();
  if (!text) return { template: '', poll };

  let parsed: unknown;
  try { parsed = JSON.parse(text); } catch { return { template: raw ?? '', poll }; }
  if (!isObj(parsed) || !isObj(parsed.poll)) return { template: raw ?? '', poll };

  const { poll: block, ...rest } = parsed as Obj & { poll: Obj };
  poll.on = true;

  const { condition, body, ...extras } = block;
  poll.extras = extras;
  if (body !== undefined) poll.recheckBody = pretty(body);

  if (isObj(condition)) {
    const ops = Object.keys(condition).filter((k) => k !== 'field');
    const known = POLL_OPS.find((o) => o.key === ops[0]);
    if (typeof condition.field === 'string' && ops.length === 1 && known) {
      poll.field = condition.field;
      poll.op = known.key;
      poll.value = String(condition[known.key] ?? '');
    } else {
      poll.advanced = pretty(condition);
    }
  }

  if (step) {
    if (step.pollIntervalSeconds > 0) {
      poll.intervalSeconds = String(step.pollIntervalSeconds);
      poll.giveUpMinutes = String(Math.round((step.pollMaxWaitSeconds / 60) * 100) / 100);
    } else {
      // Saved with the old convention: Retries = extra checks, Wait = seconds between checks.
      const interval = step.waitTimeSeconds > 0 ? step.waitTimeSeconds : 30;
      poll.intervalSeconds = String(interval);
      poll.giveUpMinutes = String(Math.max(1, Math.ceil((step.retryCount * interval) / 60)));
      poll.migratedFromLegacy = true;
    }
  }

  return { template: Object.keys(rest).length ? pretty(rest) : '', poll };
}

export function conditionFromForm(p: PollFormState): { condition?: Obj; error?: string } {
  if (p.advanced !== null) {
    try {
      const c = JSON.parse(p.advanced);
      if (!isObj(c) || typeof c.field !== 'string' || !c.field) return { error: 'The condition JSON needs a "field".' };
      return { condition: c };
    } catch { return { error: 'The condition is not valid JSON.' }; }
  }
  const field = p.field.trim();
  if (!field) return { error: 'Enter the response field to watch, for example step1.status.' };
  if (p.value.trim() === '') return { error: 'Enter the value to wait for.' };
  const op = POLL_OPS.find((o) => o.key === p.op)!;
  if (op.numeric) {
    const n = Number(p.value);
    if (!isFinite(n)) return { error: `“${op.label}” needs a number.` };
    return { condition: { field, [op.key]: n } };
  }
  return { condition: { field, [op.key]: p.value.trim() } };
}

/** Build the request template to save: the user's template plus the poll block. */
export function composeTemplate(template: string, p: PollFormState): { json?: string; error?: string } {
  const t = template.trim();
  const { condition, error } = conditionFromForm(p);
  if (!condition) return { error };

  const block: Obj = { condition };
  if (p.recheckBody.trim()) {
    try { block.body = JSON.parse(p.recheckBody); } catch { return { error: 'The re-check request body is not valid JSON.' }; }
  }
  Object.assign(block, p.extras);

  let obj: Obj;
  if (!t) {
    // The engine treats an object without "body"/"headers" as the body itself, so a header keeps "poll" out of the request.
    obj = { headers: { Accept: 'application/json' } };
  } else {
    let parsed: unknown;
    try { parsed = JSON.parse(t); } catch { return { error: 'The request template is not valid JSON.' }; }
    obj = isObj(parsed) && ('body' in parsed || 'headers' in parsed) ? { ...parsed } : { body: parsed };
  }
  obj.poll = block;
  return { json: pretty(obj) };
}

export function fmtDuration(totalSeconds: number): string {
  if (totalSeconds < 120) return `${totalSeconds}s`;
  const m = totalSeconds / 60;
  if (m < 120) return `${Math.round(m * 10) / 10} min`;
  return `${Math.round((m / 60) * 10) / 10} h`;
}

/** One-line description of a step's polling for the steps list, or null when it does not poll. */
export function pollSummary(st: Step): string | null {
  if (!st.inputParamMap || !st.inputParamMap.includes('"poll"')) return null;
  if (st.pollIntervalSeconds > 0) {
    return `polls every ${fmtDuration(st.pollIntervalSeconds)}, gives up after ${fmtDuration(st.pollMaxWaitSeconds)}`;
  }
  const interval = st.waitTimeSeconds > 0 ? st.waitTimeSeconds : 30;
  return `polls every ${fmtDuration(interval)}, up to ${st.retryCount} more time(s) (old settings — edit to update)`;
}
