import { useState, type FormEvent } from 'react';
import { useAuth } from '../components/Auth';
import { errMessage } from '../util';

export function Login() {
  const { signInWithPassword, signInWithKey } = useAuth();
  const [useKey, setUseKey] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [key, setKey] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      if (useKey) await signInWithKey(key.trim());
      else await signInWithPassword(username.trim(), password);
    } catch (ex) { setError(errMessage(ex)); setBusy(false); }
  }

  return (
    <div className="login">
      <form className="login-card" onSubmit={submit}>
        <div className="brand"><span className="brand-mark">T</span><span>TDM Orchestrator</span></div>
        <h1>Sign in</h1>
        {useKey ? (
          <>
            <p className="muted">Enter the administrator key from the server configuration.</p>
            <label htmlFor="adminKey">Admin key</label>
            <input id="adminKey" type="password" autoComplete="off" required autoFocus value={key} onChange={(e) => setKey(e.target.value)} />
          </>
        ) : (
          <>
            <p className="muted">Use the user name and password an administrator gave you.</p>
            <label htmlFor="username">User name</label>
            <input id="username" autoComplete="username" required autoFocus value={username} onChange={(e) => setUsername(e.target.value)} />
            <label htmlFor="password">Password</label>
            <input id="password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} />
          </>
        )}
        <p className="error" role="alert">{error}</p>
        <button className="btn btn-primary" type="submit" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
        <p className="small" style={{ marginTop: 14 }}>
          <button type="button" className="link" onClick={() => { setUseKey(!useKey); setError(''); }}>
            {useKey ? 'Sign in with a user name instead' : 'Administrator? Sign in with the admin key'}
          </button>
        </p>
      </form>
    </div>
  );
}
