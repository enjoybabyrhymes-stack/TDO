import { useState } from 'react';
import { api } from '../api';
import { useAsync, useGuard } from '../hooks';
import type { Group } from '../types';
import { enc, errMessage, fmtTime } from '../util';
import { useConfirm } from '../components/Confirm';
import { Modal } from '../components/Modal';
import { ErrorCard, Loading, PageHead } from '../components/Page';
import { useToast } from '../components/Toasts';

export function Groups() {
  const { data, error, loading, reload } = useAsync(() => api<Group[]>('/groups'), []);
  const [editing, setEditing] = useState<Group | 'new' | null>(null);
  const confirm = useConfirm();
  const guard = useGuard();
  const toast = useToast();

  const remove = async (g: Group) => {
    if (!(await confirm(`Delete the group “${g.name}”?`))) return;
    await guard(async () => { await api(`/groups/${enc(String(g.groupId))}`, { method: 'DELETE' }); toast('Group deleted.'); reload(); });
  };

  return (
    <>
      <PageHead title="Groups"
        subtitle="A group is a team. Its users see and manage only the scenarios, connections and run history that belong to the group."
        actions={<button className="btn btn-primary" type="button" onClick={() => setEditing('new')}>Add group</button>} />
      {error && <ErrorCard message={error} onRetry={reload} />}
      {!error && !data && loading && <Loading />}
      {data && (
        <div className="card table-wrap">
          <table>
            <thead><tr><th>Group</th><th>Description</th><th>Users</th><th>Scenarios</th><th>Connections</th><th>Created</th><th></th></tr></thead>
            <tbody>
              {data.length === 0 && <tr><td colSpan={7}><div className="empty">No groups yet. Add a group, then add users to it.</div></td></tr>}
              {data.map((g) => (
                <tr key={g.groupId}>
                  <td><strong>{g.name}</strong></td>
                  <td className="muted">{g.description || ''}</td>
                  <td>{g.userCount}</td><td>{g.scenarioCount}</td><td>{g.connectionCount}</td>
                  <td className="muted nowrap">{fmtTime(g.createdAt)}</td>
                  <td className="right nowrap">
                    <button className="btn btn-sm" type="button" onClick={() => setEditing(g)}>Edit</button>{' '}
                    <button className="btn btn-sm btn-danger" type="button" onClick={() => remove(g)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {editing && <GroupDialog item={editing === 'new' ? null : editing} onClose={() => setEditing(null)} onSaved={reload} />}
    </>
  );
}

function GroupDialog({ item, onClose, onSaved }: { item: Group | null; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [name, setName] = useState(item?.name ?? '');
  const [desc, setDesc] = useState(item?.description ?? '');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const save = async () => {
    setBusy(true); setErr('');
    try {
      await api(item ? `/groups/${item.groupId}` : '/groups', { method: item ? 'PUT' : 'POST', body: { name: name.trim(), description: desc.trim() } });
      onClose(); toast('Group saved.'); onSaved();
    } catch (ex) { setErr(errMessage(ex)); setBusy(false); }
  };

  return (
    <Modal title={item ? 'Edit group' : 'Add group'} narrow onClose={onClose}
      footer={<>
        <button className="btn" type="button" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary" type="button" onClick={save} disabled={busy}>Save</button>
      </>}>
      <label htmlFor="gName">Name</label>
      <input id="gName" value={name} placeholder="Claims team" onChange={(e) => setName(e.target.value)}
        onKeyDown={(e) => { if (e.key === 'Enter') save(); }} />
      <label htmlFor="gDesc">Description <span className="hint">(optional)</span></label>
      <input id="gDesc" value={desc} onChange={(e) => setDesc(e.target.value)} />
      <p className="error">{err}</p>
    </Modal>
  );
}
