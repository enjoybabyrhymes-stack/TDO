import { useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { api } from '../api';
import { useAsync, useGroups, useGuard, useScenarioNameCheck } from '../hooks';
import { NameStatus } from '../components/NameStatus';
import { useAuth } from '../components/Auth';
import { GroupSelect } from '../components/GroupSelect';
import type { ConfigItem, Step } from '../types';
import { enc, NAME_HINT, NAME_RE, scenarioPath } from '../util';
import { Chip } from '../components/Chip';
import { useConfirm } from '../components/Confirm';
import { Modal } from '../components/Modal';
import { ErrorCard, Loading, PageHead } from '../components/Page';
import { useToast } from '../components/Toasts';
import { StepsTab } from './StepsTab';
import { FlowTab } from './FlowTab';
import { PostmanTab } from './PostmanTab';
import { ValidateTab } from './ValidateTab';

const TABS = [['steps', 'Steps'], ['flow', 'Flow'], ['postman', 'Use in Postman'], ['validate', 'Check']] as const;

export function ScenarioPage() {
  const { project: p = '', environment: e = '', scenario: s = '', tab = 'steps' } = useParams();
  const nav = useNavigate();
  const guard = useGuard();
  const toast = useToast();
  const confirm = useConfirm();
  const [cloning, setCloning] = useState(false);
  const [moving, setMoving] = useState(false);
  const { isAdmin } = useAuth();
  const [qs] = useSearchParams();
  const { data: groupList } = useGroups();

  const base = `/scenarios/${enc(p)}/${enc(e)}/${enc(s)}`;
  const { data, error, loading, reload } = useAsync(
    () => Promise.all([api<Step[]>(`${base}/steps`), api<ConfigItem[]>('/configs')]),
    [p, e, s]);

  if (error) return <ErrorCard message={error} onRetry={reload} />;
  if (!data) return loading ? <Loading /> : null;

  const [steps, allConfigs] = data;
  // The scenario's group: taken from its steps, or from the group chosen when the scenario was started.
  const groupId: number | undefined = steps.length ? steps[0].groupId ?? undefined : (Number(qs.get('group')) || undefined);
  const groupName = groupId ? groupList?.find((g) => g.groupId === groupId)?.name : undefined;
  // Administrators see every group's connections, so narrow them to this scenario's group.
  const configs = isAdmin ? allConfigs.filter((c) => (c.groupId ?? undefined) === groupId) : allConfigs;
  const activeCount = steps.filter((x) => x.active).length;

  const toggle = () => guard(async () => {
    await api(`${base}/active`, { method: 'POST', body: { active: activeCount === 0 } });
    toast(activeCount ? 'Scenario disabled.' : 'Scenario enabled.');
    reload();
  });

  const remove = async () => {
    if (!(await confirm(`Delete scenario “${s}” and all ${steps.length} of its steps? This cannot be undone.`))) return;
    await guard(async () => {
      await api(base, { method: 'DELETE' });
      toast('Scenario deleted.');
      nav('/scenarios');
    });
  };

  const current = TABS.some(([k]) => k === tab) ? tab : 'steps';

  return (
    <>
      <PageHead
        crumbs={<><Link to="/scenarios">Scenarios</Link> / {p} / {e}</>}
        title={<>{s}{' '}
          {isAdmin && steps.length > 0 && (groupId ? (groupName ? <Chip kind="blue">{groupName}</Chip> : null) : <Chip kind="warn">Unassigned</Chip>)}{' '}
          {!steps.length ? <Chip>No steps yet</Chip> : activeCount === 0 ? <Chip kind="warn">Disabled</Chip> : <Chip kind="ok">Active</Chip>}</>}
        actions={steps.length > 0 && <>
          {isAdmin && <button className="btn" type="button" onClick={() => setMoving(true)}>Change group…</button>}
          <button className="btn" type="button" onClick={() => setCloning(true)}>Clone…</button>
          <button className="btn" type="button" onClick={toggle}>{activeCount ? 'Disable' : 'Enable'}</button>
          <button className="btn btn-danger" type="button" onClick={remove}>Delete</button>
        </>} />

      {isAdmin && steps.length > 0 && !groupId && (
        <div className="card notice">This scenario is not assigned to a group, so only administrators can see it. Use “Change group…” to give a team access. Its steps use connections of the same group.</div>
      )}

      <div className="tabs" role="tablist">
        {TABS.map(([k, label]) => (
          <button key={k} type="button" role="tab" aria-selected={k === current} className={'tab' + (k === current ? ' active' : '')}
            onClick={() => nav(scenarioPath(p, e, s, k))}>{label}</button>
        ))}
      </div>

      {current === 'steps' && <StepsTab p={p} e={e} s={s} steps={steps} configs={configs} groupId={groupId} reload={reload} />}
      {current === 'flow' && <FlowTab steps={steps} />}
      {current === 'postman' && <PostmanTab p={p} e={e} s={s} steps={steps} />}
      {current === 'validate' && <ValidateTab p={p} e={e} s={s} steps={steps} />}

      {cloning && <CloneDialog p={p} e={e} s={s} groupId={groupId} onClose={() => setCloning(false)} />}
      {moving && <MoveDialog base={base} current={groupId} onClose={() => setMoving(false)} onSaved={reload} />}
    </>
  );
}

function MoveDialog({ base, current, onClose, onSaved }: { base: string; current?: number; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const { data: groups } = useGroups();
  const [gid, setGid] = useState(current ? String(current) : '');
  const [err, setErr] = useState('');

  const save = async () => {
    try {
      await api(`${base}/group`, { method: 'POST', body: { groupId: gid ? Number(gid) : null } });
      onClose(); toast('Group changed.'); onSaved();
    } catch (ex) { setErr(ex instanceof Error ? ex.message : 'Could not change the group.'); }
  };

  return (
    <Modal title="Change group" narrow onClose={onClose}
      footer={<>
        <button className="btn" type="button" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary" type="button" onClick={save}>Save</button>
      </>}>
      <p className="muted small">Only users of this group (and administrators) can see the scenario. Its steps look up connections in the new group, so create the same connection names there first.</p>
      <label htmlFor="mvG">Group</label>
      <GroupSelect id="mvG" groups={groups ?? []} value={gid} onChange={setGid} emptyLabel="Not assigned (administrators only)" />
      <p className="error">{err}</p>
    </Modal>
  );
}

function CloneDialog({ p, e, s, groupId, onClose }: { p: string; e: string; s: string; groupId?: number; onClose: () => void }) {
  const nav = useNavigate();
  const { isAdmin } = useAuth();
  const { data: groups } = useGroups();
  const [tg, setTg] = useState(groupId ? String(groupId) : '');
  const toast = useToast();
  const [tp, setTp] = useState(p);
  const [te, setTe] = useState(e);
  const [ts, setTs] = useState(s);
  const check = useScenarioNameCheck(tp, te, ts);
  const [err, setErr] = useState('');

  const go = async () => {
    const t = [tp, te, ts].map((v) => v.trim());
    if (!t.every((v) => v && NAME_RE.test(v))) { setErr(`Use ${NAME_HINT} only.`); return; }
    if (check.state === 'taken') { setErr(check.message ?? 'That scenario name is already in use.'); return; }
    try {
      await api('/scenarios/clone', {
        method: 'POST',
        body: { projectName: p, environment: e, scenarioName: s, targetProjectName: t[0], targetEnvironment: t[1], targetScenarioName: t[2], targetGroupId: isAdmin && tg ? Number(tg) : undefined }
      });
      onClose(); toast('Scenario cloned.'); nav(scenarioPath(t[0], t[1], t[2]));
    } catch (ex) { setErr(ex instanceof Error ? ex.message : 'Clone failed.'); }
  };

  return (
    <Modal title="Clone scenario" narrow onClose={onClose}
      footer={<>
        <button className="btn" type="button" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary" type="button" onClick={go}>Clone</button>
      </>}>
      <p className="muted small">Copies every step. Use it to promote a scenario to another environment.</p>
      {isAdmin && (
        <>
          <label htmlFor="cG">Group</label>
          <GroupSelect id="cG" groups={groups ?? []} value={tg} onChange={setTg} emptyLabel="Same as the original" />
        </>
      )}
      <label htmlFor="cP">Project</label><input id="cP" value={tp} onChange={(x) => setTp(x.target.value)} />
      <label htmlFor="cE">Environment</label><input id="cE" value={te} onChange={(x) => setTe(x.target.value)} />
      <label htmlFor="cS">Scenario</label><input id="cS" value={ts} onChange={(x) => setTs(x.target.value)} />
      <NameStatus check={check} />
      <p className="error">{err}</p>
    </Modal>
  );
}
