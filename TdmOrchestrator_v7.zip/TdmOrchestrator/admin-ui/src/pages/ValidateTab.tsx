import { api } from '../api';
import { useAsync } from '../hooks';
import type { Step, ValidationIssue } from '../types';
import { enc } from '../util';
import { Chip } from '../components/Chip';
import { ErrorCard, Loading } from '../components/Page';

interface Props { p: string; e: string; s: string; steps: Step[] }

export function ValidateTab({ p, e, s, steps }: Props) {
  const { data: issues, error, loading, reload } = useAsync(
    () => steps.length ? api<ValidationIssue[]>(`/scenarios/${enc(p)}/${enc(e)}/${enc(s)}/validate`) : Promise.resolve([]),
    [p, e, s, steps]);

  if (!steps.length) return <div className="card empty">Add steps first, then check the scenario.</div>;
  if (error) return <ErrorCard message={error} onRetry={reload} />;
  if (!issues) return loading ? <Loading /> : null;

  if (!issues.length) return <div className="banner ok">No problems found. The scenario is ready to run from Postman.</div>;

  const errors = issues.filter((i) => i.severity === 'error').length;
  return (
    <>
      <div className={'banner ' + (errors ? 'warn' : 'ok')}>
        {errors} error(s), {issues.length - errors} warning(s). Fix errors before running the scenario.
      </div>
      <div className="card">
        {issues.map((i, n) => (
          <div className="issue" key={n}>
            <Chip kind={i.severity === 'error' ? 'bad' : 'warn'}>{i.severity}</Chip>
            <div>{i.stepOrder ? <strong>Step {i.stepOrder}: </strong> : null}{i.message}</div>
          </div>
        ))}
      </div>
    </>
  );
}
