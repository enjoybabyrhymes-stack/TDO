import { api } from '../api';
import { useAsync } from '../hooks';
import type { PostmanExport, Step } from '../types';
import { enc } from '../util';
import { Chip } from '../components/Chip';
import { ErrorCard, Loading } from '../components/Page';
import { useToast } from '../components/Toasts';

interface Props { p: string; e: string; s: string; steps: Step[] }

export function PostmanTab({ p, e, s, steps }: Props) {
  const hasActive = steps.some((x) => x.active);
  const { data: x, error, loading, reload } = useAsync(
    () => hasActive ? api<PostmanExport>(`/scenarios/${enc(p)}/${enc(e)}/${enc(s)}/postman`) : Promise.resolve(null),
    [p, e, s, steps]);
  const toast = useToast();

  if (!hasActive) return <div className="card empty">Enable the scenario and add at least one active step to get the Postman request.</div>;
  if (error) return <ErrorCard message={error} onRetry={reload} />;
  if (!x) return loading ? <Loading /> : null;

  const url = location.origin + x.runPath;
  const body = JSON.stringify(x.sampleBody, null, 2);

  const copy = (text: string) =>
    navigator.clipboard.writeText(text).then(() => toast('Copied.'), () => toast('Copy failed. Select the text and copy it manually.', true));

  const download = () => {
    const coll = x.collection;
    if (coll.variable && coll.variable[0]) coll.variable[0].value = location.origin;
    const blob = new Blob([JSON.stringify(coll, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${p}_${e}_${s}.postman_collection.json`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  };

  return (
    <div className="card card-pad">
      <h2>Request</h2>
      <p><span className="method">POST</span> <code>{url}</code>{' '}
        <button className="btn btn-sm" type="button" onClick={() => copy(url)}>Copy URL</button></p>
      <h3 style={{ marginTop: 14 }}>Headers</h3>
      <pre>{'X-Api-Key: <your run key>\nContent-Type: application/json'}</pre>
      <h3 style={{ marginTop: 14 }}>Body{' '}
        <button className="btn btn-sm" type="button" onClick={() => copy(body)}>Copy body</button></h3>
      <pre>{body}</pre>
      <h3 style={{ marginTop: 14 }}>Values to fill in under <code>inputData</code></h3>
      <p>
        {x.requiredInputs.length
          ? x.requiredInputs.map((n) => <span key={n}><Chip kind="blue">{n}</Chip>{' '}</span>)
          : <span className="muted">This scenario does not read any request input.</span>}
      </p>
      <p className="muted small">The list is read from the steps ($input.name and {'{input.name}'}). Values can be strings, numbers, true/false, lists or objects, as the step expects.</p>
      <div className="actions" style={{ marginTop: 12 }}>
        <button className="btn btn-primary" type="button" onClick={download}>Download Postman collection</button>
      </div>
    </div>
  );
}
