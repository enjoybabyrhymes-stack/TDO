import { useRef, useState } from 'react';
import { api } from '../api';
import type { ConfigItem, Step } from '../types';
import { errMessage } from '../util';
import { composeTemplate, parseTemplate, POLL_OPS, type PollFormState } from '../poll';
import { JsonConverter } from '../components/JsonConverter';
import { ResponseFields } from '../components/ResponseFields';
import { parseFields, serializeFields, stepToken, type OutField } from '../outputFields';
import { Modal } from '../components/Modal';
import { useToast } from '../components/Toasts';

type FieldKey = 'endpoint' | 'inputParamMap' | 'outputParamMap';
type Field = HTMLInputElement | HTMLTextAreaElement;
const METHODS = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'];

const WHEN_SNIPPET = '{\n  "$when": { "field": "input.state", "equals": "FL" },\n  "$then": { "code": "Q1", "answer": "No" }\n}';

function jsonStatus(v: string): { ok: boolean; text: string } {
  const t = v.trim();
  if (!t) return { ok: true, text: 'Optional' };
  try { JSON.parse(t); return { ok: true, text: 'Valid JSON' }; }
  catch (err) { return { ok: false, text: 'Not valid JSON: ' + errMessage(err) }; }
}

function JsonStatus({ value }: { value: string }) {
  const st = jsonStatus(value);
  const cls = !value.trim() ? '' : st.ok ? ' ok' : ' bad';
  return <div className={'json-status' + cls}>{st.text}</div>;
}

interface Props {
  p: string; e: string; s: string;
  step: Step | null; steps: Step[]; configs: ConfigItem[]; groupId?: number;
  onClose: () => void; onSaved: () => void;
}

export function StepEditor({ p, e, s, step, steps, configs, groupId, onClose, onSaved }: Props) {
  const toast = useToast();
  const isNew = !step;

  const [order, setOrder] = useState(String(step?.stepOrder ?? (steps.length ? Math.max(...steps.map((x) => x.stepOrder)) + 1 : 1)));
  const [type, setType] = useState(step?.stepType ?? 'RESTAPI');
  const [active, setActive] = useState(step?.active ?? true);
  const [desc, setDesc] = useState(step?.stepDescription ?? '');
  const [base, setBase] = useState(step?.baseUrlConfigKey ?? '');
  const [method, setMethod] = useState(step?.httpMethod ?? 'POST');
  const [endpoint, setEndpoint] = useState(step?.endpoint ?? '');
  const parsed = useRef(parseTemplate(step?.inputParamMap, step)).current;
  const [input, setInput] = useState(parsed.template);
  const [poll, setPoll] = useState<PollFormState>(parsed.poll);
  const setP = (patch: Partial<PollFormState>) => setPoll((cur) => ({ ...cur, ...patch }));
  // API steps keep the ticked response fields in OutputParamMap; only consolidate steps have an output template.
  const [output, setOutput] = useState(step?.stepType === 'RESTAPI' ? '' : step?.outputParamMap ?? '');
  const [fields, setFields] = useState<OutField[]>(() => (step?.stepType === 'RESTAPI' ? parseFields(step.outputParamMap) : []));
  // A step moved over from the old polling convention starts with Retries/Wait cleared: they now mean "per call" settings.
  const [retry, setRetry] = useState(String(parsed.poll.migratedFromLegacy ? 0 : step?.retryCount ?? 0));
  const [timeout, setTimeoutS] = useState(String(step?.timeoutSeconds ?? 30));
  const [wait, setWait] = useState(String(parsed.poll.migratedFromLegacy ? 0 : step?.waitTimeSeconds ?? 0));
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  type Tab = 'basics' | 'request' | 'response' | 'timing' | 'output';
  const [tab, setTab] = useState<Tab>('basics');
  const [converting, setConverting] = useState(false);

  const rest = type === 'RESTAPI';
  const refs = { endpoint: useRef<HTMLInputElement>(null), inputParamMap: useRef<HTMLTextAreaElement>(null), outputParamMap: useRef<HTMLTextAreaElement>(null) };
  const setters: Record<FieldKey, (v: string) => void> = { endpoint: setEndpoint, inputParamMap: setInput, outputParamMap: setOutput };
  const lastField = useRef<FieldKey>('inputParamMap');
  const track = (k: FieldKey) => () => { lastField.current = k; };

  // Insert a snippet at the caret of the field the user last clicked into.
  const insert = (kind: 'input' | 'step' | 'now' | 'when') => {
    // REST steps have an endpoint and a request template; consolidate steps only have an output template.
    const key: FieldKey = !rest ? 'outputParamMap' : lastField.current === 'endpoint' ? 'endpoint' : 'inputParamMap';
    const inEndpoint = key === 'endpoint';
    if (inEndpoint && (kind === 'now' || kind === 'when')) { toast('That value works in templates, not in the endpoint.', true); return; }
    const snippet = {
      input: inEndpoint ? '{input.fieldName}' : '$input.fieldName',
      step: inEndpoint ? '{step1.fieldName}' : '$step1.fieldName',
      now: '$now',
      when: WHEN_SNIPPET
    }[kind];
    const el = refs[key].current as Field | null;
    if (!el) return;
    const a = el.selectionStart ?? el.value.length;
    const b = el.selectionEnd ?? el.value.length;
    setters[key](el.value.slice(0, a) + snippet + el.value.slice(b));
    requestAnimationFrame(() => { el.focus(); el.selectionStart = el.selectionEnd = a + snippet.length; });
  };

  // Response fields ticked on earlier API steps, offered as ready-made values.
  const myOrder = parseInt(order, 10) || 0;
  const orderTaken = myOrder > 0 && steps.some((x) => x.stepOrder === myOrder && (isNew || x.serviceId !== step!.serviceId));
  const earlier = steps
    .filter((x) => x.stepType === 'RESTAPI' && x.stepOrder < myOrder && (isNew || x.serviceId !== step!.serviceId))
    .sort((a, b) => a.stepOrder - b.stepOrder)
    .map((x) => ({ st: x, fields: parseFields(x.outputParamMap) }))
    .filter((x) => x.fields.length > 0);

  const insertStepField = (value: string) => {
    if (!value) return;
    const [orderText, ...rest2] = value.split('|');
    const key: FieldKey = !rest ? 'outputParamMap' : lastField.current === 'endpoint' ? 'endpoint' : 'inputParamMap';
    const snippet = stepToken(Number(orderText), rest2.join('|'), key === 'endpoint');
    const el = refs[key].current as Field | null;
    if (!el) return;
    const a = el.selectionStart ?? el.value.length;
    const b = el.selectionEnd ?? el.value.length;
    setters[key](el.value.slice(0, a) + snippet + el.value.slice(b));
    requestAnimationFrame(() => { el.focus(); el.selectionStart = el.selectionEnd = a + snippet.length; });
  };

  const intervalN = Math.round(Number(poll.intervalSeconds));
  const giveUpSeconds = Math.round(Number(poll.giveUpMinutes) * 60);
  const checks = intervalN >= 1 && giveUpSeconds >= intervalN ? Math.floor(giveUpSeconds / intervalN) + 1 : 0;

  const save = async () => {
    setErr('');
    if (orderTaken) { setTab('basics'); setErr(`This scenario already has a step ${myOrder}. Choose a number that is not used.`); return; }
    if (!jsonStatus(input).ok) { setTab('request'); setErr('Fix the JSON errors before saving.'); return; }
    if (!jsonStatus(output).ok) { setTab('output'); setErr('Fix the JSON errors before saving.'); return; }

    let inputParamMap = input.trim();
    const polling = rest && poll.on;
    if (polling) {
      if (!(intervalN >= 1)) { setTab('timing'); setErr('Enter how often to check, in seconds (1 or more).'); return; }
      if (!(giveUpSeconds >= intervalN)) { setTab('timing'); setErr('The give-up time must be at least one check interval.'); return; }
      const composed = composeTemplate(input, poll);
      if (!composed.json) { setTab('timing'); setErr(composed.error || 'Check the polling settings.'); return; }
      inputParamMap = composed.json;
    }

    const dto = {
      projectName: p, environment: e, scenarioName: s,
      groupId: groupId ?? null,
      stepOrder: parseInt(order, 10) || 0,
      stepType: type,
      stepDescription: desc.trim(),
      baseUrlConfigKey: rest ? base : '',
      httpMethod: rest ? method : null,
      endpoint: rest ? endpoint.trim() : null,
      inputParamMap: rest ? inputParamMap : '',
      outputParamMap: rest ? serializeFields(fields) : output.trim(),
      retryCount: rest && !polling ? parseInt(retry, 10) || 0 : 0,
      timeoutSeconds: rest ? parseInt(timeout, 10) || 30 : 30,
      waitTimeSeconds: rest ? parseInt(wait, 10) || 0 : 0,
      pollIntervalSeconds: polling ? intervalN : 0,
      pollMaxWaitSeconds: polling ? giveUpSeconds : 0,
      active
    };
    setBusy(true);
    try {
      await api(isNew ? '/steps' : `/steps/${step!.serviceId}`, { method: isNew ? 'POST' : 'PUT', body: dto });
      onClose(); toast('Step saved.'); onSaved();
    } catch (ex) { setErr(errMessage(ex)); setBusy(false); }
  };

  const tabs: [Tab, string][] = rest
    ? [['basics', '1  Basics'], ['request', '2  Request'], ['response', '3  Response'], ['timing', '4  Waiting & retries']]
    : [['basics', '1  Basics'], ['output', '2  Output']];
  const idx = tabs.findIndex(([k]) => k === tab);
  const last = idx === tabs.length - 1;
  const tokenBar = (
    <div className="helper-box">
      <div className="helper-title">Insert a value <span className="hint">into the field you last clicked</span></div>
      <div className="token-bar">
        <button type="button" onClick={() => insert('input')}>input value</button>
        <button type="button" onClick={() => insert('step')}>earlier step value</button>
        <button type="button" onClick={() => insert('now')}>current time</button>
        <button type="button" onClick={() => insert('when')}>condition</button>
      </div>
      {earlier.length > 0 && (
        <select className="step-field-pick" aria-label="Use a response field from an earlier step" value=""
          onChange={(x) => { insertStepField(x.target.value); x.target.value = ''; }}>
          <option value="">Use a field from an earlier step…</option>
          {earlier.map(({ st, fields: fl }) => (
            <optgroup key={st.serviceId} label={`Step ${st.stepOrder} · ${st.stepDescription || st.endpoint || ''}`}>
              {fl.map((f) => <option key={f.path} value={`${st.stepOrder}|${f.path}`}>{f.path}{f.example !== undefined ? ` (e.g. ${typeof f.example === 'string' ? f.example : JSON.stringify(f.example)})` : ''}</option>)}
            </optgroup>
          ))}
        </select>
      )}
    </div>
  );

  return (
    <Modal title={isNew ? 'Add step' : `Edit step ${step!.stepOrder}`} wide onClose={onClose}
      footer={<>
        <button className="btn" type="button" onClick={onClose}>Cancel</button>
        <span className="spacer" />
        {idx > 0 && <button className="btn" type="button" onClick={() => setTab(tabs[idx - 1][0])}>Back</button>}
        {!last && <button className="btn" type="button" onClick={() => setTab(tabs[idx + 1][0])}>Next</button>}
        <button className="btn btn-primary" type="button" onClick={save} disabled={busy}>Save step</button>
      </>}>
      <div className="seg" role="tablist" aria-label="Step sections">
        {tabs.map(([k, label]) => (
          <button key={k} type="button" role="tab" aria-selected={k === tab} className={'seg-btn' + (k === tab ? ' active' : '')} onClick={() => setTab(k)}>{label}</button>
        ))}
      </div>

      <section hidden={tab !== 'basics'} className="sec">
        <h3>What is this step?</h3>
        <div className="row">
          <div><label htmlFor="f-order">Order</label>
            <input id="f-order" type="number" min={1} max={999} value={order} aria-invalid={orderTaken} onChange={(x) => setOrder(x.target.value)} /></div>
          <div><label htmlFor="f-type">Type</label>
            <select id="f-type" value={type} onChange={(x) => { setType(x.target.value); if (tab !== 'basics') setTab('basics'); }}>
              <option value="RESTAPI">REST API call</option>
              <option value="CONSOLIDATE">Consolidate results</option>
            </select></div>
        </div>
        {orderTaken && <p className="error" role="alert">This scenario already has a step {myOrder}. Choose a number that is not used.</p>}
        <p className="help">{rest ? 'Calls an API. Later steps can use what it returns.' : 'Builds the final response from the results of earlier steps. It makes no call.'}</p>
        <label htmlFor="f-desc">Description</label>
        <input id="f-desc" value={desc} placeholder="Create application" onChange={(x) => setDesc(x.target.value)} />
        <label className="check"><input type="checkbox" checked={active} onChange={(x) => setActive(x.target.checked)} /> Active <span className="hint">(untick to skip this step)</span></label>
      </section>

      {rest && (
        <section hidden={tab !== 'request'} className="sec">
          <div hidden={converting}>
            <h3>Where to send it</h3>
            <div className="row row-wide">
              <div><label htmlFor="f-base">Base URL <span className="hint">from Connections</span></label>
                <select id="f-base" value={base} onChange={(x) => setBase(x.target.value)}>
                  <option value="">None — endpoint is a full URL</option>
                  {configs.map((c) => <option key={c.id} value={c.configKey}>{c.configKey}{c.isSecret ? '' : ' — ' + c.configValue}</option>)}
                </select></div>
              <div className="w-method"><label htmlFor="f-method">Method</label>
                <select id="f-method" value={method} onChange={(x) => setMethod(x.target.value)}>
                  {METHODS.map((m) => <option key={m}>{m}</option>)}
                </select></div>
            </div>
            <label htmlFor="f-endpoint">Endpoint</label>
            <input id="f-endpoint" className="mono" ref={refs.endpoint} value={endpoint}
              placeholder="/applications/{step1.applicationId}"
              onFocus={track('endpoint')} onChange={(x) => setEndpoint(x.target.value)} />
            <p className="help">The path after the base URL. Use {'{input.name}'} or {'{step1.field}'} for values that change.</p>

            <h3>What to send</h3>
            <div className="label-row">
              <label htmlFor="f-input" style={{ margin: 0 }}>Request template <span className="hint">JSON with “body” and optional “headers”</span></label>
              <button type="button" className="btn btn-sm" onClick={() => setConverting(true)}>Build from JSON…</button>
            </div>
            <textarea id="f-input" className="mono" spellCheck={false} ref={refs.inputParamMap} value={input}
              placeholder={'{ "body": { "state": "$input.state" } }'}
              onFocus={track('inputParamMap')} onChange={(x) => setInput(x.target.value)} />
            <JsonStatus value={input} />
            {tokenBar}
          </div>
          {converting && (
            <>
              <h3>Build the request from an example</h3>
              <JsonConverter initial={input} onBack={() => setConverting(false)}
                onUse={(t) => { setInput(t); setConverting(false); toast('Request template updated.'); }} />
            </>
          )}
        </section>
      )}

      {rest && (
        <section hidden={tab !== 'response'} className="sec">
          <h3>Values this step returns</h3>
          <ResponseFields stepOrder={myOrder || 1} fields={fields} onChange={setFields} />
        </section>
      )}

      {rest && (
        <section hidden={tab !== 'timing'} className="sec">
          <h3>Waiting for a result</h3>
          <div className="panel" role="group" aria-label="Polling">
            <label className="check" style={{ marginTop: 0 }}>
              <input type="checkbox" checked={poll.on} onChange={(x) => setP({ on: x.target.checked })} />
              Keep checking this call until a condition is met
            </label>
            <p className="help" style={{ marginBottom: 0 }}>For example, wait until a policy status becomes “approved”.</p>
            {poll.on && (
              <>
                {poll.migratedFromLegacy && (
                  <p className="muted small">This step used the old Retries/Wait settings for polling. They were converted below; saving moves it to the new settings.</p>
                )}
                {poll.advanced === null ? (
                  <div className="row row-3" style={{ marginTop: 8 }}>
                    <div><label htmlFor="p-field">Stop when response field</label>
                      <input id="p-field" className="mono" list="p-field-list" placeholder={`step${order || 1}.status`} value={poll.field} onChange={(x) => setP({ field: x.target.value })} />
                      <datalist id="p-field-list">{fields.map((f) => <option key={f.path} value={stepToken(myOrder || 1, f.path, false).slice(1)} />)}</datalist></div>
                    <div><label htmlFor="p-op">Condition</label>
                      <select id="p-op" value={poll.op} onChange={(x) => setP({ op: x.target.value })}>
                        {POLL_OPS.map((o) => <option key={o.key} value={o.key}>{o.label}</option>)}
                      </select></div>
                    <div><label htmlFor="p-value">Value</label>
                      <input id="p-value" placeholder="approved" value={poll.value} onChange={(x) => setP({ value: x.target.value })} /></div>
                  </div>
                ) : (
                  <>
                    <label htmlFor="p-adv">Condition <span className="hint">JSON — this one is more than a simple comparison</span></label>
                    <textarea id="p-adv" className="mono" spellCheck={false} style={{ minHeight: 80 }} value={poll.advanced} onChange={(x) => setP({ advanced: x.target.value })} />
                  </>
                )}
                <div className="row">
                  <div><label htmlFor="p-int">Check every (seconds)</label>
                    <input id="p-int" type="number" min={1} max={3600} value={poll.intervalSeconds} onChange={(x) => setP({ intervalSeconds: x.target.value })} /></div>
                  <div><label htmlFor="p-max">Give up after (minutes)</label>
                    <input id="p-max" type="number" min={0.1} max={1440} step="any" value={poll.giveUpMinutes} onChange={(x) => setP({ giveUpMinutes: x.target.value })} /></div>
                </div>
                <p className="help">
                  {checks
                    ? `The call is made up to ${checks} time(s) in total: once now, then every ${intervalN}s for up to ${poll.giveUpMinutes} min. If the condition is never met, the step fails.`
                    : 'Set a check interval and a give-up time.'}
                </p>
                <label htmlFor="p-body">Request body for the re-checks <span className="hint">JSON, optional — empty resends the same body</span></label>
                <textarea id="p-body" className="mono" spellCheck={false} style={{ minHeight: 70 }} value={poll.recheckBody}
                  placeholder='{ "applicationId": "$step1.applicationId" }' onChange={(x) => setP({ recheckBody: x.target.value })} />
                <JsonStatus value={poll.recheckBody} />
              </>
            )}
          </div>

          <h3>Each call</h3>
          <div className="row row-3">
            {!poll.on && (
              <div><label htmlFor="f-retry">Retries <span className="hint">on 5xx</span></label>
                <input id="f-retry" type="number" min={0} max={10} value={retry} onChange={(x) => setRetry(x.target.value)} /></div>
            )}
            <div><label htmlFor="f-timeout">{poll.on ? 'Timeout per call (s)' : 'Timeout (s)'}</label>
              <input id="f-timeout" type="number" min={1} max={600} value={timeout} onChange={(x) => setTimeoutS(x.target.value)} /></div>
            <div><label htmlFor="f-wait">Wait before step (s)</label>
              <input id="f-wait" type="number" min={0} max={3600} value={wait} onChange={(x) => setWait(x.target.value)} /></div>
          </div>
          <p className="help">“Wait before step” pauses once before the step runs, whatever its type.</p>
        </section>
      )}

      {!rest && (
        <section hidden={tab !== 'output'} className="sec">
          <h3>Final response</h3>
          <label htmlFor="f-output">Output template <span className="hint">JSON that builds the response from earlier steps</span></label>
          <textarea id="f-output" className="mono" spellCheck={false} ref={refs.outputParamMap} value={output}
            placeholder={'{ "applicationId": "$step1.applicationId" }'}
            onFocus={track('outputParamMap')} onChange={(x) => setOutput(x.target.value)} />
          <JsonStatus value={output} />
          {tokenBar}
        </section>
      )}
      <p className="error">{err}</p>
    </Modal>
  );
}
