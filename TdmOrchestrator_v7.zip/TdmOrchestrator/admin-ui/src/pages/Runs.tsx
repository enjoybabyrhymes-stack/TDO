import { Fragment, useMemo, useState } from 'react';
import { api } from '../api';
import { useAsync } from '../hooks';
import type { RunFilters, RunItem } from '../types';
import { fmtTime } from '../util';
import { Chip } from '../components/Chip';
import { ErrorCard, Loading, PageHead } from '../components/Page';

const EMPTY: RunFilters = { project: '', environment: '', scenario: '', take: '100' };

/** A step row failed when it has an error message, or the system it called answered with something other than 2xx. */
const stepFailed = (r: RunItem) => !!r.errorMessage || (!!r.status && !String(r.status).startsWith('2'));

interface RunGroup {
  key: string;
  rows: RunItem[];        // steps of this run, in step order
  start: string;
  end?: string | null;
  failed?: RunItem;       // first step that failed
}

/** Rows that share a RunGroupId are one execution of a scenario. Older rows have none and stand alone. */
function groupRuns(rows: RunItem[]): RunGroup[] {
  const map = new Map<string, RunItem[]>();
  for (const r of rows) {
    const key = r.runGroupId || `row-${r.runId}`;
    const list = map.get(key); if (list) list.push(r); else map.set(key, [r]);
  }
  return [...map.entries()].map(([key, list]) => {
    const sorted = [...list].sort((a, b) => a.stepOrder - b.stepOrder || a.runId - b.runId);
    const ends = sorted.map((x) => x.executionEndTime).filter((x): x is string => !!x).sort();
    return { key, rows: sorted, start: sorted.map((x) => x.executionStartTime).sort()[0], end: ends[ends.length - 1], failed: sorted.find(stepFailed) };
  }).sort((a, b) => Math.max(...b.rows.map((x) => x.runId)) - Math.max(...a.rows.map((x) => x.runId)));
}

function duration(g: RunGroup): string {
  if (!g.end) return '';
  const ms = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(g.end) ? g.end : g.end + 'Z').getTime() - new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(g.start) ? g.start : g.start + 'Z').getTime();
  if (!(ms >= 0)) return '';
  return ms < 1000 ? `${ms} ms` : ms < 60000 ? `${(ms / 1000).toFixed(1)} s` : `${Math.floor(ms / 60000)} min ${Math.round((ms % 60000) / 1000)} s`;
}

export function Runs() {
  const [draft, setDraft] = useState<RunFilters>(EMPTY);   // what is typed in the boxes
  const [applied, setApplied] = useState<RunFilters>(EMPTY); // what the table is showing
  const [failedOnly, setFailedOnly] = useState(false);
  const [open, setOpen] = useState<Set<string>>(new Set());
  const { data, error, loading, reload } = useAsync(() => {
    const q = new URLSearchParams({ take: applied.take });
    (['project', 'environment', 'scenario'] as const).forEach((k) => { if (applied[k]) q.set(k, applied[k]); });
    return api<RunItem[]>('/runs?' + q.toString());
  }, [applied]);

  const groups = useMemo(() => groupRuns(data ?? []), [data]);
  const shown = failedOnly ? groups.filter((g) => g.failed) : groups;
  const failures = groups.filter((g) => g.failed).length;

  const set = (k: keyof RunFilters) => (e: { target: { value: string } }) => setDraft({ ...draft, [k]: e.target.value });
  const apply = () => { setApplied({ ...draft, project: draft.project.trim(), environment: draft.environment.trim(), scenario: draft.scenario.trim() }); };
  const enter = (e: React.KeyboardEvent) => { if (e.key === 'Enter') apply(); };
  const toggle = (key: string) => setOpen((cur) => { const n = new Set(cur); if (n.has(key)) n.delete(key); else n.add(key); return n; });

  return (
    <>
      <PageHead title="Run history" subtitle="One row per run, newest first. A failed run shows the step that failed and why. Open a run to see every step."
        actions={<button className="btn" type="button" onClick={reload}>Refresh</button>} />
      <div className="filters">
        <input placeholder="Project" aria-label="Project" value={draft.project} onChange={set('project')} onKeyDown={enter} />
        <input placeholder="Environment" aria-label="Environment" value={draft.environment} onChange={set('environment')} onKeyDown={enter} />
        <input placeholder="Scenario" aria-label="Scenario" value={draft.scenario} onChange={set('scenario')} onKeyDown={enter} />
        <select aria-label="Rows" value={draft.take} onChange={set('take')}>
          {['50', '100', '200'].map((n) => <option key={n} value={n}>{n} steps</option>)}
        </select>
        <button className="btn btn-primary" type="button" onClick={apply}>Apply</button>
        <label className="check failed-only"><input type="checkbox" checked={failedOnly} onChange={(e) => setFailedOnly(e.target.checked)} /> Failed runs only{failures > 0 ? ` (${failures})` : ''}</label>
      </div>
      {error && <ErrorCard message={error} onRetry={reload} />}
      {!error && !data && loading && <Loading />}
      {data && (
        <div className="card table-wrap">
          <table className="runs">
            <thead><tr><th></th><th>Time</th><th>Scenario</th><th>Result</th><th>Steps</th><th>Took</th><th>By</th></tr></thead>
            <tbody>
              {shown.length === 0 && <tr><td colSpan={7}><div className="empty">{failedOnly ? 'No failed runs.' : 'No runs found.'}</div></td></tr>}
              {shown.map((g) => {
                const first = g.rows[0];
                const isOpen = open.has(g.key);
                const f = g.failed;
                return (
                  <Fragment key={g.key}>
                    <tr className={'run-row click' + (f ? ' failed' : '')} onClick={() => toggle(g.key)} aria-expanded={isOpen}>
                      <td className="chev" aria-hidden="true">{isOpen ? '▾' : '▸'}</td>
                      <td className="nowrap muted">{fmtTime(g.start)}</td>
                      <td>{first.projectName} / {first.environment} / <strong>{first.scenarioName}</strong></td>
                      <td>
                        {f
                          ? <>
                              <Chip kind="bad">Failed at step {f.stepOrder}</Chip>
                              {f.errorMessage && <div className="small run-error">{f.errorMessage}</div>}
                              {!f.errorMessage && <div className="small run-error">The system answered HTTP {f.status}.</div>}
                            </>
                          : <Chip kind="ok">Succeeded</Chip>}
                      </td>
                      <td className="muted">{g.rows.length}</td>
                      <td className="muted nowrap">{duration(g)}</td>
                      <td>{first.executedBy || ''}</td>
                    </tr>
                    {isOpen && (
                      <tr className="run-detail">
                        <td></td>
                        <td colSpan={6}>
                          <table className="run-steps">
                            <thead><tr><th>Step</th><th>Status</th><th>Tries</th><th>Called URL</th><th>Error</th></tr></thead>
                            <tbody>
                              {g.rows.map((r) => (
                                <tr key={r.runId} className={stepFailed(r) ? 'bad-row' : ''}>
                                  <td>{r.stepOrder}</td>
                                  <td><Chip kind={stepFailed(r) ? 'bad' : 'ok'}>{r.status || '—'}</Chip></td>
                                  <td>{r.attemptCount}</td>
                                  <td className="small" style={{ wordBreak: 'break-all', maxWidth: 320 }}>{r.requestUrl || ''}</td>
                                  <td className="small">{r.errorMessage || ''}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                          {f && <p className="muted small" style={{ margin: '8px 0 0' }}>Steps after step {f.stepOrder} did not run.</p>}
                        </td>
                      </tr>
                    )}
                  </Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </>
  );
}
