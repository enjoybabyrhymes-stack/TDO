import { useState } from 'react';
import { api } from '../api';
import { useGuard, useAsync, useGroups } from '../hooks';
import { useAuth } from '../components/Auth';
import { GroupSelect } from '../components/GroupSelect';
import type { ConfigItem } from '../types';
import { enc, errMessage, fmtTime } from '../util';
import { Chip } from '../components/Chip';
import { useConfirm } from '../components/Confirm';
import { Modal } from '../components/Modal';
import { ErrorCard, Loading, PageHead } from '../components/Page';
import { useToast } from '../components/Toasts';

export function Connections() {
  const { isAdmin } = useAuth();
  const { data, error, loading, reload } = useAsync(() => api<ConfigItem[]>('/configs'), []);
  const [editing, setEditing] = useState<ConfigItem | 'new' | null>(null);
  const confirm = useConfirm();
  const guard = useGuard();
  const toast = useToast();

  const remove = async (c: ConfigItem) => {
    if (!(await confirm(`Delete connection “${c.configKey}”?`))) return;
    await guard(async () => { await api(`/configs/${enc(String(c.id))}`, { method: 'DELETE' }); toast('Connection deleted.'); reload(); });
  };

  return (
    <>
      <PageHead title="Connections"
        subtitle="Named base URLs and settings. A step picks a connection by name, so changing the URL here updates every step that uses it."
        actions={<button className="btn btn-primary" type="button" onClick={() => setEditing('new')}>Add connection</button>} />
      {error && <ErrorCard message={error} onRetry={reload} />}
      {!error && !data && loading && <Loading />}
      {data && (
        <div className="card table-wrap">
          <table>
            <thead><tr><th>Name</th>{isAdmin && <th>Group</th>}<th>Value</th><th>Description</th><th>Updated</th><th></th></tr></thead>
            <tbody>
              {data.length === 0 && <tr><td colSpan={isAdmin ? 6 : 5}><div className="empty">No connections yet. Add the base URL of the API your steps call.</div></td></tr>}
              {data.map((c) => (
                <tr key={c.id}>
                  <td><strong>{c.configKey}</strong></td>
                  {isAdmin && <td>{c.groupName ?? <Chip kind="warn">Unassigned</Chip>}</td>}
                  <td>{c.isSecret ? <Chip>Secret — hidden</Chip> : <code>{c.configValue}</code>}</td>
                  <td className="muted">{c.description || ''}</td>
                  <td className="muted nowrap">{fmtTime(c.updatedAt)}</td>
                  <td className="right nowrap">
                    <button className="btn btn-sm" type="button" onClick={() => setEditing(c)}>Edit</button>{' '}
                    <button className="btn btn-sm btn-danger" type="button" onClick={() => remove(c)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {editing && <ConnectionDialog item={editing === 'new' ? null : editing} onClose={() => setEditing(null)} onSaved={reload} />}
    </>
  );
}

function ConnectionDialog({ item, onClose, onSaved }: { item: ConfigItem | null; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [key, setKey] = useState(item?.configKey ?? '');
  const [value, setValue] = useState(item && !item.isSecret ? item.configValue : '');
  const [desc, setDesc] = useState(item?.description ?? '');
  const { isAdmin } = useAuth();
  const { data: groups } = useGroups();
  const [groupId, setGroupId] = useState(item?.groupId ? String(item.groupId) : '');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const secret = !!item?.isSecret;

  const save = async () => {
    setErr('');
    if (isAdmin && !item && !groupId) { setErr('Choose the group this connection belongs to.'); return; }
    setBusy(true);
    try {
      await api(item ? `/configs/${item.id}` : '/configs', {
        method: item ? 'PUT' : 'POST',
        body: { configKey: key.trim(), configValue: value.trim(), description: desc.trim(), groupId: isAdmin && groupId ? Number(groupId) : undefined }
      });
      onClose(); toast('Connection saved.'); onSaved();
    } catch (ex) { setErr(errMessage(ex)); setBusy(false); }
  };

  return (
    <Modal title={item ? 'Edit connection' : 'Add connection'} narrow onClose={onClose}
      footer={<>
        <button className="btn" type="button" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary" type="button" onClick={save} disabled={busy}>Save</button>
      </>}>
      {isAdmin && (
        <>
          <label htmlFor="cnG">Group</label>
          <GroupSelect id="cnG" groups={groups ?? []} value={groupId} onChange={setGroupId} emptyLabel={item ? 'Not assigned' : undefined} />
        </>
      )}
      <label htmlFor="cnK">Name</label>
      <input id="cnK" value={key} placeholder="PartnerApi.BaseUrl" onChange={(e) => setKey(e.target.value)} />
      <label htmlFor="cnV">Value</label>
      <input id="cnV" className="mono" type={secret ? 'password' : 'text'} autoComplete={secret ? 'new-password' : undefined}
        value={value} onChange={(e) => setValue(e.target.value)}
        placeholder={secret ? 'Leave empty to keep the current secret' : 'https://api.example.com'} />
      {!item && <p className="muted small">Names containing key, secret, token or password are treated as secrets and are never shown again.</p>}
      <label htmlFor="cnD">Description <span className="hint">(optional)</span></label>
      <input id="cnD" value={desc} onChange={(e) => setDesc(e.target.value)} />
      <p className="error">{err}</p>
    </Modal>
  );
}
