import { useState } from 'react';
import { api } from '../api';
import { useGuard } from '../hooks';
import type { ConfigItem, Step } from '../types';
import { Chip } from '../components/Chip';
import { useConfirm } from '../components/Confirm';
import { useToast } from '../components/Toasts';
import { StepEditor } from './StepEditor';
import { ImportDialog } from '../components/ImportDialog';
import { usersOfStep } from '../stepRefs';
import { pollSummary } from '../poll';

interface Props { p: string; e: string; s: string; steps: Step[]; configs: ConfigItem[]; groupId?: number; reload: () => void }

export function StepsTab({ p, e, s, steps, configs, groupId, reload }: Props) {
  const [editing, setEditing] = useState<Step | 'new' | null>(null);
  const [importing, setImporting] = useState(false);
  const guard = useGuard();
  const toast = useToast();
  const confirm = useConfirm();

  const remove = async (st: Step) => {
    const label = `${st.stepOrder}${st.stepDescription ? ' (' + st.stepDescription + ')' : ''}`;
    const users = usersOfStep(steps, st.stepOrder);
    const later = steps.filter((x) => x.stepOrder > st.stepOrder).length;
    const lines = [`Delete step ${label}?`];
    if (later > 0) lines.push(`The ${later} step${later === 1 ? '' : 's'} after it will be renumbered (step ${st.stepOrder + 1} becomes step ${st.stepOrder}, and so on).`);
    if (users.length > 0) lines.push(`Step${users.length === 1 ? '' : 's'} ${users.map((x) => x.stepOrder).join(', ')} use${users.length === 1 ? 's' : ''} values from this step. Those references will be marked as step0 and must be fixed.`);
    if (!(await confirm(lines.join(' ')))) return;
    await guard(async () => {
      await api(`/steps/${st.serviceId}`, { method: 'DELETE' });
      toast(later > 0 ? `Step deleted. Later steps were renumbered.${users.length ? ' Fix the references to step0.' : ''}` : 'Step deleted.', users.length > 0);
      reload();
    });
  };

  // Swap the order numbers of two neighbouring steps.
  const move = (st: Step, other: Step, direction: 'up' | 'down') => guard(async () => {
    if (other.stepOrder === st.stepOrder) { toast('Two steps have the same order number. Give each step its own number first.', true); return; }
    await api(`/steps/${st.serviceId}/move`, { method: 'POST', body: { direction } });
    reload();
  });

  return (
    <>
      <div className="actions" style={{ marginBottom: 12 }}>
        <button className="btn btn-primary" type="button" onClick={() => setEditing('new')}>Add step</button>
        <button className="btn" type="button" onClick={() => setImporting(true)}>Import…</button>
        <span className="muted small">Steps run from the lowest order to the highest. Later steps can use earlier responses.</span>
      </div>
      <div className="card">
        {steps.length === 0 && <div className="empty">No steps yet. Add the first step to define what this scenario calls.</div>}
        {steps.map((st, i) => {
          const rest = st.stepType === 'RESTAPI';
          return (
            <div key={st.serviceId} className={'step' + (st.active ? '' : ' off')}>
              <div className="step-no">{st.stepOrder}</div>
              <div>
                <div className="step-title">
                  {st.stepDescription || '(no description)'}{' '}
                  {!rest && <Chip kind="blue">Consolidate</Chip>}{' '}
                  {!st.active && <Chip kind="warn">Disabled</Chip>}
                </div>
                <div className="step-sub">
                  {rest
                    ? <><span className="method">{st.httpMethod || ''}</span> {st.baseUrlConfigKey ? `[${st.baseUrlConfigKey}] ` : ''}{st.endpoint || ''}</>
                    : 'Combines results of earlier steps into the final response'}
                </div>
                {rest && pollSummary(st)
                  ? <div className="step-sub"><Chip kind="blue">Polling</Chip> {pollSummary(st)} · timeout {st.timeoutSeconds}s per call{st.waitTimeSeconds > 0 && st.pollIntervalSeconds > 0 ? ` · wait ${st.waitTimeSeconds}s before` : ''}</div>
                  : <div className="step-sub">retry {st.retryCount} · timeout {st.timeoutSeconds}s · wait {st.waitTimeSeconds}s</div>}
              </div>
              <div className="step-actions">
                <button className="btn btn-sm" type="button" disabled={i === 0} aria-label="Move step up" onClick={() => move(st, steps[i - 1], 'up')}>↑</button>
                <button className="btn btn-sm" type="button" disabled={i === steps.length - 1} aria-label="Move step down" onClick={() => move(st, steps[i + 1], 'down')}>↓</button>
                <button className="btn btn-sm" type="button" onClick={() => setEditing(st)}>Edit</button>
                <button className="btn btn-sm btn-danger" type="button" onClick={() => remove(st)}>Delete</button>
              </div>
            </div>
          );
        })}
      </div>
      {importing && (
        <ImportDialog p={p} e={e} s={s} groupId={groupId} steps={steps} configs={configs}
          onClose={() => setImporting(false)} onDone={reload} />
      )}
      {editing && (
        <StepEditor p={p} e={e} s={s} step={editing === 'new' ? null : editing} steps={steps} configs={configs} groupId={groupId}
          onClose={() => setEditing(null)} onSaved={reload} />
      )}
    </>
  );
}
