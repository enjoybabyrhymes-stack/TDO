import { useState } from 'react';
import { api } from '../api';
import { useAsync, useGroups, useGuard } from '../hooks';
import type { AppUser, Group } from '../types';
import { errMessage, fmtTime } from '../util';
import { Chip } from '../components/Chip';
import { useAuth } from '../components/Auth';
import { useConfirm } from '../components/Confirm';
import { GroupSelect } from '../components/GroupSelect';
import { Modal } from '../components/Modal';
import { ErrorCard, Loading, PageHead } from '../components/Page';
import { useToast } from '../components/Toasts';

type Dialog = { kind: 'new' } | { kind: 'edit'; user: AppUser } | { kind: 'password'; user: AppUser } | null;

export function Users() {
  const { user: me } = useAuth();
  const { data, error, loading, reload } = useAsync(() => api<AppUser[]>('/users'), []);
  const { data: groups } = useGroups();
  const [dialog, setDialog] = useState<Dialog>(null);
  const confirm = useConfirm();
  const guard = useGuard();
  const toast = useToast();

  const remove = async (u: AppUser) => {
    if (!(await confirm(`Delete the user “${u.username}”? They will be signed out immediately.`))) return;
    await guard(async () => { await api(`/users/${u.userId}`, { method: 'DELETE' }); toast('User deleted.'); reload(); });
  };

  return (
    <>
      <PageHead title="Users"
        subtitle="Only administrators can create users. A user belongs to one group and works only with that group's data."
        actions={<button className="btn btn-primary" type="button" onClick={() => setDialog({ kind: 'new' })}>Add user</button>} />
      {error && <ErrorCard message={error} onRetry={reload} />}
      {!error && !data && loading && <Loading />}
      {data && (
        <div className="card table-wrap">
          <table>
            <thead><tr><th>User name</th><th>Role</th><th>Group</th><th>Status</th><th>Last sign-in</th><th></th></tr></thead>
            <tbody>
              {data.length === 0 && <tr><td colSpan={6}><div className="empty">No users yet.</div></td></tr>}
              {data.map((u) => (
                <tr key={u.userId}>
                  <td><strong>{u.username}</strong>{me?.userId === u.userId && <span className="muted"> (you)</span>}</td>
                  <td>{u.role === 'ADMIN' ? <Chip kind="blue">Administrator</Chip> : 'User'}</td>
                  <td>{u.role === 'ADMIN' ? <span className="muted">All groups</span> : u.groupName}</td>
                  <td>{u.active ? <Chip kind="ok">Active</Chip> : <Chip kind="warn">Disabled</Chip>}</td>
                  <td className="muted nowrap">{fmtTime(u.lastLoginAt) || 'Never'}</td>
                  <td className="right nowrap">
                    <button className="btn btn-sm" type="button" onClick={() => setDialog({ kind: 'edit', user: u })}>Edit</button>{' '}
                    <button className="btn btn-sm" type="button" onClick={() => setDialog({ kind: 'password', user: u })}>Reset password</button>{' '}
                    <button className="btn btn-sm btn-danger" type="button" disabled={me?.userId === u.userId} onClick={() => remove(u)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {dialog?.kind === 'new' && <UserDialog user={null} groups={groups ?? []} onClose={() => setDialog(null)} onSaved={reload} />}
      {dialog?.kind === 'edit' && <UserDialog user={dialog.user} groups={groups ?? []} onClose={() => setDialog(null)} onSaved={reload} />}
      {dialog?.kind === 'password' && <PasswordDialog user={dialog.user} onClose={() => setDialog(null)} />}
    </>
  );
}

function UserDialog({ user, groups, onClose, onSaved }: { user: AppUser | null; groups: Group[]; onClose: () => void; onSaved: () => void }) {
  const toast = useToast();
  const [username, setUsername] = useState(user?.username ?? '');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState(user?.role ?? 'USER');
  const [groupId, setGroupId] = useState(user?.groupId ? String(user.groupId) : '');
  const [active, setActive] = useState(user?.active ?? true);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const isAdminRole = role === 'ADMIN';

  const save = async () => {
    setErr('');
    if (!isAdminRole && !groupId) { setErr('Choose the group this user belongs to.'); return; }
    setBusy(true);
    try {
      const gid = isAdminRole ? null : Number(groupId);
      if (user) await api(`/users/${user.userId}`, { method: 'PUT', body: { role, groupId: gid, active } });
      else await api('/users', { method: 'POST', body: { username: username.trim(), password, role, groupId: gid } });
      onClose(); toast('User saved.'); onSaved();
    } catch (ex) { setErr(errMessage(ex)); setBusy(false); }
  };

  return (
    <Modal title={user ? `Edit ${user.username}` : 'Add user'} narrow onClose={onClose}
      footer={<>
        <button className="btn" type="button" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary" type="button" onClick={save} disabled={busy}>Save</button>
      </>}>
      {!user && (
        <>
          <label htmlFor="uName">User name</label>
          <input id="uName" autoComplete="off" value={username} placeholder="asha.kulkarni" onChange={(e) => setUsername(e.target.value)} />
          <label htmlFor="uPass">Password <span className="hint">at least 8 characters</span></label>
          <input id="uPass" type="password" autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </>
      )}
      <label htmlFor="uRole">Role</label>
      <select id="uRole" value={role} onChange={(e) => setRole(e.target.value)}>
        <option value="USER">User — works inside one group</option>
        <option value="ADMIN">Administrator — manages groups, users and all data</option>
      </select>
      {!isAdminRole && (
        <>
          <label htmlFor="uGroup">Group</label>
          <GroupSelect id="uGroup" groups={groups} value={groupId} onChange={setGroupId} />
        </>
      )}
      {user && (
        <label className="check"><input type="checkbox" checked={active} onChange={(e) => setActive(e.target.checked)} /> Active <span className="hint">(untick to block sign-in)</span></label>
      )}
      <p className="error">{err}</p>
    </Modal>
  );
}

function PasswordDialog({ user, onClose }: { user: AppUser; onClose: () => void }) {
  const toast = useToast();
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const save = async () => {
    setBusy(true); setErr('');
    try {
      await api(`/users/${user.userId}/password`, { method: 'POST', body: { password } });
      onClose(); toast('Password changed. The user was signed out.');
    } catch (ex) { setErr(errMessage(ex)); setBusy(false); }
  };

  return (
    <Modal title={`Reset password for ${user.username}`} narrow onClose={onClose}
      footer={<>
        <button className="btn" type="button" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary" type="button" onClick={save} disabled={busy}>Change password</button>
      </>}>
      <label htmlFor="rPass">New password <span className="hint">at least 8 characters</span></label>
      <input id="rPass" type="password" autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)}
        onKeyDown={(e) => { if (e.key === 'Enter') save(); }} />
      <p className="muted small">Share it with the person securely. They are signed out on every device when you save.</p>
      <p className="error">{err}</p>
    </Modal>
  );
}
