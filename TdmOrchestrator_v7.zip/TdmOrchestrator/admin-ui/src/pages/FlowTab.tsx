import type { Step } from '../types';
import { pollSummary } from '../poll';
import { parseFields } from '../outputFields';
import { refText, stepsOf } from '../stepRefs';

/** Names of the $input values a step uses, in the order they first appear. */
const inputsOf = (st: Step) => [...new Set([...refText(st).matchAll(/(?:\$input\.|\{input\.)([A-Za-z_]\w*)/g)].map((m) => m[1]))];

export function FlowTab({ steps }: { steps: Step[] }) {
  if (steps.length === 0) return <div className="card"><div className="empty">No steps yet. Add steps to see the flow.</div></div>;
  const ordered = [...steps].sort((a, b) => a.stepOrder - b.stepOrder || a.serviceId - b.serviceId);
  const allInputs = [...new Set(ordered.flatMap(inputsOf))];
  const orders = new Set(ordered.map((x) => x.stepOrder));

  return (
    <div className="flow" aria-label="Scenario flow">
      <div className="flow-node flow-edge-node">
        <div className="flow-title">Start</div>
        {allInputs.length > 0
          ? <div className="flow-chips"><span className="muted small">User provides</span>{allInputs.map((n) => <span key={n} className="flow-chip input">{n}</span>)}</div>
          : <div className="muted small">No user input needed</div>}
      </div>

      {ordered.map((st) => {
        const rest = st.stepType === 'RESTAPI';
        const ins = inputsOf(st);
        const deps = stepsOf(st);
        const poll = rest ? pollSummary(st) : '';
        const outs = rest ? parseFields(st.outputParamMap) : [];
        return (
          <div key={st.serviceId} className="flow-seg">
            <div className="flow-arrow" aria-hidden="true" />
            <div className={'flow-node' + (st.active ? '' : ' off') + (rest ? '' : ' consolidate')}>
              <div className="flow-head">
                <span className="step-no">{st.stepOrder}</span>
                <div className="flow-main">
                  <div className="step-title">{st.stepDescription || '(no description)'}</div>
                  <div className="step-sub">
                    {rest
                      ? <><span className="method">{st.httpMethod || ''}</span> {st.baseUrlConfigKey ? `[${st.baseUrlConfigKey}] ` : ''}{st.endpoint || ''}</>
                      : 'Combines the results of earlier steps into the final response'}
                  </div>
                </div>
                {!st.active && <span className="chip warn">Disabled</span>}
                {!rest && <span className="chip blue">Consolidate</span>}
              </div>
              {(ins.length > 0 || deps.length > 0 || outs.length > 0 || st.waitTimeSeconds > 0 || (rest && !poll && st.retryCount > 0)) && (
                <div className="flow-chips">
                  {ins.map((n) => <span key={'i' + n} className="flow-chip input" title="Value the user provides">input · {n}</span>)}
                  {deps.map((n) => <span key={'s' + n} className={'flow-chip dep' + (orders.has(n) ? '' : ' bad')} title="Uses a value from an earlier step">{orders.has(n) ? `from step ${n}` : `step ${n} is missing`}</span>)}
                  {outs.map((o) => <span key={'o' + o.path} className="flow-chip out" title="Value later steps can use">returns · {o.path}</span>)}
                  {st.waitTimeSeconds > 0 && <span className="flow-chip">waits {st.waitTimeSeconds}s first</span>}
                  {rest && !poll && st.retryCount > 0 && <span className="flow-chip">retries {st.retryCount}×</span>}
                </div>
              )}
              {poll && (
                <div className="flow-loop"><span aria-hidden="true">↻</span> <strong>Repeats</strong> {poll}</div>
              )}
            </div>
          </div>
        );
      })}

      <div className="flow-arrow" aria-hidden="true" />
      <div className="flow-node flow-edge-node"><div className="flow-title">Response returned to the caller</div></div>
    </div>
  );
}
