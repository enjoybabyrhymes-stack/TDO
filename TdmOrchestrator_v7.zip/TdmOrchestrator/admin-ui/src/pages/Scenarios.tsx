import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api';
import { useAsync, useGroups, useScenarioNameCheck } from '../hooks';
import { useAuth } from '../components/Auth';
import { GroupSelect } from '../components/GroupSelect';
import type { ScenarioSummary } from '../types';
import { fmtTime, NAME_HINT, NAME_RE, scenarioPath } from '../util';
import { Chip } from '../components/Chip';
import { NameStatus } from '../components/NameStatus';
import { ErrorCard, Loading, PageHead } from '../components/Page';
import { Modal } from '../components/Modal';

export function Scenarios() {
  const nav = useNavigate();
  const { isAdmin } = useAuth();
  const { data, error, loading, reload } = useAsync(() => api<ScenarioSummary[]>('/scenarios'), []);
  const [filter, setFilter] = useState('');
  const [creating, setCreating] = useState(false);

  const rows = useMemo(() => {
    const q = filter.trim().toLowerCase();
    return (data ?? []).filter((s) => `${s.projectName} ${s.environment} ${s.scenarioName} ${s.groupName ?? ''}`.toLowerCase().includes(q));
  }, [data, filter]);

  const open = (s: ScenarioSummary) => nav(scenarioPath(s.projectName, s.environment, s.scenarioName));
  const cols = isAdmin ? 7 : 6;

  return (
    <>
      <PageHead title="Scenarios"
        subtitle={isAdmin ? 'Scenarios from every group. A scenario belongs to one group, and only that group’s users can see it.' : 'A scenario is an ordered list of API calls. Run it from Postman once it is set up.'}
        actions={<button className="btn btn-primary" type="button" onClick={() => setCreating(true)}>New scenario</button>} />
      {error && <ErrorCard message={error} onRetry={reload} />}
      {!error && !data && loading && <Loading />}
      {data && (
        <>
          <div className="filters">
            <input type="search" placeholder="Filter by project, environment or name" aria-label="Filter scenarios"
              value={filter} onChange={(e) => setFilter(e.target.value)} />
          </div>
          <div className="card table-wrap">
            <table>
              <thead><tr><th>Project</th><th>Environment</th><th>Scenario</th>{isAdmin && <th>Group</th>}<th>Steps</th><th>Status</th><th>Updated</th></tr></thead>
              <tbody>
                {rows.length === 0 && (
                  <tr><td colSpan={cols}><div className="empty">
                    {data.length ? 'No scenarios match the filter.' : 'No scenarios yet. Create one to get started.'}
                  </div></td></tr>
                )}
                {rows.map((s) => (
                  <tr key={`${s.projectName}/${s.environment}/${s.scenarioName}`} className="click" tabIndex={0}
                    onClick={() => open(s)} onKeyDown={(e) => { if (e.key === 'Enter') open(s); }}>
                    <td>{s.projectName}</td><td>{s.environment}</td><td><strong>{s.scenarioName}</strong></td>
                    {isAdmin && <td>{s.groupName ?? <Chip kind="warn">Unassigned</Chip>}</td>}
                    <td>{s.stepCount}</td>
                    <td>
                      {s.activeStepCount === 0 ? <Chip kind="warn">Disabled</Chip>
                        : s.activeStepCount === s.stepCount ? <Chip kind="ok">Active</Chip>
                        : <Chip kind="blue">{s.activeStepCount} of {s.stepCount} active</Chip>}
                    </td>
                    <td className="muted nowrap">{fmtTime(s.updatedAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
      {creating && <NewScenarioDialog list={data ?? []} onClose={() => setCreating(false)} />}
    </>
  );
}

function NewScenarioDialog({ list, onClose }: { list: ScenarioSummary[]; onClose: () => void }) {
  const nav = useNavigate();
  const [p, setP] = useState('');
  const [e, setE] = useState('');
  const [s, setS] = useState('');
  const [err, setErr] = useState('');
  const { isAdmin } = useAuth();
  const { data: groups } = useGroups();
  const [groupId, setGroupId] = useState('');
  const check = useScenarioNameCheck(p, e, s);
  const uniq = (k: 'projectName' | 'environment') => [...new Set(list.map((x) => x[k]))];

  const go = () => {
    const vals = [p, e, s].map((v) => v.trim());
    if (!vals.every((v) => v && NAME_RE.test(v))) { setErr(`Enter all three names using only ${NAME_HINT}.`); return; }
    if (check.state === 'taken') { setErr(check.message ?? 'That scenario name is already in use.'); return; }
    if (isAdmin && !groupId) { setErr('Choose the group this scenario belongs to.'); return; }
    onClose();
    nav(scenarioPath(vals[0], vals[1], vals[2]) + (isAdmin ? `?group=${groupId}` : ''));
  };

  return (
    <Modal title="New scenario" narrow onClose={onClose}
      footer={<>
        <button className="btn" type="button" onClick={onClose}>Cancel</button>
        <button className="btn btn-primary" type="button" onClick={go}>Continue</button>
      </>}>
      <p className="muted small">Names are used in the run URL, so use {NAME_HINT}.</p>
      <datalist id="dlP">{uniq('projectName').map((v) => <option key={v} value={v} />)}</datalist>
      <datalist id="dlE">{uniq('environment').map((v) => <option key={v} value={v} />)}</datalist>
      {isAdmin && (
        <>
          <label htmlFor="nsG">Group</label>
          <GroupSelect id="nsG" groups={groups ?? []} value={groupId} onChange={setGroupId} />
        </>
      )}
      <label htmlFor="nsP">Project</label>
      <input id="nsP" list="dlP" placeholder="PARTNER_API" value={p} onChange={(ev) => setP(ev.target.value)} />
      <label htmlFor="nsE">Environment</label>
      <input id="nsE" list="dlE" placeholder="QA" value={e} onChange={(ev) => setE(ev.target.value)} />
      <label htmlFor="nsS">Scenario</label>
      <input id="nsS" placeholder="CREATE_POLICY" value={s} onChange={(ev) => setS(ev.target.value)}
        onKeyDown={(ev) => { if (ev.key === 'Enter') go(); }} />
      <NameStatus check={check} onOpen={() => { onClose(); nav(scenarioPath(p.trim(), e.trim(), s.trim())); }} />
      <p className="error">{err}</p>
    </Modal>
  );
}
