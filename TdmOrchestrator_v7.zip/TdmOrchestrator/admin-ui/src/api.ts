const API = '/api/v1/admin';
export const SESSION_STORE = 'tdmAdminSession';

/** What the browser sends to prove who it is: a session token (username/password) or the admin key. */
export type Credential = { kind: 'token'; value: string } | { kind: 'key'; value: string } | null;

let credential: Credential = null;
let onUnauthorized: () => void = () => {};

export function setCredential(c: Credential) { credential = c; }
export function setUnauthorizedHandler(fn: () => void) { onUnauthorized = fn; }

interface Options { method?: string; body?: unknown; /** For the sign-in call itself: a 401 is just "wrong password". */ anonymous?: boolean }

export async function api<T = unknown>(path: string, opts: Options = {}): Promise<T> {
  const { method = 'GET', body, anonymous = false } = opts;
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (!anonymous && credential) {
    if (credential.kind === 'token') headers['Authorization'] = 'Bearer ' + credential.value;
    else headers['X-Admin-Key'] = credential.value;
  }
  const res = await fetch(API + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });

  let data: any = null;
  if (res.status !== 204) {
    const text = await res.text();
    if (text) { try { data = JSON.parse(text); } catch { /* not JSON */ } }
  }
  const message = (data && (data.detail || data.error || data.title)) || `Request failed (${res.status}).`;

  if (res.status === 401 && !anonymous) {
    onUnauthorized();
    throw new Error(message);
  }
  if (!res.ok) throw new Error(message);
  return (res.status === 204 ? null : data) as T;
}
