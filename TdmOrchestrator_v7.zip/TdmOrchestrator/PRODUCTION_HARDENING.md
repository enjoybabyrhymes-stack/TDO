# Production Hardening — Architect's Notes

Everything below reflects what's actually in this codebase after this round of
changes — not aspirational claims. Read this before you deploy anywhere real.

---

## What changed in this round (code-level)

### 1. API-key authentication (NEW — was completely absent before)
**Files:** `Middleware/ApiKeyAuthMiddleware.cs`, `Options/ApiKeyOptions.cs`

Every request now needs an `X-Api-Key` header matching a configured key, except
`/health/live`, `/health/ready`, and `/swagger`. **The app fails CLOSED**: if no
keys are configured, it rejects every request with a 503 rather than silently
running unauthenticated. This is intentional — it forces a conscious decision in
every new environment instead of an accidental open API.

Comparison uses `CryptographicOperations.FixedTimeEquals` (constant-time), so an
attacker can't guess the key faster by timing failed attempts.

**This is a v1 gate, not a full auth system.** It's all-or-nothing — one valid
key can run every project/environment/scenario. See "What's still needed" below.

### 2. SSRF protection upgraded from scheme-only to DNS-resolution-aware
**Files:** `Utility/NetworkSafetyValidator.cs`, `Utility/RestApiUtility.cs`

The original code only checked the URL scheme was `http`/`https`. Now, before any
call goes out, the target hostname is resolved and checked against:
- **Always blocked:** loopback (127.0.0.1/::1) and link-local addresses
  (169.254.0.0/16) — this notably includes `169.254.169.254`, the cloud
  instance-metadata endpoint SSRF attacks commonly target to steal AWS/GCP/Azure
  credentials.
- **Optionally blocked** (`Security:BlockAllPrivateNetworks`, default `false`):
  the full RFC 1918 private ranges (10.x, 172.16-31.x, 192.168.x). Left off by
  default because **real deployments legitimately call internal systems** on
  private networks (like the HR-system example we discussed) — turning this on
  by default would break exactly that use case. Only enable it if you're certain
  no step in this deployment should ever reach a private-network target.

### 3. URL-encoding fix in PlaceholderResolver
**File:** `Utility/PlaceholderResolver.cs`

Resolved `{step.field}`/`{input.field}` values are now passed through
`Uri.EscapeDataString()` before being inserted into a URL. Previously, a resolved
value containing `&`, spaces, or other special characters could corrupt the URL
or let unexpected characters flow into the query string unescaped. This only
affects the *substituted value* — the literal template text around it (like
`?select=firstName,lastName`) is untouched, so nothing you've already built
breaks.

### 4. Retry count is enforced (from earlier this session)
`OrchestrationStep.RetryCount` now actually drives retries on RESTAPI steps,
retrying only on 5xx failures with linear backoff. **New this round:**
`OrchestrationRun.AttemptCount` records how many tries it actually took, so the
audit trail shows retry activity, not just the final outcome.

### 5. Real database health check (was a no-op before)
**File:** `HealthChecks/DatabaseHealthCheck.cs`

`AddHealthChecks()` previously had zero checks registered — `/health/ready`
always returned healthy even with a completely unreachable database. It now
actually calls `CanConnectAsync()`.

### 6. HTTPS redirection added
`Program.cs` now calls `app.UseHttpsRedirection()`. Wasn't there before.

### 7. Rate limiting (NEW)
100 requests/minute per API key (or per IP if unauthenticated), using ASP.NET
Core's built-in rate limiter — no new NuGet dependency. This is a **starting
placeholder number**, not a tuned production value.

---

## Per-Environment Checklist — what to actually change when moving to a client environment

This is the whole point of building it this way: **the code doesn't change
between environments, only configuration does.** Everything below is either an
environment variable or a database row — nothing requires touching a `.cs` file.

| # | What | How | Required? |
|---|---|---|---|
| 1 | **Database connection string** | Set `ConnectionStrings__OrchestratorDb` env var (or your secrets manager) | ✅ Required |
| 2 | **At least one API key** | Set `ApiKey__ValidKeys__0` (and `__1`, `__2`... for more) | ✅ Required — app refuses to serve traffic without this |
| 3 | **Scenario data** (projects/steps) | Insert rows into `OrchestrationSteps` for this client's real workflows | ✅ Required |
| 4 | **Base URLs & secrets for real integrations** | Insert rows into `ApiConfig` (e.g. `ClientHR.BaseUrl`, `ClientHR.ApiKey`) | ✅ Required |
| 5 | **ASPNETCORE_ENVIRONMENT** | Set to `Production` (disables Swagger UI automatically) | ✅ Required |
| 6 | `Security:BlockAllPrivateNetworks` | Leave `false` if any real integration is on a private network; set `true` only for fully public-internet-only deployments | Situational |
| 7 | Rate limit numbers | Adjust the `PermitLimit`/`Window` values in `Program.cs` if 100/min doesn't fit this client's traffic | Situational — currently still a code change, see note below |

**Note on #7:** rate limit values are still hardcoded in `Program.cs` rather than
config-driven. If you expect to tune these per client, that's a quick follow-up
(move them into an `Options` class like `ApiKeyOptions`/`SecurityOptions` — I can
do this next if you want it before rollout).

---

## What's still needed before this is genuinely "production ready" (not done in this round — needs your decision, not just code)

These weren't addressed because each one requires a judgment call specific to
your client's environment, compliance requirements, or infrastructure — not
because they're hard to code.

### 🔴 Should resolve before any client with real/sensitive data
1. **Secrets in `ApiConfig` are still plaintext in the database.** API keys,
   tokens — anything stored via `$SomeService.ApiKey`-style config — sit
   unencrypted in Azure SQL. If the DB is ever compromised or over-permissioned,
   every integrated system's credentials go with it. Real fix: move secrets to
   Azure Key Vault / AWS Secrets Manager / HashiCorp Vault, and have
   `ConfigurationService` fetch from there instead of the `ApiConfig` table (or
   store only a *reference* to the secret's location in `ApiConfig`, not the
   secret itself).
2. **Secrets can leak into the audit trail.** If a workflow step puts a
   token/key directly into a URL (as a query parameter, rather than a header),
   it gets persisted in plaintext into `OrchestrationRuns.RequestUrl` — forever,
   readable by anyone with DB access. Review every existing step's `Endpoint`
   and `InputParamMap` for this pattern before going live; prefer headers for
   anything sensitive (which are never persisted to `RequestUrl`).
3. **One API key = access to everything.** There's no per-project scoping —
   whoever holds a valid key can run any project/environment/scenario. If this
   client needs to restrict which teams can trigger which workflows, that's a
   real authorization model (claims/roles tied to specific keys), not covered
   by the current all-or-nothing gate.
4. **Migrations vs. schema scripts.** You explicitly chose schema scripts
   earlier in our conversation. Revisit this specifically for any environment
   with real, persistent data: schema scripts cannot evolve an existing
   schema — if you ever need to add a column (like the new `AttemptCount` this
   round), it silently does nothing on a database that already exists. You'd
   need to either manually `ALTER TABLE`, or switch back to migrations before
   that first real deployment.

### 🟡 Should resolve before meaningful production load
5. **No automated tests.** Nothing in this codebase is a test project.
   `PlaceholderResolver` is the most complex, highest-risk logic in the system
   (it's what makes chaining work) — it should have unit tests covering nested
   paths, array indexing, embedded vs. whole-value substitution, and the new
   URL-encoding behavior, before you trust it with a client's real workflows.
6. **CORS is not configured.** If any browser-based tool will call this API
   directly (not just server-to-server), you'll need an explicit CORS policy —
   currently completely unconfigured.
7. **Rate limit values are placeholders**, as noted above — validate against
   this client's actual expected traffic pattern.
8. **No load/concurrency testing done.** Verify behavior under multiple
   simultaneous scenario runs — particularly Azure SQL connection pool sizing
   under load.

### 🟢 Operational maturity — not blockers, but expected at scale
9. **Log aggregation.** Logs currently go wherever `ILogger`'s default provider
   sends them (console, typically). Wire into a real aggregator (Datadog, ELK,
   Application Insights, etc.) with alerting on error rates and repeated
   step failures.
10. **Backup/disaster-recovery plan** for the Azure SQL database.
11. ~~**A decision on `OrchestratorService.cs`**~~ — resolved: deleted in the
    production-readiness pass (see `CHANGELOG.md`).

---

## Bottom line

**What changed this round makes the difference between "a demo that would fall
over the moment it met the real internet" and "a deployment that's genuinely
defensible on day one."** Authentication, SSRF hardening, and the URL-encoding
fix were the three items I'd call non-negotiable blockers — they're done.

**Update from the production-readiness pass:** the plaintext password and API key that were
committed in `appsettings.json` have been removed (see `CHANGELOG.md`) — the base config now
ships blank and fails closed unless every environment sets `ConnectionStrings__OrchestratorDb` and
`ApiKey__ValidKeys` explicitly, exactly as this document already recommended. Local development
is unaffected via the new `appsettings.Development.json`. The remaining decision — *which*
secrets manager (Key Vault, Parameter Store, Vault, etc.) actually injects those env vars in
each real environment — is still yours to make; that depends on infrastructure this document
has no visibility into.


---

## Update: Azure SQL migration

The database is now Azure SQL; application logic is unchanged. Items above that mention PostgreSQL apply
equally to Azure SQL. Passwordless access via managed identity is documented in `docs/AZURE_DEPLOYMENT.md`.
