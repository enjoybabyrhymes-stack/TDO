# Azure Deployment Guide

## 1. Database

1. Create an Azure SQL Database. Keep the default collation (`SQL_Latin1_General_CP1_CI_AS`); scenario
   lookups are case-insensitive by relying on it.
2. Apply the schema, connected to the target database:
   ```bash
   sqlcmd -S <server>.database.windows.net -d <database> -G -i database/001_InitialSchema.sql
   ```
3. Allow the application to reach the server (private endpoint or firewall rule / "Allow Azure services").

The application still calls `EnsureCreated()` at startup, so the script is optional: it is provided for
environments where a DBA creates the schema. Note that `EnsureCreated()` cannot alter an existing schema;
for later schema changes apply `database/003_AddPollingColumns.sql` and `database/004_AddGroupsAndUsers.sql` and `database/005_AddRunGroupId.sql`
(or set `Database__AutoUpgrade=true` for one start), then use numbered scripts or EF Core migrations (`dotnet ef migrations add`).

## 2. Identity and access (recommended: no passwords)

1. Enable a system-assigned managed identity on the App Service / Container App.
2. As a Microsoft Entra admin on the database, run `database/002_GrantApplicationAccess.sql` with the
   identity name filled in. It grants read access to the configuration tables and insert access to the
   audit table only.
3. Use a passwordless connection string:
   ```
   Server=tcp:<server>.database.windows.net,1433;Database=<database>;Authentication=Active Directory Managed Identity;Encrypt=True;
   ```
   For a user-assigned identity add `User Id=<client-id>;`.

If you must use SQL authentication, store the connection string in Key Vault (section 3); never place it in a file.

## 3. Secrets in Azure Key Vault (read by the application)

The application can load its secrets directly from Azure Key Vault at startup. Nothing secret is then stored
in files, images or app settings; only the vault address is configured.

1. **Create the vault** with RBAC authorization (use a vault dedicated to this application, because every
   secret in it is loaded into configuration):
   ```bash
   az keyvault create -n <vault-name> -g <resource-group> -l <region> --enable-rbac-authorization true
   ```
2. **Store the secrets.** Key Vault names cannot contain `:`, so `--` stands in for it:

   | Secret name | Configuration key | Value |
   |---|---|---|
   | `ConnectionStrings--OrchestratorDb` | `ConnectionStrings:OrchestratorDb` | Azure SQL connection string |
   | `ApiKey--ValidKeys--0` | `ApiKey:ValidKeys:0` | API key for consumer 1 |
   | `Admin--ApiKeys--0` | `Admin:ApiKeys:0` | Admin UI key (separate from the run key) |
   | `ApiKey--ValidKeys--1` | `ApiKey:ValidKeys:1` | API key for consumer 2 (optional) |

   ```bash
   az keyvault secret set --vault-name <vault-name> --name "ConnectionStrings--OrchestratorDb" --value "<connection string>"
   az keyvault secret set --vault-name <vault-name> --name "ApiKey--ValidKeys--0" --value "<random key>"
   ```
3. **Give the application's managed identity read access:**
   ```bash
   az role assignment create --assignee <identity principal id> --role "Key Vault Secrets User" \
     --scope $(az keyvault show -n <vault-name> --query id -o tsv)
   ```
4. **Tell the application where the vault is** (the only Key Vault setting needed):
   ```
   KeyVault__Uri=https://<vault-name>.vault.azure.net/
   KeyVault__ManagedIdentityClientId=<client id>     # only for a user-assigned identity
   ```

Behaviour to be aware of:
- Vault values override appsettings and environment variables.
- Secrets are read once at startup. After rotating a secret, restart the application.
- If the vault cannot be reached or the identity lacks access, the application stops at startup with an error that
  names the vault, instead of running with missing configuration.
- In Development the application authenticates with your own login (`az login` or Visual Studio) if
  `KeyVault__Uri` is set; leave it empty for ordinary local work.
- If the vault uses a firewall or private endpoint, the application's network must be allowed.

## 4. Application settings

| Setting | Value |
|---|---|
| `ASPNETCORE_ENVIRONMENT` | `Production` |
| `KeyVault__Uri` | vault address (section 3). Omit `ConnectionStrings__OrchestratorDb` and `ApiKey__*` when the secrets are in the vault |
| `ASPNETCORE_FORWARDEDHEADERS_ENABLED` | `true` |
| `Security__BlockAllPrivateNetworks` | `true` only if no step calls a private-network system |
| `Admin__SessionHours` / `Admin__MinPasswordLength` | optional: UI session length (default 8) and minimum password length (default 8) |
| `Database__AutoUpgrade` | `true` for one start to add new columns/tables to an existing database; otherwise run the SQL scripts |

Generate API keys with, for example, `openssl rand -base64 32`. Rotate by adding the new key as
`ApiKey__ValidKeys__1`, moving consumers over, then removing the old one.

## 5. Probes

- `GET /health/live` and `GET /health/ready` (both check the database)

## 6. Release checklist

- [ ] Schema scripts (001, and 003/004 for an existing database) applied to the target database
- [ ] First administrator created via the admin key, groups and users added, existing scenarios/connections assigned to groups
- [ ] Managed identity granted least-privilege access
- [ ] Secrets stored in Key Vault and the managed identity can read them
- [ ] No secret present in any committed file or image layer
- [ ] API keys set and distributed to consumers
- [ ] `ASPNETCORE_ENVIRONMENT=Production`
- [ ] Scenario rows and `ApiConfig` base URLs loaded for this client
- [ ] Review step `Endpoint` / `InputParamMap` values: secrets must not travel in URLs (the resolved URL is stored in `OrchestrationRuns.RequestUrl`)
- [ ] Logs shipped to the client's monitoring stack (e.g. Application Insights / Log Analytics)
- [ ] Database backup and retention policy confirmed
